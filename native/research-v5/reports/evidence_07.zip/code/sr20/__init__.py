"""CASR-inspired lightweight cyclic super-resolution (not official CASR)."""
