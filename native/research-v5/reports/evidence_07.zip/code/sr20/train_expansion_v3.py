"""Controlled real-only / synthetic-mixture20x pilots, grouped real validation."""
import argparse, collections, json, math, os, random, time
from pathlib import Path
import numpy as np
import torch
from torch.nn import functional as F
from .train_reduction_v2 import FlexibleSR, sample, loss_fn, scores
from .train_matched import dump, sha, masked

def structural(p,g,roi):
 p=p.clamp(0,1).mean(1,keepdim=True);g=g.mean(1,keepdim=True)
 mu=F.avg_pool2d(p,11,1,5);mg=F.avg_pool2d(g,11,1,5)
 vp=(F.avg_pool2d(p*p,11,1,5)-mu*mu).clamp_min(0);vg=(F.avg_pool2d(g*g,11,1,5)-mg*mg).clamp_min(0);cov=F.avg_pool2d(p*g,11,1,5)-mu*mg
 ss=((2*mu*mg+.01**2)*(2*cov+.03**2))/((mu*mu+mg*mg+.01**2)*(vp+vg+.03**2))
 dx=(p[:,:,:,1:]-p[:,:,:,:-1])-(g[:,:,:,1:]-g[:,:,:,:-1]);dy=(p[:,:,1:]-p[:,:,:-1])-(g[:,:,1:]-g[:,:,:-1])
 return {'ssim_roi':masked(ss,roi).item(),'edge_mae':((masked(dx.abs(),roi[:,:,:,1:])+masked(dy.abs(),roi[:,:,1:]))/2).item()}

@torch.inference_mode()
def evaluate(model,rows,data):
 model.eval();out=[]
 for r in rows:
  assert not r['synthetic']
  for regime in ('clean','sensor'):
   b=sample(data,r,20,regime,'cuda');p=model(b['lr']);assert torch.isfinite(p).all()
   roi=b['roi'].clone();roi[:,:,:20]=0;roi[:,:,-20:]=0;roi[:,:,:,:20]=0;roi[:,:,:,-20:]=0
   out.append({'id':r['id'],'source_group':r['source_group'],'dataset':r['dataset'],'regime':regime,**scores(p,b['hr'],b['valid'],b['roi'],20),**structural(p,b['hr'],roi)})
 grouped=collections.defaultdict(list)
 for r in out:grouped[r['source_group']].append(r)
 metrics=['full','roi','ssim_roi','edge_mae'];groupmeans={k:{m:float(np.mean([r[m] for r in v])) for m in metrics} for k,v in grouped.items()};means={m:float(np.mean([g[m] for g in groupmeans.values()])) for m in metrics}
 return {'count':len(out),'groups':len(groupmeans),'score':means['roi'],'group_means':groupmeans,'means':means,'rows':out}

def main(a):
 torch.set_num_threads(4);torch.manual_seed(932);assert torch.cuda.is_available()
 manifest=json.loads((a.data/'manifest.json').read_text());records=manifest['records'];selection=json.loads(a.sampling.read_text());assert selection['manifest_sha256']==sha(a.data/'manifest.json');ids=selection['arms'][a.arm];assert len(ids)==a.steps*4
 rows={s:[r for r in records if r['split']==s and not r['synthetic']] for s in ('val','test')}
 init=torch.load(a.init,map_location='cpu',weights_only=True);config={**init['model_config'],'default_scale':20};model=FlexibleSR(**config).cuda();model.load_state_dict(init['model']);opt=torch.optim.Adam(model.parameters(),lr=3e-5);a.run.mkdir(parents=True,exist_ok=True);best=-1e10;start=0
 cfg={'arm':a.arm,'steps':a.steps,'batch_effective':4,'lr':3e-5,'parameters':sum(p.numel() for p in model.parameters()),'model_config':config,'manifest_sha256':sha(a.data/'manifest.json'),'sampling_sha256':sha(a.sampling),'code_sha256':sha(Path(__file__)),'init_sha256':sha(a.init),'sensor_probability':.75,'selection':'Equal weight real validation source groups, clean/sensor balanced ROI PSNR; step0 eligible','synthetic_probability':.1 if a.arm=='S20_mix' else 0,'gate':'Synthetic must exceed real-only grouped validation ROI PSNR by0.05dB, SSIM drop no more than0.002, edgeMAE no more than1.02x. Exploratory gate, not significance claim.'}
 if (a.run/'config.json').exists():
  assert json.loads((a.run/'config.json').read_text())==cfg;c=torch.load(a.run/'last.pt',map_location='cuda',weights_only=False);model.load_state_dict(c['model']);opt.load_state_dict(c['opt']);start=c['step'];best=c['best']
 else:dump(a.run/'config.json',cfg)
 def export(step):torch.save({'model':{k:v.cpu() for k,v in model.state_dict().items()},'model_config':config,'step':step,'arm':a.arm,'manifest_sha256':cfg['manifest_sha256']},a.run/'best_inference.pt')
 def checkpoint(step):
  p=a.run/'last.pt.tmp';torch.save({'model':model.state_dict(),'opt':opt.state_dict(),'step':step,'best':best},p);p.replace(a.run/'last.pt')
 begin=time.monotonic()
 if not (a.run/'validation_0.json').exists():
  val=evaluate(model,rows['val'],a.data);dump(a.run/'validation_0.json',val);best=val['score'];export(0);checkpoint(0);print('INITIAL',a.arm,best,flush=True)
 with (a.run/'progress.jsonl').open('a') as log:
  for step in range(start,a.steps):
   model.train();opt.zero_grad();total=0
   for pg in opt.param_groups:pg['lr']=3e-5*(.2+.8*.5*(1+math.cos(math.pi*step/a.steps)))
   for j in range(4):
    serial=step*4+j;r=records[ids[serial]];assert r['split']=='train';regime='sensor' if random.Random(93400000+serial).random()<.75 else 'clean';b=sample(a.data,r,20,regime,'cuda');p,st=model(b['lr'],return_stages=True);loss=loss_fn(p,st,b);assert torch.isfinite(loss);(loss/4).backward();total+=loss.item()/4
   grad=torch.nn.utils.clip_grad_norm_(model.parameters(),1,error_if_nonfinite=True);opt.step();row={'step':step+1,'loss':total,'grad':grad.item(),'elapsed':time.monotonic()-begin};log.write(json.dumps(row)+'\n');log.flush()
   if (step+1)%25==0:print(json.dumps(row),flush=True)
   if (step+1)%500==0 or step+1==a.steps:
    val=evaluate(model,rows['val'],a.data);dump(a.run/f'validation_{step+1}.json',val)
    if val['score']>best:best=val['score'];export(step+1)
    print('VALIDATION',a.arm,step+1,val['means'],flush=True)
   if (step+1)%25==0:
    checkpoint(step+1)
    if (time.monotonic()-begin>a.max_seconds or time.time()>float(os.environ.get('SLURM_JOB_END_TIME','inf'))-120) and step+1<a.steps:print('RESUMABLE_TIME_SLICE',step+1,flush=True);return
 checkpoint(a.steps);chosen=torch.load(a.run/'best_inference.pt',map_location='cuda',weights_only=True);model.load_state_dict(chosen['model']);dump(a.run/'test_selected.json',evaluate(model,rows['test'],a.data));dump(a.run/'validation_selected.json',evaluate(model,rows['val'],a.data));model.load_state_dict(init['model']);dump(a.run/'test_initial.json',evaluate(model,rows['test'],a.data));dump(a.run/'completion.json',{'complete':True,'arm':a.arm,'steps':a.steps,'selected_step':chosen['step'],'test_sources':len(rows['test']),'test_predictions':len(rows['test'])*2,'best_validation':best});print('V3_TRAIN_COMPLETE',a.arm,flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--data',type=Path,required=True);p.add_argument('--init',type=Path,required=True);p.add_argument('--sampling',type=Path,required=True);p.add_argument('--run',type=Path,required=True);p.add_argument('--arm',choices=['R20_real','S20_mix'],required=True);p.add_argument('--steps',type=int,default=2000);p.add_argument('--max-seconds',type=int,default=350);main(p.parse_args())
