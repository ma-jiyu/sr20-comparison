"""20x research models. B adapts pretrained RealESRNet; C adapts released CASR.

RRDB equations and state naming follow BasicSR's BSD-3-Clause implementation
(Xintao Wang et al.); no claim of an official pretrained20x RealESRNet.
"""
from pathlib import Path
import sys
import torch
from torch import nn
from torch.nn import functional as F

GROUPS = ('bottleneck_in_LLM', 'bottleneck_in_Attn', 'bottleneck_out_LLM', 'bottleneck_out_Attn')

class DenseBlock(nn.Module):
    def __init__(self):
        super().__init__()
        for i in range(1, 6):
            setattr(self, 'conv'+str(i), nn.Conv2d(64+(i-1)*32, 32 if i<5 else 64, 3, 1, 1))
    def forward(self, x):
        parts = [x]
        for i in range(1, 5):
            parts.append(F.leaky_relu(getattr(self, 'conv'+str(i))(torch.cat(parts, 1)), .2))
        return x + .2*self.conv5(torch.cat(parts, 1))

class RRDB(nn.Module):
    def __init__(self):
        super().__init__()
        self.rdb1, self.rdb2, self.rdb3 = DenseBlock(), DenseBlock(), DenseBlock()
    def forward(self, x):
        return x + .2*self.rdb3(self.rdb2(self.rdb1(x)))

class Reconstruction20(nn.Module):
    def __init__(self, weight):
        super().__init__()
        self.conv_first = nn.Conv2d(3, 64, 3, 1, 1)
        self.body = nn.Sequential(*[RRDB() for _ in range(23)])
        self.conv_body = nn.Conv2d(64, 64, 3, 1, 1)
        self.conv_up1 = nn.Conv2d(64, 64, 3, 1, 1)
        self.conv_up2 = nn.Conv2d(64, 64, 3, 1, 1)
        self.conv_up3 = nn.Conv2d(64, 64, 3, 1, 1)
        self.conv_hr = nn.Conv2d(64, 64, 3, 1, 1)
        self.conv_last = nn.Conv2d(64, 3, 3, 1, 1)
        state = torch.load(weight, map_location='cpu', weights_only=True)['params_ema']
        result = self.load_state_dict(state, strict=False)
        assert set(result.missing_keys) == {'conv_up3.weight', 'conv_up3.bias'} and not result.unexpected_keys
        nn.init.dirac_(self.conv_up3.weight)
        nn.init.zeros_(self.conv_up3.bias)
    def forward(self, x):
        h = self.conv_first(x)
        h = h + self.conv_body(self.body(h))
        for factor, layer in ((2, self.conv_up1), (2, self.conv_up2), (5, self.conv_up3)):
            h = F.leaky_relu(layer(F.interpolate(h, scale_factor=factor, mode='nearest')), .2)
        return self.conv_last(F.leaky_relu(self.conv_hr(h), .2))
    def export(self):
        return {k: v.detach().cpu() for k,v in self.state_dict().items()}
    def restore(self, state):
        self.load_state_dict(state, strict=True)

class Official20(nn.Module):
    """Full-field official stage2 forward, used identically for train and eval.

This is a DIRECT native20x aircraft adaptation, not the paper's cyclic recipe.
Native input is never enlarged and presented as additional observed information.
512-grid replication is computational padding, excluded from losses/metrics.
"""
    def __init__(self, official):
        super().__init__()
        self.official = Path(official)
        sys.path.insert(0, str(self.official / 'CASR'))
        sys.path.insert(0, str(self.official / 'CASR/infer'))
        from src.models.casr_stage2 import CASR
        from src.models.depth_anything_v2.infer import DepthModel
        from src.data.testing_utils_stage2 import parse_args_paired_testing
        from _common import load_tag_model
        from src.models.superpixel_fcn.infer import SuperPixel
        ckpt = self.official / 'weights/casr.pkl'
        args = parse_args_paired_testing(['--sd_path', str(self.official / 'weights/sdxl-turbo'),
                                        '--model_path', str(ckpt)])
        self.net = CASR(sd_path=args.sd_path, pretrained_path=str(ckpt), args=args)
        state = torch.load(ckpt, map_location='cpu', weights_only=False)
        for k in GROUPS:
            getattr(self.net, k).load_state_dict(state[k], strict=True)
            assert all(torch.equal(v.cpu(), state[k][n]) for n,v in getattr(self.net,k).state_dict().items())
        self.net.lora_rank_unet, self.net.lora_rank_vae = state['rank_unet'], state['rank_vae']
        self.net.target_modules_unet = state['unet_lora_target_modules']
        self.net.target_modules_vae = state['vae_lora_target_modules']
        del state
        self.net = self.net.cuda().float().eval().requires_grad_(False)
        for k in GROUPS:
            getattr(self.net, k).requires_grad_(True)
        self.net.unet.enable_xformers_memory_efficient_attention()
        self.net.vae.enable_xformers_memory_efficient_attention()
        self.depth = DepthModel(device='cuda', dtype=torch.float32)
        self.depth.model.requires_grad_(False)
        self.ram = load_tag_model(args).float().eval().requires_grad_(False)
        self.spix = SuperPixel('cuda')
    def train(self, mode=True):
        # Frozen pretrained encoder/helper statistics and dropout stay fixed.
        super().train(False)
        return self
    def forward(self, lr):
        from PIL import Image
        import numpy as np
        from torchvision.transforms.functional import to_tensor
        from _common import get_validation_prompt
        assert lr.shape[0] == 1
        h,w = lr.shape[-2:]; target = (h*20, w*20)
        side = max(512, ((max(target)+511)//512)*512)
        image = Image.fromarray(lr[0].detach().clamp(0,1).mul(255).round().byte().permute(1,2,0).cpu().numpy())
        with torch.no_grad():
            guide = to_tensor(image.resize((target[1],target[0]), Image.Resampling.BICUBIC))[None].cuda()
            x = to_tensor(self.spix(image, superpixel_size=4).resize((target[1],target[0]), Image.Resampling.NEAREST))[None].cuda()
            padding = (0,side-target[1],0,side-target[0])
            x = F.pad(x*2-1, padding, mode='replicate')
            guide = F.pad(guide,padding,mode='replicate')
            # Same patch order as official nested_tokenization.
            tiles = guide.reshape(1,3,side//512,512,side//512,512).permute(0,2,4,1,3,5).reshape(-1,3,512,512)
            depths = []
            for tile in tiles.split(1):
                d = self.depth.infer_tensor(tile)
                d = F.interpolate(d, (512,512), mode='bilinear', align_corners=False)
                depths.append((d-d.min())/(d.max()-d.min()).clamp_min(1e-6))
            d = torch.cat(depths)
            prompt, embeds = get_validation_prompt(image,self.ram)
        # The official encoder flattens512px image patches into the batch axis.
        # Text/time conditioning must use that SAME batch size. RAM embeddings
        # remain batch1 because the bottleneck processes the reassembled field.
        assert len(prompt)==1
        tile_count=(side//512)**2
        return (self.net(x,d,embeds,prompts=prompt*tile_count)[:,:,:target[0],:target[1]]+1)/2
    def export(self):
        return {k: {n:v.detach().cpu() for n,v in getattr(self.net,k).state_dict().items()} for k in GROUPS}
    def restore(self,state):
        for k in GROUPS:
            getattr(self.net,k).load_state_dict(state[k],strict=True)
