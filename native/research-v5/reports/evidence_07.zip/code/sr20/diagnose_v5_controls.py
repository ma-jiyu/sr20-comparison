"""Fixed old/B20/B30 and bicubic controls on new validation GT grids only.

The neural controls produce their original x20 output, then use the exact same
antialiased bicubic resize and metrics as the SwinIR diagnosis. An 80-pixel GT
result is never pooled with a 160-pixel or legacy 400-pixel result. No training,
test selection, or scheduler submission is performed here.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import torch
from torch import nn

from .diagnose_v5_swinir import dump, evaluate_rare
from .research_v4_models import Reconstruction20
from .train_reduction_v2 import FlexibleSR
from .v5_baselines import sha256


METHODS = ("bicubic", "old", "B20", "B30")


class FixedControl(nn.Module):
    def __init__(self, method, root, expected_weights, device):
        super().__init__()
        self.method = method
        # A zero-sized, nontrainable device anchor lets the shared evaluator
        # determine the device even for parameter-free bicubic interpolation.
        self.device_anchor = nn.Parameter(torch.empty(0), requires_grad=False)
        self.receipt = {"name": method, "new_training": False, "weight_sha256": None,
                        "checkpoint_step": None, "strict_load": None}
        v4 = root / "research_v4_20260929"
        if method == "bicubic":
            self.network = nn.Identity()
            self.receipt["prediction"] = "Direct antialiased bicubic LR-to-GT interpolation; no learned stage"
        else:
            path = (root / "reduction_v2_20260928/training/C20_sensor/best_inference.pt" if method == "old"
                    else v4 / "train/B_real" / ("best_perceptual.pt" if method == "B20" else "final.pt"))
            observed = sha256(path)
            if observed != expected_weights[method]:
                raise ValueError(f"Frozen {method} checkpoint hash mismatch: {path}")
            state = torch.load(path, map_location="cpu", weights_only=True)
            if method == "old":
                self.network = FlexibleSR(**state["model_config"])
                self.network.load_state_dict(state["model"], strict=True)
            else:
                expected_step = 20000 if method == "B20" else 30000
                if state["step"] != expected_step:
                    raise ValueError(f"Expected {method} step {expected_step}, got {state['step']}")
                initial_path = v4 / "weights/RealESRNet_x4plus.pth"
                self.network = Reconstruction20(initial_path)
                self.network.restore(state["model"])
                self.receipt["architecture_initial_asset_sha256"] = sha256(initial_path)
                self.receipt["checkpoint_step"] = state["step"]
            self.receipt.update(weight_sha256=observed, strict_load=True,
                                prediction="Original x20 forward, then antialiased bicubic resize to the effective GT grid")
        self.to(device)
        self.eval()
        self.requires_grad_(False)

    @torch.no_grad()
    def predict(self, lr, *, self_ensemble=False):
        if self_ensemble:
            raise ValueError("Fixed controls do not introduce self-ensemble")
        result = self.network(lr)
        if not torch.isfinite(result).all():
            raise FloatingPointError(f"Nonfinite {self.method} prediction")
        if self.method != "bicubic" and result.shape[-2:] != tuple(s * 20 for s in lr.shape[-2:]):
            raise ValueError("Fixed neural control no longer produces its original x20 grid")
        return result.clamp(0, 1)


def main(args):
    import lpips

    torch.set_num_threads(4)
    torch.manual_seed(1005)
    if args.device.startswith("cuda") and not torch.cuda.is_available():
        raise RuntimeError("Requested CUDA but none is available")
    vgg = Path(torch.hub.get_dir()) / "checkpoints/vgg16-397923af.pth"
    if not vgg.is_file():
        raise FileNotFoundError(f"Expected cached pretrained VGG; refusing implicit download: {vgg}")
    metric = lpips.LPIPS(net="vgg").to(args.device).eval().requires_grad_(False)
    protocol = json.loads(args.protocol.read_text(encoding="utf-8"))
    if protocol["selection_split"] != "val" or protocol["test_used_for_selection"]:
        raise ValueError("Expected validation-only diagnostic protocol")
    manifest = args.rare_data / "manifest.json" if args.rare_data.is_dir() else args.rare_data
    for method in args.methods:
        model = FixedControl(method, args.root, protocol["weights"], args.device)
        out = args.out / method
        config = {"model": model.receipt, "manifest_sha256": sha256(manifest),
                  "protocol_sha256": sha256(args.protocol), "vgg_sha256": sha256(vgg),
                  "split": "val", "test_used_for_selection": False,
                  "code_sha256": {name: sha256(Path(__file__).with_name(name)) for name in
                                  ("diagnose_v5_controls.py", "diagnose_v5_swinir.py", "v5_baselines.py",
                                   "research_v4_models.py", "train_reduction_v2.py", "train_expansion_v3.py",
                                   "train_research_v4.py")}}
        config_path = out / "config.json"
        if config_path.exists() and json.loads(config_path.read_text(encoding="utf-8")) != config:
            raise ValueError(f"Existing output uses a different configuration: {out}")
        dump(config_path, config)
        result = evaluate_rare(model, manifest, metric, out)
        result["method"] = method
        result["weight_sha256"] = model.receipt["weight_sha256"]
        result["prediction"] = model.receipt["prediction"]
        for grid in result["grids"].values():
            for row in grid["rows"]:
                produced_size = row.pop("learned_size_hw")
                row["network_output_size_hw"] = produced_size if method != "bicubic" else None
        dump(out / "effective_grid_validation.json", result)
        dump(out / "complete.json", {"complete": True, "split": "val", "new_training": False,
                                     "config_sha256": sha256(config_path),
                                     "counts_per_grid": {k: v["count"] for k, v in result["grids"].items()}})
        print("V5_EFFECTIVE_CONTROLS_COMPLETE", method,
              {k: v["means"] for k, v in result["grids"].items()}, flush=True)
        del model
        if torch.cuda.is_available():
            torch.cuda.empty_cache()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    for key in ("root", "out", "protocol", "rare-data"):
        parser.add_argument("--" + key, type=Path, required=True)
    parser.add_argument("--methods", nargs="+", choices=METHODS, default=list(METHODS))
    parser.add_argument("--device", default="cuda")
    main(parser.parse_args())
