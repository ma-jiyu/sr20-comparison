"""Frozen native20 pairs, source-balanced training and held-out selection."""
import argparse, json, hashlib, random, time, math, collections, os
from pathlib import Path
import numpy as np
from PIL import Image
import torch
from torch.nn import functional as F
from .model import CyclicSR, resize

def dump(p,v):
 t=p.with_suffix(p.suffix+'.tmp');t.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf8');t.replace(p)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def sample(data,r,device):
 out={}
 for k,v in r['files'].items():
  a=np.asarray(Image.open(data/v['path'])).copy()
  if a.ndim==2:a=a[:,:,None]
  out[k]=torch.from_numpy(a).permute(2,0,1).float()[None].to(device)/255
 return out
def masked(a,m):return (a*m).sum((1,2,3))/(m.sum((1,2,3))*a.shape[1]).clamp_min(1)
def loss_fn(pred,stages,b):
 mask=b['valid']*(1+2*b['roi'])
 def l1(x,y):return masked((x-y).abs(),F.interpolate(mask,size=x.shape[-2:],mode='area')).mean()
 rec=l1(pred,b['hr']);inter=sum(l1(x,resize(b['hr'],x.shape[-2:]).clamp(0,1)) for x in stages[:-1])/2
 consistency=l1(resize(pred,(20,20)),b['clean_lr'])
 dx=(pred[:,:,:,1:]-pred[:,:,:,:-1])-(b['hr'][:,:,:,1:]-b['hr'][:,:,:,:-1])
 dy=(pred[:,:,1:,:]-pred[:,:,:-1,:])-(b['hr'][:,:,1:,:]-b['hr'][:,:,:-1,:])
 edge=(masked(dx.abs(),torch.minimum(mask[:,:,:,1:],mask[:,:,:,:-1])).mean()+masked(dy.abs(),torch.minimum(mask[:,:,1:,:],mask[:,:,:-1,:])).mean())/2
 return rec+.1*inter+.05*consistency+.05*edge
@torch.inference_mode()
def evaluate(model,rows,data,device,save=None):
 model.eval();out=[]
 for r in rows:
  b=sample(data,r,device);p=model(b['lr']).clamp(0,1);base=resize(b['lr'],(400,400)).clamp(0,1)
  valid=b['valid'].clone();valid[:,:,:20]=0;valid[:,:,-20:]=0;valid[:,:,:,:20]=0;valid[:,:,:,-20:]=0
  row={k:r[k] for k in ('id','dataset','source_group')};row['variant']=r['degradation']['variant']
  for prefix,x in [('model',p),('bicubic',base)]:
   for region,m in [('full',valid),('roi',valid*b['roi'])]:
    err=masked((x-b['hr']).square(),m).item();row[prefix+'_'+region+'_psnr']=-10*math.log10(max(err,1e-12))
  out.append(row)
  if save:
   dest=save/r['id'];dest.mkdir(parents=True,exist_ok=True);Image.fromarray((p[0].permute(1,2,0).cpu().numpy()*255).round().astype('uint8')).save(dest/'sr.png')
 strata=collections.defaultdict(list)
 for r in out:strata[(r['dataset'],r['variant'])].append(r)
 means={f'{k[0]}/v{k[1]}':{m:float(np.mean([x[m] for x in v])) for m in ('model_full_psnr','model_roi_psnr','bicubic_full_psnr','bicubic_roi_psnr')} for k,v in strata.items()}
 return {'count':len(out),'score':float(np.mean([v['model_roi_psnr'] for v in means.values()])),'stratum_means':means,'rows':out,'metric':'RGB PSNR, clamp0-1, shave20px and exclude padding; ROI is coarse annotation region. Macro mean across dataset and degradation variant. Synthetic paired test, not native real GT.'}
def sampler(rows,seed):
 pools=collections.defaultdict(lambda:collections.defaultdict(list))
 for r in rows:pools[r['dataset']][r['source_group']].append(r)
 names=sorted(pools);weights=[{'dota':.7,'internal':.3,'rareplanes-real':0}[n] for n in names]
 def get(i):
  rng=random.Random(seed*10000000+i);ds=rng.choices(names,weights)[0];groups=sorted(pools[ds]);g=rng.choice(groups);return rng.choice(pools[ds][g])
 return get
def main(a):
 torch.set_num_threads(4);torch.manual_seed(928);random.seed(928);np.random.seed(928)
 device='cuda';assert torch.cuda.is_available();manifest=json.loads((a.data/'manifest.json').read_text());rows={s:[r for r in manifest['records'] if r['split']==s] for s in ['train','val','test']}
 saved=torch.load(a.init,map_location='cpu',weights_only=True);model=CyclicSR(**saved['model_config']).to(device);model.load_state_dict(saved['model']);optimizer=torch.optim.Adam(model.parameters(),lr=a.lr)
 a.run.mkdir(parents=True,exist_ok=True);cfg={'steps':a.steps,'lr':a.lr,'accumulation':4,'seed':928,'init_sha256':sha(a.init),'manifest_sha256':sha(a.data/'manifest.json'),'code_sha256':sha(Path(__file__)),'model_config':saved['model_config'],'parameters':sum(p.numel() for p in model.parameters()),'sampling':'dataset probability DOTA.7 internal.3 Rare0; uniform source group then pair; same deterministic draws both arms. Rare excluded: only25feasible pairs from4train locations and none inpairedholdout.','selection':'Full validation, macro mean ROI PSNR by dataset/degradation; step0 eligible; no test selection','loss':'L1 valid*(1+2ROI), .1 intermediate, .05 cleanLR consistency, .05 first-difference; padding excluded; coarse ROI is not silhouette','budget':'2000 optimizer steps effectivebatch4; data+ROI-loss package. Two arms isolate capacity conditional on that package.'}
 start=0;best=-1e9
 if (a.run/'config.json').exists():
  assert json.loads((a.run/'config.json').read_text())==cfg
  c=torch.load(a.run/'last.pt',map_location=device,weights_only=False);model.load_state_dict(c['model']);optimizer.load_state_dict(c['optimizer']);start=c['step'];best=c['best']
 else:dump(a.run/'config.json',cfg)
 def export(step,name):torch.save({'model':{k:v.cpu() for k,v in model.state_dict().items()},'model_config':saved['model_config'],'step':step,'manifest_sha256':cfg['manifest_sha256']},a.run/name)
 def checkpoint(step):
  t=a.run/'last.pt.tmp';torch.save({'model':model.state_dict(),'optimizer':optimizer.state_dict(),'step':step,'best':best},t);t.replace(a.run/'last.pt')
 begin=time.monotonic()
 if not (a.run/'validation_0.json').exists():
  # Check that the exact training path can fit a fixed tiny batch. Restore all weights afterward.
  initial={k:v.detach().clone() for k,v in model.state_dict().items()};mini=[sample(a.data,r,device) for r in rows['train'][:4]];opt=torch.optim.Adam(model.parameters(),lr=1e-4);values=[]
  for step in range(24):
   model.train();opt.zero_grad();b=mini[step%4];p,st=model(b['lr'],return_stages=True);loss=loss_fn(p,st,b);assert torch.isfinite(loss);loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),1,error_if_nonfinite=True);opt.step();values.append(loss.item())
  smoke={'first4_mean':float(np.mean(values[:4])),'last4_mean':float(np.mean(values[-4:])),'losses':values};dump(a.run/'smoke.json',smoke);assert smoke['last4_mean']<smoke['first4_mean'],'Tiny fixed set failed to improve'
  model.load_state_dict(initial);del initial,mini,opt
  v=evaluate(model,rows['val'],a.data,device);dump(a.run/'validation_0.json',v);best=v['score'];export(0,'best_inference.pt');checkpoint(0);print('INITIAL',best,flush=True)
 choose=sampler(rows['train'],928)
 with (a.run/'progress.jsonl').open('a') as log:
  for step in range(start,a.steps):
   model.train();optimizer.zero_grad();total=0
   for pg in optimizer.param_groups:pg['lr']=a.lr*(.2+.8*.5*(1+math.cos(math.pi*step/a.steps)))
   for j in range(4):
    b=sample(a.data,choose(step*4+j),device);pred,stages=model(b['lr'],return_stages=True);loss=loss_fn(pred,stages,b);assert torch.isfinite(loss);(loss/4).backward();total+=loss.item()/4
   norm=torch.nn.utils.clip_grad_norm_(model.parameters(),1,error_if_nonfinite=True);optimizer.step();record={'step':step+1,'loss':total,'grad':norm.item(),'elapsed':time.monotonic()-begin};log.write(json.dumps(record)+'\n');log.flush()
   if (step+1)%25==0:print(json.dumps(record),flush=True)
   if (step+1)%500==0 or step+1==a.steps:
    v=evaluate(model,rows['val'],a.data,device);dump(a.run/f'validation_{step+1}.json',v)
    if v['score']>best:best=v['score'];export(step+1,'best_inference.pt')
    print('VALIDATION',step+1,v['score'],best,flush=True)
   if (step+1)%50==0:
    checkpoint(step+1)
    if time.monotonic()-begin>a.max_seconds and step+1<a.steps:print('RESUMABLE_TIME_SLICE',step+1,flush=True);return
 checkpoint(a.steps);export(a.steps,'final_inference.pt')
 chosen=torch.load(a.run/'best_inference.pt',map_location=device,weights_only=True);model.load_state_dict(chosen['model']);dump(a.run/'test_selected.json',evaluate(model,rows['test'],a.data,device,a.run/'test_outputs'))
 model.load_state_dict(saved['model']);dump(a.run/'test_initial.json',evaluate(model,rows['test'],a.data,device))
 dump(a.run/'completion.json',{'complete':True,'steps':a.steps,'best_step':chosen['step'],'best_score':best,'test_count':len(rows['test'])});print('MATCHED_TRAIN_COMPLETE',flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--data',type=Path,required=True);p.add_argument('--init',type=Path,required=True);p.add_argument('--run',type=Path,required=True);p.add_argument('--steps',type=int,default=2000);p.add_argument('--lr',type=float,default=3e-5);p.add_argument('--max-seconds',type=int,default=1200);main(p.parse_args())
