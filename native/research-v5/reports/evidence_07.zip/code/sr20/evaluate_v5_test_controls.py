"""Fixed x4 test controls, accessible only after a candidate selection is frozen.

Uses the exact selected-candidate test evaluator. It never chooses, ranks, or
changes a candidate using test scores. Run explicitly after freezing selection;
importing this file does not load images, models, or test metadata.
"""
from __future__ import annotations

import argparse
import json
import os
from pathlib import Path
import time

import torch
from torch import nn

from .diagnose_v5_controls import FixedControl
from .diagnose_v5_swinir import dump
from .v5_baselines import SwinIRBaseline, display_resize, sha256
from .infer_v5_swinir import (HeldoutData, METRIC_SPEC, DISPLAY_SPEC, below,
                             load_selection, output_lock, paired_test,
                             read_json, verify_payload)


METHODS = ("bicubic", "old", "B20", "B30", "swinir_classical_x4_init", "swinir_real_psnr_x4_init")


class EffectiveX4Control(nn.Module):
    """Expose an identical effective output grid to the common test evaluator."""

    def __init__(self, method, root, assets, expected_weights, device):
        super().__init__()
        self.method = method
        if method.endswith("_init"):
            self.base = SwinIRBaseline(method.removesuffix("_init"), assets, device)
            self.receipt = {**self.base.source_receipt, "adapted": False,
                            "prediction": "Official pretrained x4 output on the native effective80px grid"}
        else:
            self.base = FixedControl(method, root, expected_weights, device)
            self.receipt = self.base.receipt
        self.eval().requires_grad_(False)

    @torch.no_grad()
    def forward(self, lr):
        output = self.base.predict(lr)
        return display_resize(output, tuple(int(s) * 4 for s in lr.shape[-2:]))

    @torch.no_grad()
    def predict(self, lr, **kwargs):
        if kwargs.get("self_ensemble"):
            raise ValueError("The frozen fixed controls do not introduce self-ensemble")
        return self(lr)


def main(args):
    start = time.monotonic()
    if sha256(args.selection) != args.selection_sha256:
        raise ValueError("Selection JSON bytes differ from the explicitly frozen SHA256")
    selected, checkpoint, training, _, _ = load_selection(args.selection, args.run, args.data, args.root)
    for name, digest in training["code_sha256"].items():
        if sha256(Path(__file__).parent / name) != digest:
            raise ValueError(f"Frozen training/metric helper changed: {name}")
    state = torch.load(checkpoint, map_location="cpu", weights_only=True)
    if state["config"] != training or state["step"] != selected["checkpoint"]["step"]:
        raise ValueError("Frozen candidate checkpoint contents disagree with selection")
    del state
    controls = read_json(args.controls_protocol)
    if controls["selection_split"] != "val" or controls["test_used_for_selection"]:
        raise ValueError("Expected fixed pre-test control identities")
    if set(controls["weights"]) != {"old", "B20", "B30"}:
        raise ValueError("Fixed controls must include the old, B20 and B30 checkpoints")
    if args.device == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("Requested CUDA but none is available")
    torch.set_num_threads(4)
    torch.manual_seed(1005)
    if torch.cuda.is_available():
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False
        torch.backends.cudnn.benchmark = False
        torch.backends.cudnn.deterministic = True
    vgg = Path(torch.hub.get_dir()) / "checkpoints/vgg16-397923af.pth"
    if not vgg.is_file() or sha256(vgg) != training["vgg_sha256"]:
        raise ValueError("Exact pretrained VGG from the training config must already be staged")

    # No held-out image is opened until all frozen-selection checks above pass.
    import lpips
    metric = lpips.LPIPS(net="vgg").to(args.device).eval().requires_grad_(False)
    data = HeldoutData(args.data, selected["data_manifest_sha256"])
    common = {"version": 5, "selection_sha256": args.selection_sha256,
              "data_manifest_sha256": selected["data_manifest_sha256"],
              "vgg_sha256": training["vgg_sha256"],
              "controls_protocol_sha256": sha256(args.controls_protocol),
              "fixed_methods": list(METHODS), "selection_changed": False,
              "test_used_for_selection": False, "no_test_ranking": True,
              "metric_spec": METRIC_SPEC, "display_spec": DISPLAY_SPEC,
              "precision": "float32", "paired_pairs": 78, "paired_cases": 156,
              "input_size": [20, 20], "effective_output_size": [80, 80], "shave": 4,
              "output_key_note": "Shared storage key learned80 denotes the effective80px comparison image; bicubic has no learned stage and x20 controls are downsampled.",
              "code_sha256": {name: sha256(Path(__file__).with_name(name)) for name in
                              ("evaluate_v5_test_controls.py", "infer_v5_swinir.py", "diagnose_v5_controls.py",
                               "diagnose_v5_swinir.py", "v5_baselines.py", "v5_baseline_sources.json")},
              "torch": str(torch.__version__)}

    def deadline():
        return (time.monotonic() - start >= args.max_seconds or
                time.time() >= float(os.environ.get("SLURM_JOB_END_TIME", "inf")) - 120)

    with output_lock(args.out):
        root_config = args.out / "config.json"
        if root_config.exists() and read_json(root_config) != common:
            raise ValueError("This test-controls output belongs to another frozen configuration")
        dump(root_config, common)
        reports = []
        for method in METHODS:
            if deadline():
                print("RESUMABLE_V5_TEST_CONTROLS", method, flush=True)
                return
            model = EffectiveX4Control(method, args.root, args.assets, controls["weights"], args.device)
            output = args.out / method
            config = {**common, "method": method, "model": model.receipt}
            config_path = output / "config.json"
            if config_path.exists() and read_json(config_path) != config:
                raise ValueError(f"Fixed control identity changed: {method}")
            dump(config_path, config)
            if not paired_test(model, data, metric, args.device, output, config, sha256(config_path), deadline):
                return
            report_path = output / "paired_test.json"
            report = read_json(report_path)
            if report["count"] != 156 or report["groups"] != 4 or report["metric_spec"] != METRIC_SPEC:
                raise ValueError("Control did not cover the identical frozen effective-grid test cases")
            for row in report["rows"]:
                for key, size in (("learned80", (80, 80)), ("display400", (400, 400))):
                    entry = row["outputs"][key]
                    verify_payload(below(output, entry["path"]).read_bytes(), entry, size)
            reports.append({"method": method, "path": str(report_path), "sha256": sha256(report_path),
                            "config_sha256": sha256(config_path), "verified_output_files": 312})
            print("V5_FIXED_TEST_CONTROL_COMPLETE", method, flush=True)
            del model
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
        dump(args.out / "complete.json", {"complete": True, "config_sha256": sha256(root_config),
             "selection_sha256": args.selection_sha256, "reports": reports,
             "selection_changed": False, "test_ranking_performed": False})


def parser():
    result = argparse.ArgumentParser(description=__doc__)
    for name in ("root", "run", "out", "assets", "data", "selection", "controls-protocol"):
        result.add_argument("--" + name, type=Path, required=True)
    result.add_argument("--selection-sha256", required=True,
                        help="SHA256 of the previously frozen candidate selection JSON")
    result.add_argument("--device", default="cuda", choices=("cpu", "cuda"))
    result.add_argument("--max-seconds", type=float, default=100000)
    return result


if __name__ == "__main__":
    main(parser().parse_args())
