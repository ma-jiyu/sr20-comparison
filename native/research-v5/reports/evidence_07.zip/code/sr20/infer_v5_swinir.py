"""Frozen-candidate x4 test evaluation and resumable native8000 inference.

No candidate selection, training, network downloads or test-driven tuning occurs.
Use --selection with the explicit schema validated by load_selection(). Native
learned80 and display400 outputs are different artifacts: the latter is exactly
PIL bicubic resampling of the quantized learned80 image, never learned x20 SR.
"""
import argparse
import collections
from contextlib import contextmanager
import hashlib
from io import BytesIO
import json
import math
import os
from pathlib import Path
import tarfile
import time

import numpy as np
from PIL import Image
import torch

from .v5_baselines import SwinIRBaseline
from .train_reduction_v2 import scores
from .train_expansion_v3 import structural
from .train_research_v4 import perception
from .diagnose_v5_perceptual import pil_consistency


METRICS = ('full', 'roi', 'ssim_roi', 'edge_mae', 'lpips_roi', 'same_operator_lr_mae')
METRIC_SPEC = 'trainer_v5:RGB80;shave4;valid/diamondROI;structural_gray11;VGG_plane_crop224;samePILbicubicLR;prePNG_float_prediction'
DISPLAY_SPEC = 'PIL RGB uint8 learned80 resized to400 with BICUBIC; display interpolation only'


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf8'))


def dump(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + '.tmp')
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf8')
    tmp.replace(path)


def below(root, relative):
    relative = Path(relative)
    assert not relative.is_absolute(), 'Paths in frozen records must be relative'
    result = (Path(root) / relative).resolve()
    result.relative_to(Path(root).resolve())
    return result


def load_selection(selection_path, run, data, root):
    """Metadata/byte checks precede opening any held-out image or model execution."""
    selected = read_json(selection_path)
    assert selected['version'] == 5 and selected['frozen'] is True
    assert selected['test_used_for_selection'] is False
    chosen = selected['checkpoint']
    assert chosen['model'] in ('swinir_classical_x4', 'swinir_real_psnr_x4')
    assert type(chosen['step']) is int and chosen['step'] >= 0
    checkpoint = below(run, chosen['file'])
    assert sha(checkpoint) == chosen['sha256'], 'Frozen checkpoint changed'
    config_path, complete_path = run / 'config.json', run / 'training_complete.json'
    assert sha(config_path) == selected['training_config_sha256']
    assert sha(complete_path) == selected['training_complete_sha256']
    cfg, complete = read_json(config_path), read_json(complete_path)
    assert complete['complete'] is True and complete['test_evaluated'] is False
    assert complete['steps'] == cfg['steps'] and complete['config_sha256'] == sha(config_path)
    assert cfg['smoke'] is False and cfg['scale'] == 4 and cfg['precision'] == 'float32'
    assert chosen['model'] == cfg['model'] and chosen['step'] <= cfg['steps']
    assert (run / f"validation_{chosen['step']}.json").is_file(), 'Chosen step was never validated'
    validation = read_json(run / f"validation_{chosen['step']}.json")
    assert validation['step'] == chosen['step'] and validation['split'] == 'val'
    assert validation['config_sha256'] == selected['training_config_sha256']
    assert sha(data / 'manifest.json') == cfg['data_manifest_sha256'] == selected['data_manifest_sha256']
    native_path = root / 'geometry_20260928/test_protocol.json'
    panel_path = root / 'research_v4_20260929/visual_panel_frozen.json'
    assert sha(native_path) == selected['native_protocol_sha256']
    assert sha(panel_path) == selected['visual_panel_sha256']
    native, panel = read_json(native_path), read_json(panel_path)
    ids = native['test_indices']
    assert len(ids) == len(set(ids)) == 8000 and all(type(i) is int and i >= 0 for i in ids)
    panels = sorted(set(native['display_indices']) | set(panel['native_ids']))
    assert len(panels) == 29 and selected['native_panel_ids'] == panels
    assert set(panels) <= set(ids) and len(native['display_indices']) == 5
    return selected, checkpoint, cfg, native, panels


@contextmanager
def output_lock(output):
    """OS lock releases on crash; a stale text PID cannot force duplicate work."""
    output.mkdir(parents=True, exist_ok=True)
    path = output / '.inference.lock'
    with path.open('a+b') as stream:
        if stream.tell() == 0:
            stream.write(b'0'); stream.flush()
        stream.seek(0)
        try:
            if os.name == 'nt':
                import msvcrt
                msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl
                fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError as error:
            raise RuntimeError('Another process owns this inference output') from error
        try:
            yield
        finally:
            stream.seek(0)
            if os.name == 'nt':
                msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                fcntl.flock(stream.fileno(), fcntl.LOCK_UN)


def tensor(array, device):
    if array.ndim == 2:
        array = array[:, :, None]
    return torch.from_numpy(array.copy()).permute(2, 0, 1)[None].to(device).float() / 255


def png(image):
    stream = BytesIO(); image.save(stream, format='PNG', compress_level=1)
    return stream.getvalue()


def output_images(pred):
    assert pred.shape == (1, 3, 80, 80) and torch.isfinite(pred).all()
    array = pred[0].clamp(0, 1).mul(255).round().byte().permute(1, 2, 0).cpu().numpy()
    image = Image.fromarray(array)
    return {'learned80': png(image), 'display400': png(image.resize((400, 400), Image.Resampling.BICUBIC))}


def payload_meta(payload, path, size):
    return {'path': str(path).replace('\\', '/'), 'sha256': hashlib.sha256(payload).hexdigest(),
            'bytes': len(payload), 'size': list(size), 'mode': 'RGB'}


def save_payload(path, payload):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == payload, f'Existing output differs: {path}'
    else:
        tmp = path.with_name(path.name + '.tmp'); tmp.write_bytes(payload); tmp.replace(path)


def verify_payload(payload, metadata, size):
    assert len(payload) == metadata['bytes'] and hashlib.sha256(payload).hexdigest() == metadata['sha256']
    assert metadata['size'] == list(size) and metadata['mode'] == 'RGB'
    with Image.open(BytesIO(payload)) as image:
        image.verify()
    with Image.open(BytesIO(payload)) as image:
        image.load(); assert image.size == tuple(size) and image.mode == 'RGB'


def aggregate(rows):
    groups = collections.defaultdict(list)
    for row in rows:
        assert all(math.isfinite(row[k]) for k in METRICS)
        groups[row['source_group']].append(row)
    means = {g: {k: float(np.mean([r[k] for r in values])) for k in METRICS} for g, values in groups.items()}
    return {'count': len(rows), 'groups': len(groups), 'group_means': means,
            'means': {k: float(np.mean([v[k] for v in means.values()])) for k in METRICS}, 'rows': rows}


class HeldoutData:
    def __init__(self, directory, expected_manifest):
        self.directory = Path(directory)
        assert sha(self.directory / 'manifest.json') == expected_manifest
        manifest = read_json(self.directory / 'manifest.json')
        self.rows = sorted((r for r in manifest['records'] if r['split'] == 'test' and
                            r['scale'] == 4 and r.get('synthetic') is False), key=lambda r: r['id'])
        assert len(self.rows) == len({r['id'] for r in self.rows}) == 78
        assert len({r['source_group'] for r in self.rows}) == 4
        assert all(r['input_size'] == [20, 20] and r['reference_size'] == [80, 80] for r in self.rows)
        other_groups = {r['source_group'] for r in manifest['records'] if r['split'] in ('train', 'val')}
        assert not (other_groups & {r['source_group'] for r in self.rows})

    def batch(self, row, regime, device):
        result = {}
        for key in ('hr', 'roi', 'valid', 'clean_lr', 'sensor_lr'):
            entry = row['files'][key]; path = below(self.directory, entry['path'])
            assert sha(path) == entry['sha256'], f'Changed heldout file: {path}'
            with Image.open(path) as image:
                mode = 'L' if key in ('roi', 'valid') else 'RGB'
                assert image.mode == mode and image.size == ((20, 20) if key.endswith('_lr') else (80, 80))
                result[key] = tensor(np.asarray(image), device)
        result['lr'] = result[regime + '_lr']
        return result


@torch.inference_mode()
def paired_test(model, data, metric, device, output, config, config_sha, deadline):
    report_path = output / 'paired_test.json'
    if report_path.exists():
        previous = read_json(report_path)
        assert previous['complete'] is True and previous['config_sha256'] == config_sha
        return True
    cases = [(r, regime) for r in data.rows for regime in ('clean', 'sensor')]
    work_path = output / 'paired_test_work.json'
    rows = []
    if work_path.exists():
        work = read_json(work_path); assert work['config_sha256'] == config_sha
        rows = work['rows']
        assert [(r['id'], r['regime']) for r in rows] == [(r['id'], reg) for r, reg in cases[:len(rows)]]
        for row in rows:
            for key, size in (('learned80', (80, 80)), ('display400', (400, 400))):
                entry = row['outputs'][key]
                verify_payload(below(output, entry['path']).read_bytes(), entry, size)
    for row, regime in cases[len(rows):]:
        if deadline():
            print('RESUMABLE_V5_PAIRED_TEST', len(rows), flush=True); return False
        batch = data.batch(row, regime, device); pred = model(batch['lr'])
        assert pred.shape == batch['hr'].shape and torch.isfinite(pred).all()
        roi = batch['roi'].clone() * batch['valid']
        roi[:, :, :4] = 0; roi[:, :, -4:] = 0; roi[:, :, :, :4] = 0; roi[:, :, :, -4:] = 0
        outputs = {}
        for key, payload in output_images(pred).items():
            rel = f"paired/{row['id']}/{regime}/{key}.png"
            save_payload(output / rel, payload)
            outputs[key] = payload_meta(payload, rel, (80, 80) if key == 'learned80' else (400, 400))
        rows.append({'id': row['id'], 'source_group': row['source_group'], 'regime': regime,
            'source_files': row['files'], 'outputs': outputs,
            **scores(pred, batch['hr'], batch['valid'], batch['roi'], 4),
            **structural(pred, batch['hr'], roi), 'lpips_roi': float(perception(metric, pred.clamp(0, 1), batch)),
            'same_operator_lr_mae': pil_consistency(pred, batch['clean_lr'])})
        dump(work_path, {'config_sha256': config_sha, 'rows': rows, 'partial': True})
        if len(rows) % 16 == 0:
            print('V5_PAIRED_TEST', len(rows), len(cases), flush=True)
    dump(report_path, {'complete': True, 'split': 'test', 'test_used_for_selection': False,
        'config_sha256': config_sha, 'selection_sha256': config['selection_sha256'],
        'data_manifest_sha256': config['data_manifest_sha256'], 'vgg_sha256': config['vgg_sha256'],
        'metric_spec': METRIC_SPEC, **aggregate(rows)})
    return True


def save_panel(output, index, input_array, payloads):
    values = dict(payloads)
    im = Image.fromarray(input_array)
    values['input20'] = png(im)
    values['input_nearest400'] = png(im.resize((400, 400), Image.Resampling.NEAREST))
    values['input_bicubic400'] = png(im.resize((400, 400), Image.Resampling.BICUBIC))
    entries = {}
    for key, body in values.items():
        rel = f'panel/{index}/{key}.png'; save_payload(output / rel, body)
        side = 20 if key == 'input20' else (80 if key == 'learned80' else 400)
        entries[key] = payload_meta(body, rel, (side, side))
    return {'index': index, 'files': entries}


@torch.inference_mode()
def native_shard(model, pixels, selected, number, output, panel_ids, config_sha, device, deadline):
    archive = output / f'shard_{number:03d}.tar'; meta_path = archive.with_suffix('.json')
    if meta_path.exists():
        meta = read_json(meta_path)
        assert meta['config_sha256'] == config_sha and meta['indices'] == selected
        assert sha(archive) == meta['tar_sha256']
        return meta
    stage = output / '.inprogress' / f'shard_{number:03d}'; stage.mkdir(parents=True, exist_ok=True)
    work = stage / 'rows.json'; rows = []
    if work.exists():
        prior = read_json(work); assert prior['config_sha256'] == config_sha
        rows = prior['rows']; assert [r['index'] for r in rows] == selected[:len(rows)]
        for row in rows:
            for key, size in (('learned80', (80, 80)), ('display400', (400, 400))):
                item = row['files'][key]; verify_payload(below(stage, item['path']).read_bytes(), item, size)
    for index in selected[len(rows):]:
        if deadline():
            print('RESUMABLE_V5_NATIVE', number, len(rows), flush=True); return None
        raw = pixels[index]; pred = model(tensor(raw, device)); payloads = output_images(pred)
        files = {}
        for key, body in payloads.items():
            rel = f'{index}/{key}.png'; save_payload(stage / rel, body)
            files[key] = payload_meta(body, rel, (80, 80) if key == 'learned80' else (400, 400))
        row = {'index': index, 'input_pixels_sha256': hashlib.sha256(raw.tobytes()).hexdigest(), 'files': files}
        if index in panel_ids:
            row['panel'] = save_panel(output, index, raw, payloads)
        rows.append(row); dump(work, {'config_sha256': config_sha, 'rows': rows})
    tmp = archive.with_name(archive.name + '.tmp')
    with tarfile.open(tmp, 'w') as tar:
        for row in rows:
            for key in ('learned80', 'display400'):
                entry = row['files'][key]; body = below(stage, entry['path']).read_bytes()
                info = tarfile.TarInfo(entry['path']); info.size = len(body); info.mtime = 0
                tar.addfile(info, BytesIO(body))
    tmp.replace(archive)
    meta = {'config_sha256': config_sha, 'number': number, 'indices': selected, 'rows': rows,
            'tar_sha256': sha(archive), 'display_spec': DISPLAY_SPEC}
    dump(meta_path, meta)
    # Delete only explicitly verified files in this task's completed staging directory.
    # The archive and manifest were atomically committed before this optional cleanup.
    for row in rows:
        for entry in row['files'].values():
            below(stage, entry['path']).unlink()
        below(stage, str(row['index'])).rmdir()
    work.unlink(); stage.rmdir()
    print('V5_NATIVE_SHARD', number, len(selected), flush=True)
    return meta


def main(args):
    import cv2
    cv2.setNumThreads(2); torch.set_num_threads(4)
    start = time.monotonic()
    assert sha(args.selection) == args.selection_sha256, 'Selection bytes differ from separately frozen identity'
    selected, checkpoint, training, native, panel_ids = load_selection(args.selection, args.run, args.data, args.root)
    assert args.device != 'cuda' or torch.cuda.is_available()
    source = args.root / 'planesnet_20260921/inputs.npy'
    assert sha(source) == native['planesnet_npy_sha256']
    pixels = np.load(source, allow_pickle=False, mmap_mode='r')
    assert pixels.dtype == np.uint8 and pixels.ndim == 4 and pixels.shape[1:] == (20, 20, 3)
    assert max(native['test_indices']) < len(pixels)
    for name, digest in training['code_sha256'].items():
        assert sha(Path(__file__).parent / name) == digest, f'Training metric/model helper changed: {name}'
    state = torch.load(checkpoint, map_location='cpu', weights_only=False)
    assert state['config'] == training and state['step'] == selected['checkpoint']['step']
    model = SwinIRBaseline(selected['checkpoint']['model'], args.assets, args.device)
    assert model.source_receipt == training['source_receipt']
    model.load_state_dict(state['model'], strict=True); model.eval(); del state
    if torch.cuda.is_available():
        torch.backends.cuda.matmul.allow_tf32 = False; torch.backends.cudnn.allow_tf32 = False
        torch.backends.cudnn.benchmark = False; torch.backends.cudnn.deterministic = True
    cfg = {'version': 5, 'selection_sha256': sha(args.selection), 'selection': selected,
           'data_manifest_sha256': selected['data_manifest_sha256'], 'vgg_sha256': training['vgg_sha256'],
           'checkpoint': selected['checkpoint'], 'input_array_sha256': sha(source), 'native_count': 8000,
           'native_panel_ids': panel_ids, 'paired_pairs': 78, 'paired_cases': 156,
           'input_size': [20, 20], 'learned_size': [80, 80], 'display_size': [400, 400],
           'display_spec': DISPLAY_SPEC, 'metric_spec': METRIC_SPEC, 'precision': 'float32',
           'test_used_for_selection': False, 'inference': 'FP32 single forward; no TTA; no HR conditioning',
           'code_sha256': sha(Path(__file__)), 'torch': torch.__version__, 'pillow': Image.__version__}
    with output_lock(args.output):
        config_path = args.output / 'config.json'
        if config_path.exists():
            assert read_json(config_path) == cfg, 'Frozen inference identity changed; never reuse this output'
        else:
            dump(config_path, cfg); dump(args.output / 'selection.json', selected)
        config_sha = sha(config_path)
        if (args.output / 'completion.json').exists():
            complete = read_json(args.output / 'completion.json')
            assert complete['complete'] is True and complete['config_sha256'] == config_sha
            print('V5_INFERENCE_ALREADY_COMPLETE; independent audit still required', flush=True); return
        def deadline():
            return time.monotonic() - start >= args.max_seconds or time.time() >= float(os.environ.get('SLURM_JOB_END_TIME', 'inf')) - 120
        if not (args.output / 'paired_test.json').exists():
            import lpips
            backbone = Path(torch.hub.get_dir()) / 'checkpoints/vgg16-397923af.pth'
            assert backbone.is_file() and sha(backbone) == training['vgg_sha256'], 'Stage exact VGG; no download'
            metric = lpips.LPIPS(net='vgg').to(args.device).eval().requires_grad_(False)
            data = HeldoutData(args.data, selected['data_manifest_sha256'])
            if not paired_test(model, data, metric, args.device, args.output, cfg, config_sha, deadline):
                return
            del data, metric
        else:
            prior = read_json(args.output / 'paired_test.json')
            assert prior['complete'] is True and prior['config_sha256'] == config_sha and prior['count'] == 156
        panel_rows, seen, manifests = [], [], []
        for number in range(40):
            ids = native['test_indices'][number * 200:(number + 1) * 200]
            meta = native_shard(model, pixels, ids, number, args.output, set(panel_ids), config_sha, args.device, deadline)
            if meta is None:
                return
            seen.extend(meta['indices']); panel_rows.extend(r['panel'] for r in meta['rows'] if 'panel' in r)
            manifests.append({'number': number, 'sha256': sha(args.output / f'shard_{number:03d}.json')})
        assert seen == native['test_indices']
        panel_rows.sort(key=lambda r: r['index']); assert [r['index'] for r in panel_rows] == panel_ids
        dump(args.output / 'panel.json', {'config_sha256': config_sha, 'rows': panel_rows, 'native_no_hr': True})
        dump(args.output / 'completion.json', {'complete': True, 'config_sha256': config_sha,
            'selection_sha256': cfg['selection_sha256'], 'native_images': 8000, 'native_pngs': 16000,
            'paired_test_sha256': sha(args.output / 'paired_test.json'), 'panel_sha256': sha(args.output / 'panel.json'),
            'shard_manifests': manifests, 'independent_audit_required': True,
            'note': 'Completion is coverage, not evidence of improved quality; native images have no HR truth.'})
        print('V5_INFERENCE_COMPLETE; independent audit required', flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    for key in ('selection', 'run', 'data', 'root', 'assets', 'output'):
        parser.add_argument('--' + key, required=True, type=Path)
    parser.add_argument('--selection-sha256', required=True)
    parser.add_argument('--device', choices=('cuda', 'cpu'), default='cuda')
    parser.add_argument('--max-seconds', type=float, default=100000)
    main(parser.parse_args())
