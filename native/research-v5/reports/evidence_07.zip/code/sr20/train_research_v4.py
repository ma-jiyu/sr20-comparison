"""Long-budget paired aircraft adaptation, with two validation objectives and exact state resume."""
import argparse
import collections
import hashlib
import json
import math
import os
from pathlib import Path
import random
import time
import numpy as np
import torch
from torch.nn import functional as F
from .research_v4_models import Reconstruction20, Official20, GROUPS
from .research_v4_data import PairedData
from .train_matched import dump, sha, masked
from .train_reduction_v2 import FlexibleSR, scores
from .train_expansion_v3 import structural

def plane_crop(t,roi):
    nz=torch.nonzero(roi[0,0]>.5)
    if not len(nz):return F.interpolate(t,(224,224),mode='bilinear',align_corners=False)
    lo=nz.min(0).values;hi=nz.max(0).values+1
    side=min(max(t.shape[-2:]),max(64,int((hi-lo).max().item()*1.1)))
    cy,cx=((lo+hi)//2).tolist();y=max(0,min(cy-side//2,t.shape[-2]-side));x=max(0,min(cx-side//2,t.shape[-1]-side))
    return F.interpolate(t[:,:,y:y+side,x:x+side],(224,224),mode='bilinear',align_corners=False)

def perception(metric,p,b):
    return metric(plane_crop(p,b['roi'])*2-1,plane_crop(b['hr'],b['roi'])*2-1).mean()

def losses(pred,b,metric,perceptual_weight):
    mask=1+2*b['roi'];rec=masked((pred-b['hr']).abs(),mask).mean()
    dx=(pred[:,:,:,1:]-pred[:,:,:,:-1])-(b['hr'][:,:,:,1:]-b['hr'][:,:,:,:-1])
    dy=(pred[:,:,1:]-pred[:,:,:-1])-(b['hr'][:,:,1:]-b['hr'][:,:,:-1])
    edge=(masked(dx.abs(),mask[:,:,:,1:])+masked(dy.abs(),mask[:,:,1:])).mean()/2
    consistency=F.l1_loss(F.interpolate(pred,b['lr'].shape[-2:],mode='bicubic',align_corners=False,antialias=True),b['clean_lr'])
    percept=perception(metric,pred.clamp(0,1),b) if perceptual_weight else rec.new_zeros(())
    loss=rec+.05*edge+.05*consistency+perceptual_weight*percept
    return loss,{'l1':float(rec.detach()),'edge':float(edge.detach()),'consistency':float(consistency.detach()),'lpips':float(percept.detach())}

@torch.no_grad()
def evaluate(model,data,metric,split='val'):
    model.eval();rows=[]
    for r in data.splits[split]:
        for regime in ('clean','sensor'):
            b=data.batch(r,regime=regime)
            torch.manual_seed(int(hashlib.sha256((r['id']+regime).encode()).hexdigest()[:8],16))
            p=model(b['lr']);assert torch.isfinite(p).all()
            valid=torch.ones_like(b['roi']);roi=b['roi'].clone()
            roi[:,:,:20]=0;roi[:,:,-20:]=0;roi[:,:,:,:20]=0;roi[:,:,:,-20:]=0
            value={'id':r['id'],'source_group':r['source_group'],'regime':regime,
                   **scores(p,b['hr'],valid,b['roi'],20),**structural(p,b['hr'],roi),
                   'lpips_roi':float(perception(metric,p.clamp(0,1),b)),
                   'lowfreq_mae':float(F.l1_loss(F.interpolate(p.clamp(0,1),b['lr'].shape[-2:],mode='area'),b['clean_lr']))}
            rows.append(value)
    groups=collections.defaultdict(list)
    for r in rows:groups[r['source_group']].append(r)
    keys=('full','roi','ssim_roi','edge_mae','lpips_roi','lowfreq_mae')
    means={g:{k:float(np.mean([r[k] for r in rs])) for k in keys} for g,rs in groups.items()}
    return {'count':len(rows),'groups':len(means),'group_means':means,
            'means':{k:float(np.mean([m[k] for m in means.values()])) for k in keys},'rows':rows}

def eligible(val,anchor,guard):
    v,a=val['means'],anchor['means']
    return (v['roi']>=a['roi']-guard['roi_psnr_drop_db'] and
            v['ssim_roi']>=a['ssim_roi']-guard['ssim_drop'] and
            v['edge_mae']<=a['edge_mae']*guard['edge_ratio'] and
            v['lowfreq_mae']<=a['lowfreq_mae']*guard['lowfreq_ratio'])

def lr_and_perceptual(arm,step):
    if arm.startswith('B'):
        if step<20000:
            lr=1e-5+.5*(1e-4-1e-5)*(1+math.cos(math.pi*step/20000))
            return lr*min(1,(step+1)/500),0.
        s=(step-20000)/10000
        return 2e-6+.5*1.8e-5*(1+math.cos(math.pi*s)),.10
    lr=2e-7+.5*1.8e-6*(1+math.cos(math.pi*step/10000))
    return lr*min(1,(step+1)/200),.2*min(1,step/500)

def main(a):
    import cv2
    import lpips
    cv2.setNumThreads(2);torch.set_num_threads(4)
    torch.manual_seed(940);np.random.seed(940);random.seed(940)
    a.run.mkdir(parents=True,exist_ok=True)
    protocol=json.loads(a.protocol.read_text());data=PairedData(a.data,a.protocol)
    # Actual pretrained VGG is required; no silent download or random fallback.
    backbone=Path(torch.hub.get_dir())/'checkpoints/vgg16-397923af.pth'
    assert backbone.exists(),str(backbone)
    metric=lpips.LPIPS(net='vgg').cuda().eval().requires_grad_(False)
    model=(Reconstruction20(a.weight).cuda() if a.arm.startswith('B') else Official20(a.official))
    params=[p for p in model.parameters() if p.requires_grad]
    optimizer=torch.optim.AdamW(params,lr=1e-5,weight_decay=.01)
    steps=30000 if a.arm.startswith('B') else 10000
    config={'arm':a.arm,'steps':steps,'effective_batch':4,'initial_seed':940,
            'protocol_sha256':sha(a.protocol),'dataset_sha256':protocol['data_manifest_sha256'],
            'initial_sha256':sha(a.weight if a.arm.startswith('B') else a.official/'weights/casr.pkl'),
            'vgg_sha256':sha(backbone),'trainable_parameters':sum(p.numel() for p in params),
            'code_sha256':{name:sha(Path(__file__).parent/name) for name in
                           ('train_research_v4.py','research_v4_models.py','research_v4_data.py','prepare_reduction_v2.py')},
            'smoke':a.smoke,'precision':'float32','architecture': 'RRDB23blocks20x' if a.arm.startswith('B') else 'CASR-full-field-direct20-adaptation'}
    cfgfile=a.run/'config.json'
    if cfgfile.exists():assert json.loads(cfgfile.read_text())==config,'Config changed across resume'
    else:dump(cfgfile,config)
    if a.smoke:
        audit=[]
        for n in (12,20,40):
            r=next(r for r in data.splits['train'] if r['input_size']==[n,n])
            b=data.batch(r,serial=100+n)
            torch.manual_seed(940+n);optimizer.zero_grad(set_to_none=True)
            start=time.monotonic();p=model(b['lr']);assert p.shape==b['hr'].shape
            loss,components=losses(p,b,metric,.1);assert torch.isfinite(loss)
            loss.backward();norm=torch.nn.utils.clip_grad_norm_(params,1,error_if_nonfinite=True)
            assert norm>0
            if a.arm.startswith('C'):
                module_norms={k:sum(float(p.grad.square().sum()) for p in getattr(model.net,k).parameters() if p.grad is not None)**.5 for k in GROUPS}
                assert all(v>0 and math.isfinite(v) for v in module_norms.values())
            else:module_norms={'up3':float(model.conv_up3.weight.grad.norm())}
            optimizer.step();audit.append({'n':n,'shape':list(p.shape),'loss':float(loss.detach()),'components':components,'gradient_norm':float(norm),'module_norms':module_norms,'seconds':time.monotonic()-start})
            print('SMOKE',json.dumps(audit[-1]),flush=True)
        # Same-state export/load parity on native20. This does not yet claim resumed optimizer parity.
        r=next(r for r in data.splits['train'] if r['input_size']==[20,20]);b=data.batch(r,regime='sensor')
        with torch.no_grad():
            torch.manual_seed(946);before=model(b['lr']);state=model.export();model.restore(state)
            torch.manual_seed(946);after=model(b['lr']);error=float((after-before).abs().max());assert error<1e-6
        dump(a.run/'smoke_complete.json',{'complete':True,'cases':audit,'state_restore_max_error':error,'gpu':torch.cuda.get_device_name(),'peak_gpu_gib':torch.cuda.max_memory_allocated()/2**30})
        print('V4_SMOKE_COMPLETE',a.arm,flush=True);return
    start=0;best_f=-1e10;best_p=1e10;selected={'fidelity':None,'perceptual':None};validated_step=-1
    def save_last(step):
        state={'model':model.export(),'optimizer':optimizer.state_dict(),'step':step,'best_f':best_f,'best_p':best_p,'selected':selected,'validated_step':validated_step,
               'torch_rng':torch.get_rng_state(),'cuda_rng':torch.cuda.get_rng_state_all(),'numpy_rng':np.random.get_state(),'python_rng':random.getstate(),'config':config}
        tmp=a.run/'last.pt.tmp';torch.save(state,tmp);tmp.replace(a.run/'last.pt')
        dump(a.run/'state.json',{'step':step,'steps':steps,'selected':selected})
    def export(step,name):
        tmp=a.run/(name+'.tmp');torch.save({'model':model.export(),'step':step,'config':config},tmp);tmp.replace(a.run/name)
    if (a.run/'last.pt').exists():
        state=torch.load(a.run/'last.pt',map_location='cpu',weights_only=False);assert state['config']==config
        model.restore(state['model']);optimizer.load_state_dict(state['optimizer']);start=state['step'];best_f=state['best_f'];best_p=state['best_p'];selected=state['selected'];validated_step=state['validated_step']
        torch.set_rng_state(state['torch_rng']);torch.cuda.set_rng_state_all(state['cuda_rng']);np.random.set_state(state['numpy_rng']);random.setstate(state['python_rng']);del state
    anchor_path=a.run/'old_anchor_validation.json'
    if not anchor_path.exists():
        saved=torch.load(a.old,map_location='cpu',weights_only=True);old=FlexibleSR(**saved['model_config']).cuda();old.load_state_dict(saved['model']);dump(anchor_path,evaluate(old,data,metric));del old,saved;torch.cuda.empty_cache()
    anchor=json.loads(anchor_path.read_text())
    def validate(step):
        nonlocal best_f,best_p,validated_step
        val=evaluate(model,data,metric);val['step']=step;val['perceptual_eligible']=eligible(val,anchor,protocol['perceptual_guard']);dump(a.run/f'validation_{step}.json',val)
        if val['means']['roi']>best_f:
            best_f=val['means']['roi'];selected['fidelity']=step;export(step,'best_fidelity.pt')
        if val['perceptual_eligible'] and val['means']['lpips_roi']<best_p:
            best_p=val['means']['lpips_roi'];selected['perceptual']=step;export(step,'best_perceptual.pt')
        validated_step=step
        print('VALIDATION',step,json.dumps(val['means']),val['perceptual_eligible'],flush=True)
        # A safety stop is recorded and never disguised as a converged or complete run.
        if step>=3000 and val['means']['roi']<anchor['means']['roi']-2 and val['means']['lpips_roi']>anchor['means']['lpips_roi']*1.25:
            dump(a.run/'needs_review.json',{'reason':'large simultaneous fidelity/perceptual regression','step':step});save_last(step);raise RuntimeError('V4 validation regression requires review')
    begin=time.monotonic()
    if start==0 and not (a.run/'last.pt').exists():validate(0);save_last(0)
    elif start%1000==0 and validated_step<start:validate(start);save_last(start)
    # Validation/export can take minutes; preserve a resumable checkpoint before starting another update.
    def near_deadline():return time.time()>float(os.environ.get('SLURM_JOB_END_TIME','inf'))-180 or time.monotonic()-begin>a.max_seconds
    with (a.run/'progress.jsonl').open('a',encoding='utf8') as log:
        for step in range(start,steps):
            if near_deadline():save_last(step);print('RESUMABLE_TIME_SLICE',step,flush=True);return
            model.train();optimizer.zero_grad(set_to_none=True);total=0.;lr,pw=lr_and_perceptual(a.arm,step)
            for group in optimizer.param_groups:group['lr']=lr
            tick=time.monotonic()
            for j in range(4):
                serial=step*4+j;r=data.choose(serial,a.arm.endswith('mix'));b=data.batch(r,serial=serial)
                torch.manual_seed(945000000+serial);pred=model(b['lr']);loss,components=losses(pred,b,metric,pw);assert torch.isfinite(loss)
                (loss/4).backward();total+=float(loss.detach())/4
            grad=torch.nn.utils.clip_grad_norm_(params,1,error_if_nonfinite=True);optimizer.step()
            row={'step':step+1,'loss':total,'grad':float(grad),'lr':lr,'perceptual_weight':pw,'seconds':time.monotonic()-tick};log.write(json.dumps(row)+'\n');log.flush()
            if (step+1)%25==0:print(json.dumps(row),flush=True)
            if (step+1)%100==0:save_last(step+1)
            if (step+1)%1000==0:
                # A periodic checkpoint precedes potentially lengthy validation.
                validate(step+1);save_last(step+1)
        export(steps,'final.pt');save_last(steps)
    dump(a.run/'training_complete.json',{'complete':True,'steps':steps,'selected':selected,'note':'Training complete; final test/native inference and visual review still required'})
    print('V4_TRAIN_COMPLETE',a.arm,flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser()
    for n in ('data','protocol','run','weight','official','old'):p.add_argument('--'+n,type=Path,required=True)
    p.add_argument('--arm',choices=['B_real','B_mix','C_real','C_mix'],required=True)
    p.add_argument('--smoke',action='store_true')
    p.add_argument('--max-seconds',type=float,default=100000)
    main(p.parse_args())
