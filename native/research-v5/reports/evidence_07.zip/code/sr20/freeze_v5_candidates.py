"""Freeze two explicit V5 scientific comparison candidates before any test run.

The only policy is the already frozen lowest guard-eligible validation LPIPS
checkpoint, including step0 eligibility. No alternate checkpoint or model is
silently substituted if the actual final-checkpoint visual review fails.
"""
import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import tempfile

import torch

from .infer_v5_swinir import load_selection, output_lock, read_json, sha
from .audit_v5_swinir import recompute


ARMS = {'classical': 'swinir_classical_x4', 'realpsnr': 'swinir_real_psnr_x4'}
GUARD = {'roi_psnr_drop_db': .15, 'ssim_drop': .01, 'edge_ratio': 1.10}
PROTOCOL_GUARD = {'roi_drop_db_max': .15, 'ssim_drop_max': .01, 'edge_ratio_max': 1.10}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + '\n').encode('utf8')


def assert_no_test(task):
    # Metadata scan only. Even partial evaluator cursors mean the test has begun.
    found = sorted(str(p.relative_to(task)) for p in task.rglob('paired_test*.json'))
    require(not found, 'Refusing a pre-test freeze after paired test artifacts exist: ' + ', '.join(found[:8]))


def check_visual(path):
    review = read_json(path)
    require(review.get('completed') is True, 'Actual final-checkpoint visual review is incomplete')
    require(review.get('blind_review') is False, 'This review must explicitly disclose that labels were visible')
    require(review.get('test_images_read') is False and review.get('test_used_for_selection') is False,
            'Visual selection must use validation and fixed native panels only')
    for arm in ARMS:
        item = review.get('methods', {}).get(arm, {})
        require(item.get('reviewed') is True and item.get('validation_reviewed') is True and item.get('native_reviewed') is True,
                f'{arm}: actual final validation and native visual review is required')
        require(isinstance(item.get('notes'), str) and bool(item['notes'].strip()), f'{arm}: observed visual notes are absent')
        require(item.get('no_obvious_new_grid_or_shape_collapse') is True,
                f'{arm}: VISUAL GATE FAILED or unreviewed: new grid artifacts / shape collapse; no fallback and neither candidate will be frozen')
        require(isinstance(item.get('checkpoint_sha256'), str) and len(item['checkpoint_sha256']) == 64,
                f'{arm}: visual review must identify the exact final selected checkpoint SHA256')
    return review


def check_protocol(config, protocol, protocol_path, model, manifest_sha):
    require(config['protocol_sha256'] == sha(protocol_path), f'{model}: training protocol bytes changed')
    expected = {'model': model, 'steps': 6000, 'reconstruction_steps': 4000, 'effective_batch': 8,
                'microbatch': 4, 'seed': 1005, 'scale': 4, 'data_manifest_sha256': manifest_sha}
    for key, value in expected.items():
        require(config[key] == protocol[key] == value, f'{model}: frozen {key} mismatch')
    require(protocol['validation_interval'] == 500 and protocol['test_used_for_selection'] is False,
            f'{model}: invalid validation/test policy')
    require(config['candidate_guard'] == GUARD and protocol['candidate_guard'] == PROTOCOL_GUARD,
            f'{model}: candidate gates differ from the prospective freeze')
    require(config['candidate_anchor'] == 'step0 on same new real validation', f'{model}: different validation anchor')
    require(config['smoke'] is False and config['precision'] == 'float32', f'{model}: smoke or other precision run')
    require({'train_v5_swinir.py', 'v5_baselines.py', 'train_research_v4.py', 'train_reduction_v2.py',
             'train_expansion_v3.py', 'train_matched.py', 'prepare_reduction_v2.py', 'diagnose_v5_perceptual.py'} <= set(config['code_sha256']),
            f'{model}: training/metric code identity record is incomplete')
    for name, digest in config['code_sha256'].items():
        require(sha(Path(__file__).parent / name) == digest, f'{model}: training/helper code changed: {name}')


def structural_gate(value, anchor):
    values = {
        'roi_psnr_drop_db': anchor['roi'] - value['roi'],
        'ssim_drop': anchor['ssim_roi'] - value['ssim_roi'],
        'edge_mae': value['edge_mae'],
    }
    checks = {
        'roi': value['roi'] >= anchor['roi'] - .15,
        'ssim': value['ssim_roi'] >= anchor['ssim_roi'] - .01,
        'edge': value['edge_mae'] <= anchor['edge_mae'] * 1.10,
    }
    return all(checks.values()), {'passed': all(checks.values()), 'checks': checks,
        'observed': values, 'limits': {'roi_psnr_drop_db': .15, 'ssim_drop': .01, 'edge_mae': anchor['edge_mae'] * 1.10}}


def inspect_arm(arm, model, task, manifest_sha, validation_identities, review):
    run = task / 'training' / model
    cfg_path, done_path = run / 'config.json', run / 'training_complete.json'
    cfg, done = read_json(cfg_path), read_json(done_path)
    cfg_sha = sha(cfg_path)
    require(done['complete'] is True and done['steps'] == 6000 and done['config_sha256'] == cfg_sha,
            f'{arm}: full6000 training is not complete under this config')
    require(done['test_evaluated'] is False, f'{arm}: test was already evaluated')
    protocol_path = task / f'{model}_training_protocol.json'; protocol = read_json(protocol_path)
    check_protocol(cfg, protocol, protocol_path, model, manifest_sha)
    require(cfg['train_pairs'] == 385 and cfg['train_groups'] == 20 and cfg['validation_pairs'] == 61 and cfg['validation_groups'] == 4,
            f'{arm}: data count differs from frozen real-aircraft pilot')
    # Check the exported final state, not only the completion marker.
    final_path = run / 'final.pt'
    final = torch.load(final_path, map_location='cpu', weights_only=True)
    require(final['step'] == 6000 and final['config'] == cfg and isinstance(final['model'], dict) and bool(final['model']),
            f'{arm}: final.pt is not the complete frozen6000 state')
    state_keys = set(final['model']); del final
    history = []; anchor = None
    best_step, best_lpips, fidelity_step, best_roi = None, float('inf'), None, -float('inf')
    for step in range(0, 6001, 500):
        path = run / f'validation_{step}.json'; value = read_json(path)
        require(value['step'] == step and value['split'] == 'val' and value['config_sha256'] == cfg_sha,
                f'{arm}: inconsistent validation record at step{step}')
        group = recompute(value)
        require(value['count'] == 122 and value['groups'] == 4 and group['identities'] == validation_identities,
                f'{arm}: validation IDs or source groups changed at step{step}')
        if step == 0:
            anchor = group['means']
        passed, details = structural_gate(group['means'], anchor)
        require(value['perceptual_eligible'] is passed, f'{arm}: recorded guard eligibility is wrong at step{step}')
        if passed and group['means']['lpips_roi'] < best_lpips:
            best_step, best_lpips = step, group['means']['lpips_roi']
        if group['means']['roi'] > best_roi:
            fidelity_step, best_roi = step, group['means']['roi']
        history.append({'step': step, 'sha256': sha(path), 'means': group['means'], 'gate': details})
    require(best_step is not None, f'{arm}: no guard-eligible checkpoint; no fallback')
    require(done['selected']['perceptual'] == best_step and done['selected']['fidelity'] == fidelity_step,
            f'{arm}: training-selected policy differs from independent grouped validation reconstruction')
    chosen_path = run / 'best_perceptual.pt'
    chosen_sha = sha(chosen_path)
    chosen = torch.load(chosen_path, map_location='cpu', weights_only=True)
    require(chosen['step'] == best_step and chosen['config'] == cfg and set(chosen['model']) == state_keys,
            f'{arm}: best_perceptual.pt is not the exact frozen policy checkpoint')
    require(all(torch.is_tensor(v) and torch.isfinite(v).all().item() for v in chosen['model'].values()),
            f'{arm}: checkpoint contains invalid tensors')
    del chosen
    require(review['methods'][arm]['checkpoint_sha256'] == chosen_sha,
            f'{arm}: visual observations refer to different weight bytes; final candidate must actually be viewed')
    selected_validation = next(value for value in history if value['step'] == best_step)
    require(selected_validation['gate']['passed'], f'{arm}: selected checkpoint violates structural validation gate')
    return {'arm': arm, 'model': model, 'run': run, 'checkpoint_sha256': chosen_sha, 'step': best_step,
        'training_config_sha256': cfg_sha, 'training_complete_sha256': sha(done_path),
        'training_protocol_sha256': sha(protocol_path), 'final6000_sha256': sha(final_path),
        'validation': selected_validation, 'anchor': anchor, 'validation_history': history,
        'visual': review['methods'][arm], 'vgg_sha256': cfg['vgg_sha256']}


def main(args):
    args.root, args.task = args.root.resolve(), args.task.resolve()
    require(args.task.is_dir(), 'Task directory does not exist')
    with output_lock(args.task / '.candidate_freeze_lock'):
        assert_no_test(args.task)
        review = check_visual(args.visual_review)
        review_sha = sha(args.visual_review)
        data = args.task / 'rareplanes/data'; manifest_path = data / 'manifest.json'
        manifest_sha = sha(manifest_path); manifest = read_json(manifest_path)
        # Metadata only: no file named by a test record is opened.
        val = [r for r in manifest['records'] if r['split'] == 'val' and r['scale'] == 4 and r.get('synthetic') is False]
        train = [r for r in manifest['records'] if r['split'] == 'train' and r['scale'] == 4 and r.get('synthetic') is False]
        require(len(val) == 61 and len({r['source_group'] for r in val}) == 4, 'Unexpected frozen validation population')
        require(len(train) == 385 and len({r['source_group'] for r in train}) == 20, 'Unexpected frozen training population')
        require(not ({r['source_group'] for r in train} & {r['source_group'] for r in val}), 'Training/validation location overlap')
        require(len({r['id'] for r in train + val}) == len(train) + len(val), 'Duplicate training/validation identity')
        identities = sorted((r['id'], r['source_group'], regime) for r in val for regime in ('clean', 'sensor'))
        native_path = args.root / 'geometry_20260928/test_protocol.json'
        panel_path = args.root / 'research_v4_20260929/visual_panel_frozen.json'
        native, panel = read_json(native_path), read_json(panel_path)
        panel_ids = sorted(set(native['display_indices']) | set(panel['native_ids']))
        require(len(panel_ids) == 29, 'Original fixed29 panel identity changed')
        inspected = {arm: inspect_arm(arm, model, args.task, manifest_sha, identities, review) for arm, model in ARMS.items()}
        require(len({v['vgg_sha256'] for v in inspected.values()}) == 1, 'Arms used different VGG metrics')
        files = {'classical': args.task / 'selection_classical.json', 'realpsnr': args.task / 'selection_realpsnr.json'}
        joint_path = args.task / 'joint_candidate_freeze.json'
        existing = [read_json(path) for path in [*files.values(), joint_path] if path.exists()]
        prior_times = {value.get('frozen_at_utc') for value in existing}
        require(not existing or (len(prior_times) == 1 and None not in prior_times), 'Existing freeze files disagree on their timestamp')
        timestamp = next(iter(prior_times)) if existing else datetime.now(timezone.utc).isoformat()
        recorded = datetime.fromisoformat(timestamp)
        require(recorded.tzinfo is not None and recorded <= datetime.now(timezone.utc), 'Invalid or future freeze timestamp')
        payloads = {}
        for arm, item in inspected.items():
            payloads[arm] = {
                'version': 5, 'frozen': True, 'frozen_at_utc': timestamp, 'test_used_for_selection': False,
                'checkpoint': {'file': 'best_perceptual.pt', 'sha256': item['checkpoint_sha256'], 'model': item['model'], 'step': item['step']},
                'training_config_sha256': item['training_config_sha256'], 'training_complete_sha256': item['training_complete_sha256'],
                'training_protocol_sha256': item['training_protocol_sha256'], 'data_manifest_sha256': manifest_sha,
                'native_protocol_sha256': sha(native_path), 'visual_panel_sha256': sha(panel_path), 'native_panel_ids': panel_ids,
                'visual_review_sha256': review_sha, 'visual_gate': item['visual'],
                'selected_validation_sha256': item['validation']['sha256'], 'validation_gate': item['validation']['gate'],
                'selection_policy': 'Lowest guard-eligible source-group-macro validation LPIPS across step0,500,...,6000; ties keep earliest; no fallback',
                'role': 'Final scientific comparison candidate; does not replace the default model',
                'limitations': '61 validation aircraft in4 locations; official coarse diamond ROI; label-visible visual review; native panel has no HR truth. Selection and observations are not proof of general native detail recovery.',
            }
        # Validate both complete selection payloads using the inference entry's
        # metadata gate before committing either public selection file.
        with tempfile.TemporaryDirectory(prefix='freeze_check_', dir=args.task) as directory:
            Path(directory).resolve().relative_to(args.task)
            for arm, payload in payloads.items():
                path = Path(directory) / f'{arm}.json'; path.write_bytes(encoded(payload))
                load_selection(path, inspected[arm]['run'], data, args.root)
        candidates = [{'arm': arm, 'file': files[arm].name, 'sha256': hashlib.sha256(encoded(payloads[arm])).hexdigest(),
                       'checkpoint': payloads[arm]['checkpoint'], 'training_final6000_sha256': inspected[arm]['final6000_sha256'],
                       'validation_anchor': inspected[arm]['anchor'], 'selected_validation': inspected[arm]['validation'],
                       'validation_history': inspected[arm]['validation_history']} for arm in ARMS]
        joint = {'version': 5, 'frozen': True, 'frozen_at_utc': timestamp, 'pre_test_scan_passed': True,
            'test_images_read': False, 'test_used_for_selection': False, 'default_model_replaced': False,
            'visual_review_sha256': review_sha, 'data_manifest_sha256': manifest_sha, 'candidates': candidates,
            'freeze_code_sha256': sha(Path(__file__)),
            'scope': 'Both training runs completed6000 updates. Two explicit validation+actual-visual candidates are frozen for scientific comparison. Test may only describe these candidates; it must not retrospectively choose or tune a candidate.',
            'sample_limit': {'training_aircraft': 385, 'training_locations': 20, 'validation_aircraft': 61, 'validation_locations': 4,
                             'native_panel_count': 29, 'native_hr_truth_available': False, 'blind_visual_review': False}}
        planned = [(files[arm], encoded(payloads[arm])) for arm in ARMS] + [(joint_path, encoded(joint))]
        for path, body in planned:
            require(not path.exists() or path.read_bytes() == body, f'Existing freeze differs; refusing overwrite: {path}')
        assert_no_test(args.task)
        for path, body in planned:
            if not path.exists():
                temporary = path.with_name(path.name + '.tmp'); temporary.write_bytes(body); temporary.replace(path)
        print('V5_JOINT_CANDIDATES_FROZEN', json.dumps({'frozen_at_utc': timestamp,
            'selections': {arm: {'path': str(files[arm]), 'sha256': sha(files[arm]), 'checkpoint_step': inspected[arm]['step']} for arm in ARMS},
            'joint_sha256': sha(joint_path), 'default_model_replaced': False}), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('root', 'task', 'visual-review'):
        parser.add_argument('--' + name, required=True, type=Path)
    main(parser.parse_args())
