"""Deterministic source-balanced samples and fresh aligned degradation per draw."""
import collections
import hashlib
import json
import random
from functools import lru_cache
from pathlib import Path
import numpy as np
from PIL import Image
import torch
from .prepare_reduction_v2 import sensor

@lru_cache(maxsize=128)
def read_array(path, mode):
    return np.asarray(Image.open(path).convert(mode)).copy()

class PairedData:
    def __init__(self, data, frozen):
        self.data = Path(data)
        self.protocol = json.loads(Path(frozen).read_text())
        raw = (self.data/'manifest.json').read_bytes()
        assert hashlib.sha256(raw).hexdigest() == self.protocol['data_manifest_sha256']
        self.rows = json.loads(raw)['records']
        self.splits = {s:[r for r in self.rows if r['split']==s and not r['synthetic']] for s in ('train','val','test')}
        self.synthetic = [r for r in self.rows if r['split']=='train' and r['synthetic']]
        self.pools = collections.defaultdict(lambda:collections.defaultdict(list))
        for r in self.splits['train']:
            self.pools[r['cell']][r['source_group']].append(r)
        self.cells = sorted(self.pools)
        self.weights = [self.protocol['target_cell_weights'].get(c,.01) for c in self.cells]
    def choose(self, serial, mix):
        gen = random.Random(940000000+serial)
        cell = gen.choices(self.cells,self.weights)[0]
        group = gen.choice(sorted(self.pools[cell]))
        row = gen.choice(self.pools[cell][group])
        if mix and random.Random(941000000+serial).random() < .1:
            row = random.Random(942000000+serial).choice(self.synthetic)
        return row
    def batch(self,row,serial=None,regime='sensor',device='cuda'):
        def arr(key,mode):return read_array(str(self.data/row['files'][key]['path']),mode).copy()
        hr,roi = arr('hr','RGB'), arr('roi','L')
        n = row['input_size'][0]
        if serial is not None:
            rng = np.random.default_rng(943000000+serial)
            rot = int(rng.integers(4)); flip = bool(rng.integers(2))
            hr,roi = np.rot90(hr,rot).copy(),np.rot90(roi,rot).copy()
            if flip:hr,roi=hr[:,::-1].copy(),roi[:,::-1].copy()
            # Photometry applies to HR BEFORE its LR is generated; no target/input tone mismatch.
            if rng.random()<.65:
                gamma=float(rng.uniform(.65,1.25));gain=float(rng.uniform(.9,1.15))
                hr=np.clip((hr.astype(np.float32)/255)**gamma*gain,0,1)
                hr=(hr*255).round().astype('uint8')
            if rng.random()<.75:
                low,_=sensor(hr,(n,n),int(rng.integers(2**31)))
            else:low=np.asarray(Image.fromarray(hr).resize((n,n),Image.Resampling.BICUBIC)).copy()
        else:
            low=arr(regime+'_lr','RGB')
        clean=np.asarray(Image.fromarray(hr).resize((n,n),Image.Resampling.BICUBIC)).copy()
        def tensor(a):
            if a.ndim==2:a=a[:,:,None]
            return torch.from_numpy(a.copy()).permute(2,0,1)[None].float().to(device)/255
        return {'lr':tensor(low),'hr':tensor(hr),'roi':tensor(roi),'clean_lr':tensor(clean)}
