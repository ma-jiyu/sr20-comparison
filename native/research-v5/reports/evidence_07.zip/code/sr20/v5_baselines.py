"""Auditable official SwinIR baselines for very small aircraft inputs.

This module downloads nothing at import or model construction. First explicitly
run ``prepare --assets DIR``; model construction then verifies the recorded bytes.
The learned x4/x8 output and optional x20 display resize remain distinct.

CLI examples::
    python -m sr20.v5_baselines prepare --assets /path/v5_assets
    python -m sr20.v5_baselines infer --assets /path/v5_assets \
        --model swinir_classical_x4 --input input.png --output output.png \
        --display-size 400 400 --display-output display.png
"""
from __future__ import annotations

import argparse
import base64
import hashlib
import importlib.util
import json
from pathlib import Path
import time
import urllib.request

import torch
from torch import nn
from torch.nn import functional as F


SOURCES = Path(__file__).with_name("v5_baseline_sources.json")


def source_manifest():
    return json.loads(SOURCES.read_text(encoding="utf-8"))


def sha256(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _write_json(path, value):
    path = Path(path)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    tmp.replace(path)


def _request(url):
    return urllib.request.Request(url, headers={"User-Agent": "aircraft-sr-v5"})


def _download(url, path, size_bytes, digest=None):
    """Atomic, bounded, size-checked download; preserve any existing target."""
    path = Path(path)
    if path.exists():
        raise FileExistsError(f"Unreceipted file already exists; inspect before adoption: {path}")
    tmp = path.with_suffix(path.suffix + ".part")
    try:
        with urllib.request.urlopen(_request(url), timeout=45) as response, tmp.open("wb") as out:
            count = 0
            while True:
                chunk = response.read(1024 * 1024)
                if not chunk:
                    break
                count += len(chunk)
                if count > size_bytes:
                    raise ValueError(f"Asset exceeded recorded size: {url}")
                out.write(chunk)
        if count != size_bytes:
            raise ValueError(f"Asset size {count} != expected {size_bytes}: {url}")
        observed = sha256(tmp)
        if digest and observed != digest:
            raise ValueError(f"SHA256 mismatch: {url}")
        tmp.replace(path)
        return observed
    finally:
        if tmp.exists():
            tmp.unlink()


def prepare_assets(directory, names=None):
    """Explicit network step; repeated calls verify, and never silently replace."""
    manifest = source_manifest()
    names = list(names or manifest["models"])
    for name in names:
        if name not in manifest["models"]:
            raise ValueError(f"Unknown model: {name}")
    directory = Path(directory)
    directory.mkdir(parents=True, exist_ok=True)
    receipt_path = directory / "asset_receipt.json"
    if receipt_path.exists():
        receipt = json.loads(receipt_path.read_text(encoding="utf-8"))
        if receipt["source_manifest_sha256"] != sha256(SOURCES):
            raise ValueError("Source manifest changed; use a new asset directory")
    else:
        receipt = {"source_manifest_sha256": sha256(SOURCES), "repository": manifest["repository"],
                   "commit": manifest["commit"], "assets": {}}
    arch = manifest["architecture"]
    arch_path = directory / arch["filename"]
    if arch_path.exists():
        if sha256(arch_path) != arch["sha256"]:
            raise ValueError("Architecture hash mismatch")
    else:
        # GitHub's contents API serves the same pinned commit bytes and can be
        # used where raw.githubusercontent.com is temporarily unavailable.
        with urllib.request.urlopen(_request(arch["api_url"]), timeout=45) as response:
            value = json.load(response)
        body = base64.b64decode(value["content"], validate=False)
        if len(body) != arch["size_bytes"] or hashlib.sha256(body).hexdigest() != arch["sha256"]:
            raise ValueError("Pinned architecture download failed verification")
        arch_path.write_bytes(body)
    receipt["architecture_sha256"] = arch["sha256"]
    _write_json(receipt_path, receipt)
    for name in names:
        spec = manifest["models"][name]
        target = directory / spec["filename"]
        old = receipt["assets"].get(name)
        if old:
            if not target.is_file() or target.stat().st_size != spec["size_bytes"] or sha256(target) != old["sha256"]:
                raise ValueError(f"Cached asset changed: {name}")
            continue
        digest = _download(spec["url"], target, spec["size_bytes"], spec["publisher_sha256"])
        receipt["assets"][name] = {"filename": spec["filename"], "url": spec["url"],
            "release_asset_id": spec["release_asset_id"], "size_bytes": spec["size_bytes"],
            "sha256": digest, "sha256_authority": "locally observed on official asset download",
            "downloaded_at_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
        _write_json(receipt_path, receipt)
    return receipt


def _load_architecture(directory, manifest):
    path = Path(directory) / manifest["architecture"]["filename"]
    if sha256(path) != manifest["architecture"]["sha256"]:
        raise ValueError("Architecture bytes differ from pinned official source")
    module_spec = importlib.util.spec_from_file_location("_v5_pinned_swinir", path)
    module = importlib.util.module_from_spec(module_spec)
    module_spec.loader.exec_module(module)
    return module.SwinIR


def _official_pad(value, window=8):
    """Match official inference's symmetric extension, including divisible sizes."""
    h, w = value.shape[-2:]
    if min(h, w) < window:
        raise ValueError(f"Baseline supports dimensions >= {window}; got {(h, w)}")
    hp = (h // window + 1) * window - h
    wp = (w // window + 1) * window - w
    value = torch.cat((value, torch.flip(value, (2,))), 2)[:, :, :h + hp, :]
    return torch.cat((value, torch.flip(value, (3,))), 3)[:, :, :, :w + wp]


def display_resize(value, size):
    """Bicubic display resampling. This does not add learned SR stages."""
    if value.shape[-2:] == tuple(size):
        return value
    return F.interpolate(value, size=tuple(size), mode="bicubic", align_corners=False,
                         antialias=True).clamp(0, 1)


class SwinIRBaseline(nn.Module):
    """Strictly loaded official network with differentiable native-scale forward."""

    def __init__(self, name, assets, device="cpu"):
        super().__init__()
        manifest = source_manifest()
        spec = manifest["models"][name]
        directory = Path(assets)
        receipt = json.loads((directory / "asset_receipt.json").read_text(encoding="utf-8"))
        if receipt["source_manifest_sha256"] != sha256(SOURCES):
            raise ValueError("Asset receipt uses another source manifest")
        entry = receipt["assets"][name]
        checkpoint = directory / spec["filename"]
        if checkpoint.stat().st_size != spec["size_bytes"] or sha256(checkpoint) != entry["sha256"]:
            raise ValueError("Checkpoint verification failed")
        architecture = _load_architecture(directory, manifest)
        self.network = architecture(upscale=spec["scale"], in_chans=3, img_size=64, window_size=8,
            img_range=1., depths=[6] * 6, embed_dim=180, num_heads=[6] * 6,
            mlp_ratio=2, upsampler=spec["upsampler"], resi_connection="1conv")
        value = torch.load(checkpoint, map_location="cpu", weights_only=True)
        if isinstance(value, dict) and spec["state_key"] in value:
            state, state_key = value[spec["state_key"]], spec["state_key"]
        elif isinstance(value, dict) and value and all(isinstance(v, torch.Tensor) for v in value.values()):
            state, state_key = value, "raw_state_dict"
        else:
            raise ValueError(f"Unexpected checkpoint container: expected {spec['state_key']} or raw tensors")
        self.network.load_state_dict(state, strict=True)
        self.name, self.scale = name, int(spec["scale"])
        self.source_receipt = {"name": name, "learned_scale": self.scale, "commit": manifest["commit"],
            "architecture_sha256": manifest["architecture"]["sha256"], "checkpoint_sha256": entry["sha256"],
            "state_key": state_key, "strict_load": True, "state_entries": len(state),
            "parameters": sum(p.numel() for p in self.network.parameters()),
            "training_distribution": spec["training_distribution"],
            "padding": manifest["implementation"]["padding"]}
        self.to(device)
        self.eval()

    def forward(self, lr):
        if lr.ndim != 4 or lr.shape[1] != 3 or not lr.is_floating_point():
            raise ValueError("Expected floating BCHW RGB input in [0,1]")
        h, w = lr.shape[-2:]
        result = self.network(_official_pad(lr))
        return result[:, :, :h * self.scale, :w * self.scale]

    @torch.no_grad()
    def predict(self, lr, *, target_size=None, self_ensemble=False):
        if self.training:
            raise RuntimeError("Call eval() before predict(); forward() remains available for training")
        if not self_ensemble:
            result = self(lr)
        else:
            outputs = []
            for transpose in (False, True):
                for flip_y in (False, True):
                    for flip_x in (False, True):
                        inp = lr.transpose(-2, -1) if transpose else lr
                        if flip_y:
                            inp = inp.flip(-2)
                        if flip_x:
                            inp = inp.flip(-1)
                        pred = self(inp)
                        if flip_x:
                            pred = pred.flip(-1)
                        if flip_y:
                            pred = pred.flip(-2)
                        if transpose:
                            pred = pred.transpose(-2, -1)
                        outputs.append(pred)
            result = torch.stack(outputs).mean(0)
        if not torch.isfinite(result).all():
            raise FloatingPointError("Nonfinite SwinIR prediction")
        result = result.clamp(0, 1)
        return display_resize(result, target_size) if target_size is not None else result


def _save_rgb(value, path):
    from PIL import Image
    array = value[0].detach().clamp(0, 1).permute(1, 2, 0).cpu().numpy()
    target = Path(path)
    target.parent.mkdir(parents=True, exist_ok=True)
    Image.fromarray((array * 255).round().astype("uint8"), mode="RGB").save(target)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    subs = parser.add_subparsers(dest="command", required=True)
    prep = subs.add_parser("prepare")
    prep.add_argument("--assets", type=Path, required=True)
    prep.add_argument("--models", nargs="+", choices=list(source_manifest()["models"]))
    infer = subs.add_parser("infer")
    infer.add_argument("--assets", type=Path, required=True)
    infer.add_argument("--model", choices=list(source_manifest()["models"]), required=True)
    infer.add_argument("--input", type=Path, required=True)
    infer.add_argument("--output", type=Path, required=True)
    infer.add_argument("--device", default="cuda")
    infer.add_argument("--self-ensemble", action="store_true")
    infer.add_argument("--display-size", type=int, nargs=2, metavar=("HEIGHT", "WIDTH"))
    infer.add_argument("--display-output", type=Path)
    args = parser.parse_args()
    if args.command == "prepare":
        print(json.dumps(prepare_assets(args.assets, args.models), indent=2))
        return
    from PIL import Image
    import numpy as np
    if bool(args.display_size) != bool(args.display_output):
        parser.error("Supply both --display-size and --display-output, or neither")
    image = np.asarray(Image.open(args.input).convert("RGB"), dtype=np.float32) / 255
    lr = torch.from_numpy(image.copy()).permute(2, 0, 1).unsqueeze(0).to(args.device)
    model = SwinIRBaseline(args.model, args.assets, args.device)
    result = model.predict(lr, self_ensemble=args.self_ensemble)
    _save_rgb(result, args.output)
    if args.display_output:
        _save_rgb(display_resize(result, args.display_size), args.display_output)
    record = {**model.source_receipt, "input_sha256": sha256(args.input),
        "input_size_hw": list(lr.shape[-2:]), "learned_output_size_hw": list(result.shape[-2:]),
        "self_ensemble": args.self_ensemble, "output_sha256": sha256(args.output),
        "display_size_hw": args.display_size,
        "display_note": "Resizing for display is not additional recovered scene information"}
    _write_json(args.output.with_suffix(".json"), record)
    print(json.dumps(record, indent=2))


if __name__ == "__main__":
    main()
