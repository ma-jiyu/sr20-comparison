"""Prospective V5 validation of final perceptual weights and LR-only detail transfer.

Never changes V4 selections. No ground truth enters any prediction transform.
Only validation is used by this diagnostic; test requires a separate frozen selection.
"""
import argparse, collections, hashlib, json, time
from pathlib import Path
import numpy as np
from PIL import Image
import torch
from torch.nn import functional as F
from .research_v4_models import Reconstruction20
from .research_v4_data import PairedData
from .train_research_v4 import perception
from .train_reduction_v2 import FlexibleSR, scores
from .train_expansion_v3 import structural
from .train_matched import dump, sha

METHODS=('old','B20','B30','blend50','dc50','dc100')

def pil_consistency(p, clean):
    """Diagnostic only: identical PIL/uint8 operator used to produce clean LR."""
    im=Image.fromarray(p[0].clamp(0,1).mul(255).round().byte().permute(1,2,0).cpu().numpy())
    low=np.asarray(im.resize((clean.shape[-1],clean.shape[-2]),Image.Resampling.BICUBIC)).astype(np.float32)/255
    target=clean[0].permute(1,2,0).cpu().numpy()
    return float(np.abs(low-target).mean())

def detail_transfer(base, final, size, strength):
    # Retain late-stage details, anchor low frequency to same-input reconstruction.
    delta=final.clamp(0,1)-base.clamp(0,1)
    for _ in range(6):
        low=F.interpolate(delta,size,mode='area')
        delta=delta-F.interpolate(low,delta.shape[-2:],mode='bilinear',align_corners=False)
    return (base.clamp(0,1)+strength*delta).clamp(0,1)

def variants(base, final, x, old):
    return {'old':old,'B20':base,'B30':final,'blend50':.5*base.clamp(0,1)+.5*final.clamp(0,1),
            'dc50':detail_transfer(base,final,x.shape[-2:],.5),'dc100':detail_transfer(base,final,x.shape[-2:],1.)}

def save_png(p,t):
    p.parent.mkdir(parents=True,exist_ok=True)
    Image.fromarray(t[0].detach().clamp(0,1).mul(255).round().byte().permute(1,2,0).cpu().numpy()).save(p)

def aggregate(rows):
    groups=collections.defaultdict(list)
    for r in rows:groups[r['source_group']].append(r)
    keys=('full','roi','ssim_roi','edge_mae','lpips_roi','lowfreq_mae','same_operator_lr_mae')
    gm={g:{k:float(np.mean([r[k] for r in rs])) for k in keys} for g,rs in groups.items()}
    return {'count':len(rows),'groups':len(gm),'group_means':gm,'means':{k:float(np.mean([v[k] for v in gm.values()])) for k in keys},'rows':rows}

@torch.inference_mode()
def main(a):
    import lpips,cv2
    cv2.setNumThreads(2);torch.set_num_threads(4);torch.manual_seed(1005)
    v4=a.base/'research_v4_20260929'; out=a.run;out.mkdir(parents=True,exist_ok=True)
    protocol=json.loads(a.protocol.read_text());assert protocol['methods']==list(METHODS)
    assert not (out/'complete.json').exists(),'Completed diagnostic must not be overwritten'
    metric=lpips.LPIPS(net='vgg').cuda().eval().requires_grad_(False)
    nets=[];weights={}
    for name,file in [('B20','best_perceptual.pt'),('B30','final.pt')]:
        path=v4/'train/B_real'/file; weights[name]=sha(path)
        state=torch.load(path,map_location='cpu',weights_only=False)
        assert state['step']==(20000 if name=='B20' else 30000)
        net=Reconstruction20(v4/'weights/RealESRNet_x4plus.pth').cuda().eval()
        net.restore(state['model']);nets.append(net);del state
    oldpath=a.base/'reduction_v2_20260928/training/C20_sensor/best_inference.pt'
    state=torch.load(oldpath,map_location='cpu',weights_only=True)
    old=FlexibleSR(**state['model_config']).cuda().eval();old.load_state_dict(state['model']);del state
    weights['old']=sha(oldpath)
    assert weights==protocol['weights'],(weights,protocol['weights'])
    dump(out/'config.json',{'protocol_sha256':sha(a.protocol),'code_sha256':sha(Path(__file__)),
         'weights':weights,'method':'Same input two checkpoints; predeclared output transforms only; no HR oracle',
         'split':a.split,'gpu':torch.cuda.get_device_name()})
    data=PairedData(a.base/'expansion_v3_20260928/data',v4/'protocol_frozen.json')
    results={k:[] for k in METHODS};start=time.monotonic()
    for i,r in enumerate(data.splits[a.split]):
        for regime in ('clean','sensor'):
            b=data.batch(r,regime=regime)
            preds=variants(nets[0](b['lr']),nets[1](b['lr']),b['lr'],old(b['lr']))
            roi=b['roi'].clone();roi[:,:,:20]=0;roi[:,:,-20:]=0;roi[:,:,:,:20]=0;roi[:,:,:,-20:]=0
            for k,p in preds.items():
                assert p.shape==b['hr'].shape and torch.isfinite(p).all()
                row={'id':r['id'],'source_group':r['source_group'],'regime':regime,
                     **scores(p,b['hr'],torch.ones_like(roi),b['roi'],20),**structural(p,b['hr'],roi),
                     'lpips_roi':float(perception(metric,p.clamp(0,1),b)),
                     'lowfreq_mae':float(F.l1_loss(F.interpolate(p.clamp(0,1),b['lr'].shape[-2:],mode='area'),b['clean_lr'])),
                     'same_operator_lr_mae':pil_consistency(p,b['clean_lr'])}
                results[k].append(row)
            if r['id'] in protocol['paired_panel_ids']:
                dest=out/'paired'/r['id']/regime
                for k,p in {**preds,'input':b['lr'],'reference':b['hr']}.items():save_png(dest/(k+'.png'),p)
        if (i+1)%8==0:print('V5_VALIDATION',i+1,len(data.splits[a.split]),round(time.monotonic()-start,1),flush=True)
    for k,rows in results.items():dump(out/(k+'.json'),aggregate(rows))
    if a.split=='val':
        pixels=np.load(a.base/'planesnet_20260921/inputs.npy',allow_pickle=False)
        for index in protocol['native_panel_ids']:
            x=torch.from_numpy(pixels[index].copy()).permute(2,0,1)[None].float().cuda()/255
            preds=variants(nets[0](x),nets[1](x),x,old(x))
            for k,p in {**preds,'input':x}.items():save_png(out/'native'/str(index)/(k+'.png'),p)
    dump(out/'complete.json',{'complete':True,'split':a.split,'count_per_method':len(results['old']),
         'methods':list(METHODS),'seconds':time.monotonic()-start,'protocol_sha256':sha(a.protocol)})
    print('V5_PERCEPTUAL_DIAG_COMPLETE',flush=True)

if __name__=='__main__':
    p=argparse.ArgumentParser()
    for k in ('base','run','protocol'):p.add_argument('--'+k,type=Path,required=True)
    p.add_argument('--split',choices=['val','test'],default='val')
    main(p.parse_args())
