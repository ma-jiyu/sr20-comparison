"""Separate prospective freeze after rejecting the perceptual-classical pilot.

Classical: new6000 reconstruction-only run, maximum validation ROI PSNR.
Real-PSNR: original6000 run, minimum guard-eligible validation LPIPS.
Both exact checkpoints need actual validation/native visual acceptance. The
old rejected classical evidence is retained, never silently relabeled/reused.
"""
import argparse
from datetime import datetime, timezone
import hashlib
from pathlib import Path
import tempfile
import json

import torch

from .freeze_v5_candidates import (ARMS, GUARD, PROTOCOL_GUARD, assert_no_test,
                                  check_visual, encoded, inspect_arm, require, structural_gate)
from .infer_v5_swinir import read_json, sha, load_selection, output_lock
from .audit_v5_swinir import recompute


RECON_RUN = 'swinir_classical_reconstruction_x4'


def inspect_reconstruction(task, manifest_sha, identities, review):
    model = ARMS['classical']; run = task / 'training' / RECON_RUN
    cfg_path, done_path = run / 'config.json', run / 'training_complete.json'
    cfg, done = read_json(cfg_path), read_json(done_path); cfg_sha = sha(cfg_path)
    require(done['complete'] is True and done['steps'] == 6000 and done['config_sha256'] == cfg_sha and done['test_evaluated'] is False,
            'Reconstruction-only6000 training is incomplete or test has already run')
    proto_path = task / f'{RECON_RUN}_training_protocol.json'; proto = read_json(proto_path)
    expected = {'model': model, 'steps': 6000, 'reconstruction_steps': 6000, 'effective_batch': 8,
                'microbatch': 4, 'seed': 1005, 'scale': 4, 'data_manifest_sha256': manifest_sha}
    for key, value in expected.items():
        require(cfg[key] == proto[key] == value, 'Reconstruction frozen field differs: ' + key)
    require(proto['candidate_checkpoint'] == 'best_fidelity.pt' and proto['selection_policy'] == 'highest_validation_roi_psnr',
            'New protocol must prospectively specify maximum validation ROI PSNR')
    require(proto['validation_interval'] == 500 and proto['test_used_for_selection'] is False and proto['candidate_guard'] == PROTOCOL_GUARD,
            'Reconstruction protocol changes validation or structural gates')
    require(cfg['protocol_sha256'] == sha(proto_path) and cfg['candidate_guard'] == GUARD,
            'Reconstruction training protocol identity/gates changed')
    require(cfg['smoke'] is False and cfg['precision'] == 'float32' and cfg['candidate_anchor'] == 'step0 on same new real validation',
            'Expected genuine FP32 training with original step0 anchor')
    require((cfg['train_pairs'], cfg['train_groups'], cfg['validation_pairs'], cfg['validation_groups']) == (385, 20, 61, 4),
            'Reconstruction population differs')
    names = {'train_v5_reconstruction.py', 'train_v5_swinir.py', 'v5_baselines.py', 'prepare_reduction_v2.py',
             'train_matched.py', 'train_reduction_v2.py', 'train_expansion_v3.py', 'train_research_v4.py', 'diagnose_v5_perceptual.py'}
    require(names <= set(cfg['code_sha256']), 'Reconstruction code identity record is incomplete')
    for name, digest in cfg['code_sha256'].items():
        require(sha(Path(__file__).parent / name) == digest, 'Frozen training/helper changed: ' + name)
    trainer = Path(__file__).with_name('train_v5_reconstruction.py')
    require(proto['trainer'] == trainer.name and proto['trainer_sha256'] == cfg['code_sha256'][trainer.name] == sha(trainer),
            'Reconstruction trainer differs from prospectively declared bytes')
    old_source = Path(__file__).with_name('train_v5_swinir.py').read_text(encoding='utf8')
    expected_source = old_source.replace('assert args.steps > args.reconstruction_steps > 0', 'assert args.steps >= args.reconstruction_steps > 0')
    expected_source = expected_source.replace("code_names = ('train_v5_swinir.py',", "code_names = ('train_v5_reconstruction.py', 'train_v5_swinir.py',")
    require(trainer.read_text(encoding='utf8') == expected_source, 'Reconstruction trainer contains changes beyond the two declared mechanical edits')
    final_path = run / 'final.pt'; state = torch.load(final_path, map_location='cpu', weights_only=True)
    require(state['step'] == 6000 and state['config'] == cfg and bool(state['model']), 'Final reconstruction export is not6000')
    keys = set(state['model']); del state
    history, anchor = [], None
    best_step, best_roi, perceptual_step, best_lpips = None, -float('inf'), None, float('inf')
    for step in range(0, 6001, 500):
        path = run / f'validation_{step}.json'; value = read_json(path)
        require(value['step'] == step and value['split'] == 'val' and value['config_sha256'] == cfg_sha, 'Wrong reconstruction validation identity')
        grouped = recompute(value)
        require(value['count'] == 122 and value['groups'] == 4 and grouped['identities'] == identities, 'Reconstruction validation population changed')
        if step == 0:
            anchor = grouped['means']
        passed, gate = structural_gate(grouped['means'], anchor)
        require(value['perceptual_eligible'] is passed, 'Incorrect recorded reconstruction structural eligibility')
        if grouped['means']['roi'] > best_roi:
            best_step, best_roi = step, grouped['means']['roi']
        if passed and grouped['means']['lpips_roi'] < best_lpips:
            perceptual_step, best_lpips = step, grouped['means']['lpips_roi']
        history.append({'step': step, 'sha256': sha(path), 'means': grouped['means'], 'gate': gate})
    require(done['selected']['fidelity'] == best_step and done['selected']['perceptual'] == perceptual_step, 'Training checkpoint policy markers disagree with independent recomputation')
    validation = next(v for v in history if v['step'] == best_step)
    require(validation['gate']['passed'], 'Highest-ROI reconstruction checkpoint fails structural guard; no lower-rank fallback')
    checkpoint = run / 'best_fidelity.pt'; state = torch.load(checkpoint, map_location='cpu', weights_only=True)
    require(state['step'] == best_step and state['config'] == cfg and set(state['model']) == keys, 'Best-fidelity checkpoint is not the highest-ROI state')
    require(all(torch.is_tensor(v) and torch.isfinite(v).all().item() for v in state['model'].values()), 'Nonfinite reconstruction candidate')
    del state
    digest = sha(checkpoint)
    require(review['methods']['classical']['checkpoint_sha256'] == digest, 'Visual acceptance does not identify the final reconstruction checkpoint')
    return {'arm': 'classical', 'model': model, 'run': run, 'checkpoint_file': 'best_fidelity.pt', 'checkpoint_sha256': digest,
        'step': best_step, 'training_config_sha256': cfg_sha, 'training_complete_sha256': sha(done_path),
        'training_protocol': proto_path.name, 'training_protocol_sha256': sha(proto_path), 'final6000_sha256': sha(final_path),
        'validation': validation, 'anchor': anchor, 'validation_history': history, 'visual': review['methods']['classical'],
        'vgg_sha256': cfg['vgg_sha256'], 'protocol': proto,
        'policy': 'Highest source-group-macro validation ROI PSNR at step0,500,...,6000; tie earliest; then original structural and actual visual veto; no fallback'}


def rejection_observations(record):
    if record.get('schema_version') == 'v5.independent_visual_review.1':
        # Read the actual independent review schema without rewriting its
        # observations or confusing a proposal with final candidate acceptance.
        require(record.get('blind') is False and record.get('labels_visible') is True and
                record.get('selection_test_used') is False and record.get('test_images_read_by_this_review') is False,
                'Independent rejection review must be labeled and pre-test')
        verification = record.get('verification', {})
        require(all(verification.get(key) is True for key in (
            'all_receipt_source_and_sheet_sha256_rechecked', 'all_74_source_comparisons_decoded',
            'all_37_sheets_actual_model_view', 'no_rareplanes_test_payload_read')),
            'Independent rejection review lacks completed source/view verification')
        images = record.get('images', [])
        require(len(images) == 37 and all(image.get('actually_viewed') is True and
                image.get('review_is_blind') is False for image in images),
                'Independent rejection must cover its actual37 review sheets')
        proposal = record.get('candidate_gate_proposals', {}).get('classical', {})
        require(proposal.get('review_complete') is True and proposal.get('step') == 6000,
                'Independent classical rejection is incomplete')
        artifact_ok = proposal.get('no_new_obvious_periodic_artifact')
        shape_ok = proposal.get('no_new_global_shape_collapse')
        require(isinstance(artifact_ok, bool) and isinstance(shape_ok, bool) and
                proposal.get('pass_narrow_visual_gate') is (artifact_ok and shape_ok),
                'Independent rejection proposal disagrees with its visual gates')
        receipt = record.get('source_receipts', {}).get('classical', {}).get('receipt', {})
        require(receipt.get('checkpoint_sha256') == proposal.get('checkpoint_sha256') and
                receipt.get('step') == 6000 and receipt.get('test_used') is False,
                'Independent rejection source receipt differs from the reviewed candidate')
        item = {'reviewed': True, 'checkpoint_sha256': proposal['checkpoint_sha256'],
                'no_obvious_new_grid_or_shape_collapse': proposal['pass_narrow_visual_gate'],
                'notes': proposal.get('reason_zh'), 'original_schema': record['schema_version'],
                'original_classical_proposal': proposal}
    else:
        require(record.get('completed') is True and record.get('blind_review') is False and record.get('test_images_read') is False
                and record.get('test_used_for_selection') is False, 'Completed nonblind pre-test rejection record required')
        item = record.get('methods', {}).get('classical', {})
    require(item.get('reviewed') is True and item.get('no_obvious_new_grid_or_shape_collapse') is False
            and isinstance(item.get('notes'), str) and item['notes'].strip(), 'Original classical rejection must contain actual failed visual observations')
    return item


def rejected_parent(task, path, protocol):
    record = read_json(path); item = rejection_observations(record)
    run = task / 'training' / ARMS['classical']; checkpoint = run / 'best_perceptual.pt'; digest = sha(checkpoint)
    require(digest == item['checkpoint_sha256'] == protocol['rejected_parent_checkpoint_sha256'], 'Rejected predecessor weight identity differs')
    done = read_json(run / 'training_complete.json')
    require(done['complete'] is True and done['steps'] == 6000 and done['test_evaluated'] is False, 'Rejected predecessor completion record differs')
    # A stable task-relative reference lets delivery package the exact rejection.
    review_file = path.resolve().relative_to(task).as_posix()
    return {'model': ARMS['classical'], 'checkpoint_file': 'training/' + ARMS['classical'] + '/best_perceptual.pt',
            'checkpoint_sha256': digest, 'review_file': review_file, 'review_sha256': sha(path),
            'training_complete_sha256': sha(run / 'training_complete.json'), 'visual_observations': item,
            'role': 'Rejected exploratory predecessor, not a final candidate; no full8000/test claim required or made'}


def main(args):
    task, root = args.task.resolve(), args.root.resolve()
    require(task.is_dir(), 'Missing task directory')
    with output_lock(task / '.candidate_freeze_lock'):
        assert_no_test(task); review = check_visual(args.visual_review); visual_sha = sha(args.visual_review)
        data = task / 'rareplanes/data'; manifest_path = data / 'manifest.json'; manifest_sha = sha(manifest_path)
        records = read_json(manifest_path)['records']
        val = [r for r in records if r['split'] == 'val' and r['scale'] == 4 and r.get('synthetic') is False]
        train = [r for r in records if r['split'] == 'train' and r['scale'] == 4 and r.get('synthetic') is False]
        require(len(val) == 61 and len({r['source_group'] for r in val}) == 4 and len(train) == 385 and len({r['source_group'] for r in train}) == 20,
                'Unexpected frozen real-aircraft population')
        require(not ({r['source_group'] for r in val} & {r['source_group'] for r in train}) and len({r['id'] for r in train + val}) == 446,
                'Training/validation overlap or duplicate identity')
        identities = sorted((r['id'], r['source_group'], reg) for r in val for reg in ('clean', 'sensor'))
        classical = inspect_reconstruction(task, manifest_sha, identities, review)
        real = inspect_arm('realpsnr', ARMS['realpsnr'], task, manifest_sha, identities, review)
        real.update(checkpoint_file='best_perceptual.pt', training_protocol=f"{ARMS['realpsnr']}_training_protocol.json",
                    policy='Lowest guard-eligible source-group-macro validation LPIPS across step0,500,...,6000; tie earliest; actual visual veto; no fallback')
        items = {'classical': classical, 'realpsnr': real}
        require(classical['vgg_sha256'] == real['vgg_sha256'], 'Candidate VGG metric identities differ')
        rejection = rejected_parent(task, args.rejection_review, classical['protocol'])
        native_path = root / 'geometry_20260928/test_protocol.json'; panel_path = root / 'research_v4_20260929/visual_panel_frozen.json'
        native, panel = read_json(native_path), read_json(panel_path)
        panels = sorted(set(native['display_indices']) | set(panel['native_ids'])); require(len(panels) == 29, 'Fixed29 panel changed')
        files = {arm: task / f'selection_{arm}.json' for arm in ARMS}; joint_path = task / 'joint_candidate_freeze.json'
        prior = [read_json(p) for p in [*files.values(), joint_path] if p.exists()]; stamps = {r.get('frozen_at_utc') for r in prior}
        require(not prior or (len(stamps) == 1 and None not in stamps), 'Existing freeze chronology conflicts')
        stamp = next(iter(stamps)) if prior else datetime.now(timezone.utc).isoformat(); dt = datetime.fromisoformat(stamp)
        require(dt.tzinfo is not None and dt <= datetime.now(timezone.utc), 'Invalid/future freeze timestamp')
        payloads = {}
        for arm, item in items.items():
            payloads[arm] = {'version': 5, 'frozen': True, 'frozen_at_utc': stamp, 'test_used_for_selection': False,
                'checkpoint': {'file': item['checkpoint_file'], 'sha256': item['checkpoint_sha256'], 'model': item['model'], 'step': item['step']},
                'training_run': item['run'].relative_to(task).as_posix(), 'training_protocol': item['training_protocol'],
                'training_config_sha256': item['training_config_sha256'], 'training_complete_sha256': item['training_complete_sha256'],
                'training_protocol_sha256': item['training_protocol_sha256'], 'data_manifest_sha256': manifest_sha,
                'native_protocol_sha256': sha(native_path), 'visual_panel_sha256': sha(panel_path), 'native_panel_ids': panels,
                'visual_review_sha256': visual_sha, 'visual_gate': item['visual'], 'selected_validation_sha256': item['validation']['sha256'],
                'validation_gate': item['validation']['gate'], 'selection_policy': item['policy'],
                'role': 'Final scientific comparison candidate; default model not automatically replaced',
                'limitations': '61 validation aircraft in4 locations; coarse diamond ROI; label-visible visual review; native panel has no HR truth. These two final candidates have different training loss schedules and architectures.'}
        with tempfile.TemporaryDirectory(prefix='reconstruction_freeze_check_', dir=task) as temporary:
            Path(temporary).resolve().relative_to(task)
            for arm, payload in payloads.items():
                path = Path(temporary) / (arm + '.json'); path.write_bytes(encoded(payload))
                load_selection(path, items[arm]['run'], data, root)
        joint = {'version': 5, 'frozen': True, 'frozen_at_utc': stamp, 'pre_test_scan_passed': True,
            'test_images_read': False, 'test_used_for_selection': False, 'default_model_replaced': False,
            'visual_review_sha256': visual_sha, 'data_manifest_sha256': manifest_sha, 'rejected_predecessor': rejection,
            'candidates': [{'arm': arm, 'file': files[arm].name, 'sha256': hashlib.sha256(encoded(payloads[arm])).hexdigest(),
                'checkpoint': payloads[arm]['checkpoint'], 'training_run': payloads[arm]['training_run'],
                'training_protocol': item['training_protocol'], 'training_final6000_sha256': item['final6000_sha256'],
                'validation_anchor': item['anchor'], 'selected_validation': item['validation'], 'validation_history': item['validation_history']}
                for arm, item in items.items()], 'freeze_code_sha256': sha(Path(__file__)),
            'scope': 'Revised prospective comparison: reconstruction-only classical fidelity candidate vs original real-PSNR perceptual candidate. Rejected classical perceptual result retained separately. No test-based reselection.',
            'sample_limit': {'training_aircraft': 385, 'training_locations': 20, 'validation_aircraft': 61, 'validation_locations': 4,
                             'native_panel_count': 29, 'native_hr_truth_available': False, 'blind_visual_review': False}}
        planned = [(files[arm], encoded(payloads[arm])) for arm in ARMS] + [(joint_path, encoded(joint))]
        for path, body in planned:
            require(not path.exists() or path.read_bytes() == body, f'Existing freeze differs; refusing overwrite: {path}')
        assert_no_test(task)
        for path, body in planned:
            if not path.exists():
                temporary = path.with_name(path.name + '.tmp'); temporary.write_bytes(body); temporary.replace(path)
        print('V5_RECONSTRUCTION_JOINT_FROZEN', json.dumps({'frozen_at_utc': stamp,
            'selections': {arm: {'path': str(files[arm]), 'sha256': sha(files[arm]), 'step': items[arm]['step'],
                                'run': str(items[arm]['run'])} for arm in ARMS}, 'joint_sha256': sha(joint_path)}, ensure_ascii=False), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('root', 'task', 'visual-review', 'rejection-review'):
        parser.add_argument('--' + name, type=Path, required=True)
    main(parser.parse_args())
