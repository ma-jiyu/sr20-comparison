"""Read-only model analysis; writes plots/statistics, never selects checkpoints.

``curves`` consumes completed training validation files only. ``final`` requires
both frozen, fully audited deliveries and the six completed fixed test controls.
No image inference, test-driven tuning, final_summary edit, or publication occurs.
"""
from __future__ import annotations

import argparse
import collections
import hashlib
import itertools
import json
import math
from pathlib import Path

import numpy as np

from .audit_v5_swinir import METRICS, LOWER_BETTER, recompute, bootstrap


ARMS = {"classical": "swinir_classical_x4", "realpsnr": "swinir_real_psnr_x4"}
CONTROLS = ("bicubic", "old", "B20", "B30", "swinir_classical_x4_init", "swinir_real_psnr_x4_init")
SCOPES = ("combined", "clean", "sensor")
PAIRS = (("classical", "B20"), ("classical", "old"), ("classical", "swinir_classical_x4_init"),
         ("realpsnr", "B20"), ("realpsnr", "old"), ("realpsnr", "swinir_real_psnr_x4_init"))
SEED = 10052026
DRAWS = 10000


def sha(path):
    result = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            result.update(chunk)
    return result.hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    tmp.replace(path)


def group_rows(rows):
    """The independent unit remains location, including clean/sensor subsets."""
    assert rows
    grouped = collections.defaultdict(list)
    identities = []
    for row in rows:
        assert all(math.isfinite(row[key]) for key in METRICS)
        identities.append((row["id"], row["source_group"], row["regime"]))
        grouped[row["source_group"]].append(row)
    assert len(identities) == len(set(identities))
    means = {group: {key: float(np.mean([row[key] for row in values])) for key in METRICS}
             for group, values in grouped.items()}
    return {"count": len(rows), "groups": len(means), "identities": sorted(identities),
            "group_means": means,
            "means": {key: float(np.mean([value[key] for value in means.values()])) for key in METRICS}}


def report_scopes(report):
    audited = recompute(report)
    combined = group_rows(report["rows"])
    assert combined["identities"] == audited["identities"]
    assert all(abs(combined["means"][key] - audited["means"][key]) < 1e-12 for key in METRICS)
    result = {"combined": combined}
    for regime in ("clean", "sensor"):
        result[regime] = group_rows([row for row in report["rows"] if row["regime"] == regime])
    assert all(value["groups"] == 4 for value in result.values())
    return result


def effect(reference, candidate):
    result = {}
    for key in METRICS:
        control, value = reference[key], candidate[key]
        row = {"control_mean": control, "candidate_mean": value, "candidate_minus_control": value - control,
               "direction": "lower is better" if key in LOWER_BETTER else "higher is better"}
        if key in ("full", "roi"):
            row["unit"] = "dB; do not interpret a PSNR ratio as a relative quality gain"
        elif control != 0:
            row["candidate_to_control_ratio"] = value / control
            row["relative_change_percent"] = 100 * (value / control - 1)
            if key in LOWER_BETTER:
                row["relative_reduction_percent"] = 100 * (1 - value / control)
        result[key] = row
    return result


def paired_contrast(reference, candidate):
    assert reference["groups"] == candidate["groups"] == 4
    result = bootstrap(reference, candidate, draws=DRAWS, seed=SEED)
    groups = result["groups"]
    # Enumerate all4^4 ordered location resamples as a reproducibility check on
    # the seeded Monte Carlo percentile interval; neither is a significance test.
    exact_indices = np.array(list(itertools.product(range(4), repeat=4)))
    values = effect(reference["means"], candidate["means"])
    for key in METRICS:
        delta = np.array([candidate["group_means"][group][key] - reference["group_means"][group][key]
                          for group in groups])
        exact = delta[exact_indices].mean(axis=1)
        exact_ci = [float(x) for x in np.percentile(exact, [2.5, 97.5])]
        result["metrics"][key].update(values[key])
        result["metrics"][key]["exact_256_resamples_ci95"] = exact_ci
        result["metrics"][key]["exact_ci_includes_zero"] = exact_ci[0] <= 0 <= exact_ci[1]
    result["independent_units"] = "Four locations; images and two degradation regimes are not independent replicates"
    result["interval_method"] = "Paired location percentile bootstrap; 10,000 seeded draws and all256 ordered resamples; no p-values or multiple-comparison significance claim"
    result["uses_test_for_selection"] = False
    return result


def below(root, relative):
    assert not Path(relative).is_absolute(), "Run path must be relative to ROOT"
    path = (root / relative).resolve()
    path.relative_to(root.resolve())
    return path


def curve_runs(root, summary_path=None):
    # Keep the two initial runs even after a different run passes the visual gate.
    runs = {"classical": {"model": ARMS["classical"], "training_run": "training/swinir_classical_x4",
                          "label": "Classical + perceptual (native artifact)",
                          "context": "6000-step perceptual checkpoint rejected after native visual review: fine diagonal grid at IDs 24018/24259; parent decision, no test read."},
            "realpsnr": {"model": ARMS["realpsnr"], "training_run": "training/swinir_real_psnr_x4",
                         "label": "Real-PSNR + perceptual", "context": "Final eligibility requires native visual gate and frozen test."}}
    reconstruction = "training/swinir_classical_reconstruction_x4"
    if (root / reconstruction / "training_complete.json").is_file():
        runs["classical_reconstruction"] = {"model": ARMS["classical"], "training_run": reconstruction,
            "label": "Classical reconstruction only", "context": "Prospective separate6000-step run after native artifact rejection; original run retained."}
    if summary_path is not None:
        summary = read(summary_path)
        for arm, model in ARMS.items():
            name = summary["candidates"][arm]["training_run"]
            below(root, name)
            if not any(item["training_run"] == name for item in runs.values()):
                runs[arm + "_final"] = {"model": model, "training_run": name,
                    "label": arm + " final frozen run", "context": "Run supplied by final summary; validated against actual selection SHA."}
    return runs


def training_curves(root, summary_path=None):
    collected = {}
    inputs = []
    for arm, spec in curve_runs(root, summary_path).items():
        model = spec["model"]
        run = below(root, spec["training_run"])
        config_path, done_path = run / "config.json", run / "training_complete.json"
        config, done = read(config_path), read(done_path)
        assert done["complete"] is True and done["test_evaluated"] is False
        assert done["config_sha256"] == sha(config_path) and done["steps"] == config["steps"] == 6000
        assert config["reconstruction_steps"] in (4000, 6000) and config["model"] == model and config["smoke"] is False
        records = []
        for step in range(0, 6001, 500):
            path = run / f"validation_{step}.json"
            record = read(path)
            assert record["step"] == step and record["split"] == "val" and record["config_sha256"] == sha(config_path)
            assert record["count"] == 122 and record["groups"] == 4
            scopes = report_scopes(record)
            records.append({"step": step, "scopes": scopes, "sha256": sha(path)})
            inputs.append({"path": str(path.relative_to(root)), "sha256": sha(path)})
        selected = dict(done["selected"])
        for delivery_arm in ARMS:
            delivery_config = root / "delivery" / delivery_arm / "config.json"
            if delivery_config.exists():
                frozen = read(delivery_config)
                assert frozen["selection"]["frozen"] is True and frozen["selection"]["test_used_for_selection"] is False
                if frozen["selection"]["training_config_sha256"] == sha(config_path):
                    selected["frozen_final"] = frozen["checkpoint"]["step"]
        by_step = {record["step"]: record for record in records}
        changes = {}
        for kind, step in selected.items():
            assert type(step) is int and step in by_step
            changes[kind] = {"step": step, "scopes": {scope: effect(by_step[0]["scopes"][scope]["means"],
                by_step[step]["scopes"][scope]["means"]) for scope in SCOPES}}
        collected[arm] = {**spec, "steps": config["steps"], "reconstruction_steps": config["reconstruction_steps"],
                          "selected_steps": selected, "initial_to_selected": changes, "validation": records,
                          "config_sha256": sha(config_path), "training_complete_sha256": sha(done_path)}
        inputs.extend({"path": str(path.relative_to(root)), "sha256": sha(path)} for path in (config_path, done_path))
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    colors = dict(zip(collected, ("#087f8c", "#c15b17", "#783d9d", "#3f7b36", "#4767ac")))
    metrics = (("roi", "ROI PSNR (dB; higher better)"), ("ssim_roi", "ROI SSIM (higher better)"),
               ("lpips_roi", "ROI LPIPS (lower better)"), ("edge_mae", "Edge MAE (lower better)"),
               ("same_operator_lr_mae", "Same-operator LR MAE (lower better)"), ("full", "Full-image PSNR (dB; higher better)"))
    fig, axes = plt.subplots(2, 3, figsize=(13.2, 8.2))
    fig.subplots_adjust(left=.065, right=.985, bottom=.075, top=.81, hspace=.34, wspace=.24)
    for axis, (key, title) in zip(axes.flat, metrics):
        axis.axvspan(4, 6, color="#d9d1e8", alpha=.45, zorder=0)
        axis.axvline(4, color="#7a678b", linewidth=.8, linestyle="--")
        for arm, data in collected.items():
            x = [row["step"] / 1000 for row in data["validation"]]
            y = [row["scopes"]["combined"]["means"][key] for row in data["validation"]]
            axis.plot(x, y, color=colors[arm], linewidth=1.7, marker="o", markersize=3.6, label=data["label"])
            for kind, marker in (("fidelity", "^"), ("perceptual", "s")):
                chosen = data["selected_steps"][kind]
                value = next(row for row in data["validation"] if row["step"] == chosen)
                axis.scatter([chosen / 1000], [value["scopes"]["combined"]["means"][key]], marker=marker,
                             s=66, facecolors="none", edgecolors=colors[arm], linewidths=1.5, zorder=5)
        axis.set_title(title, fontsize=10)
        axis.set_xlabel("Training updates (thousands)", fontsize=9)
        axis.grid(alpha=.22)
        axis.tick_params(labelsize=8)
        axis.set_xlim(-.1, 6.1)
    handles, legend_labels = axes[0, 0].get_legend_handles_labels()
    fig.legend(handles, legend_labels, loc="upper center", bbox_to_anchor=(.5, .905),
               ncol=min(len(collected), 3), frameon=False, fontsize=9)
    fig.suptitle("SwinIR x4: real-aircraft validation at 4 held-out locations", y=.975, fontsize=13)
    fig.text(.5, .931, "Location-weighted means; shading: LPIPS stage in original two runs only; triangle/square: fidelity/perceptual", ha="center", fontsize=9)
    fig.text(.5, .852, "Validation-selected gains are not independent test evidence; quantitative improvement can coexist with native grid artifacts.",
             ha="center", fontsize=9, color="#5b3030")
    figures = root / "figures"
    figures.mkdir(parents=True, exist_ok=True)
    png, pdf = figures / "v5_training_curves.png", figures / "v5_training_curves.pdf"
    fig.savefig(png, dpi=220)
    fig.savefig(pdf)
    plt.close(fig)
    result = {"complete": True, "scope": "Validation training curves; no test scores read or used to choose checkpoints",
              "selection_bias_note": "The marked checkpoints were selected on this validation set; their validation gains are not independent test evidence.",
              "locations": 4, "pairs": 61, "regimes_per_pair": 2, "test_read": False,
              "models": collected, "inputs": inputs, "analysis_code_sha256": sha(Path(__file__)),
              "figures": [{"path": str(path.relative_to(root)), "sha256": sha(path)} for path in (png, pdf)]}
    if "classical_reconstruction" in collected:
        original = {row["step"]: row for row in collected["classical"]["validation"]}
        reconstruction = {row["step"]: row for row in collected["classical_reconstruction"]["validation"]}
        pre_change = max(abs(original[step]["scopes"][scope]["means"][key] -
                             reconstruction[step]["scopes"][scope]["means"][key])
                         for step in original if step <= 4000 for scope in SCOPES for key in METRICS)
        result["reconstruction_loss_ablation"] = {
            "scope": "Same architecture/data/seed/update budget; descriptive validation comparison, not test evidence",
            "reference_run": collected["classical"]["training_run"],
            "candidate_run": collected["classical_reconstruction"]["training_run"],
            "steps0_through4000_max_absolute_macro_metric_difference": pre_change,
            "pre_change_note": "Compares all6 metric means in combined/clean/sensor at9 validation steps; this is not a bitwise checkpoint identity claim.",
            "same_update6000": {scope: effect(original[6000]["scopes"][scope]["means"],
                reconstruction[6000]["scopes"][scope]["means"]) for scope in SCOPES},
            "native_quality_limit": "The original perceptual checkpoint was rejected by actual native visual review. This quantitative ablation alone does not establish absence of artifacts in the reconstruction candidate."}
    dump(root / "analysis" / "training_validation_analysis.json", result)
    print("V5_TRAINING_CURVES_COMPLETE", png, pdf, flush=True)


def final_analysis(root, controls_directory, summary_path=None):
    reports, provenance = {}, {}
    joint_path = root / "joint_candidate_freeze.json"
    joint = read(joint_path)
    assert joint["frozen"] is True and joint["test_used_for_selection"] is False
    assert joint["version"] == 5 and len(joint["candidates"]) == 2
    joint_entries = {entry["arm"]: entry for entry in joint["candidates"]}
    assert set(joint_entries) == set(ARMS)
    common_identity = None
    for arm, model in ARMS.items():
        folder = root / "delivery" / arm
        cfg_path, audit_path, report_path = folder / "config.json", folder / "integrity_audit.json", folder / "paired_test.json"
        cfg, audit, done = read(cfg_path), read(audit_path), read(folder / "completion.json")
        status = read(folder / "integrity_audit_status.json")
        assert status["state"] == "complete" and status["report_sha256"] == sha(audit_path)
        assert audit["complete"] is True and audit["native_exact_ids"] is True and audit["verified_native_pngs"] == 16000
        assert audit["verified_paired_output_pngs"] == 312 and audit["verified_panel_pngs"] == 145
        assert audit["all_displays_verified_as_interpolation"] is True
        assert done["complete"] is True and done["native_images"] == 8000 and done["native_pngs"] == 16000
        assert done["config_sha256"] == audit["config_sha256"] == sha(cfg_path)
        assert sha(report_path) == done["paired_test_sha256"]
        # The inference copy is reserialized; the frozen source retains its byte identity.
        assert audit["selection_sha256"] == cfg["selection_sha256"] == sha(root / f"selection_{arm}.json")
        selected = read(root / f"selection_{arm}.json")
        assert read(folder / "selection.json") == selected
        assert selected == cfg["selection"] and selected["frozen"] is True and selected["test_used_for_selection"] is False
        assert cfg["checkpoint"] == audit["checkpoint"] == selected["checkpoint"] and cfg["checkpoint"]["model"] == model
        assert selected["frozen_at_utc"] == joint["frozen_at_utc"]
        assert joint_entries[arm]["sha256"] == cfg["selection_sha256"]
        assert joint_entries[arm]["checkpoint"] == selected["checkpoint"]
        run = below(root, selected["training_run"])
        assert joint_entries[arm]["training_run"] == selected["training_run"]
        assert sha(run / "config.json") == selected["training_config_sha256"]
        assert sha(run / "training_complete.json") == selected["training_complete_sha256"]
        if summary_path is not None:
            summary = read(summary_path)
            assert summary["candidates"][arm]["training_run"] == selected["training_run"]
        report = read(report_path)
        assert report["config_sha256"] == sha(cfg_path) and report["selection_sha256"] == cfg["selection_sha256"]
        assert cfg["input_size"] == [20, 20] and cfg["learned_size"] == [80, 80]
        identity = {key: report[key] for key in ("metric_spec", "data_manifest_sha256", "vgg_sha256")}
        assert identity == {key: cfg[key] for key in identity}
        common_identity = identity if common_identity is None else common_identity
        assert identity == common_identity
        reports[arm] = report
        provenance[arm] = {"report_sha256": sha(report_path), "audit_sha256": sha(audit_path),
                           "config_sha256": sha(cfg_path), "selection_sha256": cfg["selection_sha256"],
                           "checkpoint": cfg["checkpoint"], "training_run": selected["training_run"]}
    assert common_identity["metric_spec"].startswith("trainer_v5:RGB80;shave4;")
    control_root = (root / controls_directory).resolve()
    control_root.relative_to(root.resolve())
    cfg_path, done_path = control_root / "config.json", control_root / "complete.json"
    common, done = read(cfg_path), read(done_path)
    assert common["fixed_methods"] == list(CONTROLS) and common["no_test_ranking"] is True
    assert common["test_used_for_selection"] is False
    assert done["complete"] is True and done["test_ranking_performed"] is False and done["selection_changed"] is False
    assert done["config_sha256"] == sha(cfg_path)
    assert done["selection_sha256"] == common["selection_sha256"] in {value["selection_sha256"] for value in provenance.values()}
    assert common["effective_output_size"] == [80, 80] and common["shave"] == 4
    assert common_identity == {key: common[key] for key in common_identity}
    entries = {row["method"]: row for row in done["reports"]}
    assert set(entries) == set(CONTROLS)
    for method in CONTROLS:
        report_path, config_path = control_root / method / "paired_test.json", control_root / method / "config.json"
        config, report = read(config_path), read(report_path)
        assert config["method"] == method and all(config[key] == value for key, value in common.items())
        assert report["config_sha256"] == entries[method]["config_sha256"] == sha(config_path)
        assert entries[method]["sha256"] == sha(report_path) and entries[method]["verified_output_files"] == 312
        assert report["selection_sha256"] == common["selection_sha256"]
        assert common_identity == {key: report[key] for key in common_identity}
        reports[method] = report
        provenance[method] = {"report_sha256": sha(report_path), "config_sha256": sha(config_path), "model": config["model"]}
    by_method = {}
    for name, report in reports.items():
        assert report["complete"] is True and report["split"] == "test" and report["test_used_for_selection"] is False
        assert report["count"] == 156 and report["groups"] == 4
        by_method[name] = report_scopes(report)
        assert by_method[name]["combined"]["identities"] == by_method["classical"]["combined"]["identities"]
        assert sorted((row["id"], row["regime"], json.dumps(row["source_files"], sort_keys=True)) for row in report["rows"]) == sorted(
            (row["id"], row["regime"], json.dumps(row["source_files"], sort_keys=True)) for row in reports["classical"]["rows"])
    contrasts = {}
    for candidate, reference in PAIRS:
        contrasts[candidate + "_vs_" + reference] = {"candidate": candidate, "control": reference,
            "scopes": {scope: paired_contrast(by_method[reference][scope], by_method[candidate][scope]) for scope in SCOPES}}
    result = {"complete": True, "split": "test", "test_used_for_selection": False,
              "ranking_or_candidate_changes": False, "predefined_comparisons": [list(pair) for pair in PAIRS],
              "same_grid": [80, 80], "shave": 4, "pairs": 78, "cases": 156, "independent_locations": 4,
              "joint_candidate_freeze_sha256": sha(joint_path),
              "common_identity": common_identity, "provenance": provenance, "methods": by_method, "contrasts": contrasts,
              "analysis_code_sha256": sha(Path(__file__)),
              "limitations": ["仅4个留出地点；bootstrap区间为描述性配对地点重采样，不能把156行当作156个独立样本。",
                  "clean和sensor来自同一实拍参考，二者相关；各条件分别统计并始终按地点等权。",
                  "预先列出的多个对照未作多重比较显著性检验，不据test排名或再次选择训练权重。",
                  "ROI是包含背景的官方菱形标注，非精确飞机轮廓；必须保留真实目视结构判断。",
                  "本表是20→80的实拍计算退化测试，不能推断无高清真值的原生PlanesNet细节真实性。"]}
    target = root / "analysis" / "final_quantitative_analysis.json"
    dump(target, result)
    print("V5_FROZEN_TEST_ANALYSIS_COMPLETE", target, flush=True)
    for key in ("classical_vs_B20", "classical_vs_old", "classical_vs_swinir_classical_x4_init"):
        value = contrasts[key]["scopes"]["combined"]["metrics"]
        print(key, json.dumps({"roi_psnr_delta_db": value["roi"]["candidate_minus_control"],
            "lpips_relative_reduction_percent": value["lpips_roi"].get("relative_reduction_percent"),
            "lpips_delta_ci95": value["lpips_roi"]["ci95"],
            "lpips_better_location_fraction": value["lpips_roi"]["better_group_fraction"]}), flush=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("mode", choices=("curves", "final"))
    parser.add_argument("--root", type=Path, default=Path("D:/超分实验/飞机超分突破诊断_20261005"))
    parser.add_argument("--controls-directory", default="test_controls")
    parser.add_argument("--summary", type=Path, help="Optional ROOT final_summary.json; uses candidates.*.training_run without changing it")
    args = parser.parse_args()
    if args.mode == "curves":
        training_curves(args.root, args.summary)
    else:
        final_analysis(args.root, args.controls_directory, args.summary)
