"""Full-field extra2/3/4 reduction and empirically stratified native20 study."""
import json,hashlib,collections,math,tarfile,random
from pathlib import Path
from io import BytesIO
import numpy as np,cv2
from PIL import Image,ImageDraw
OLD=Path(r'D:\超分实验\飞机尺度统计与匹配训练_20260928')
ROOT=Path(r'D:\超分实验\整图降采样与退化匹配_20260928')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2),encoding='utf8')
def cell(long,area):return ('small' if long<=12 else 'mid' if long<=16 else 'large')+'/'+('low' if area<.4 else 'mid' if area<.65 else 'high')
def sensor(hr,size,seed):
 rng=np.random.default_rng(seed);w,h=size;factor=float(hr.shape[1]/w);sx=float(rng.uniform(.12,.65));sy=float(rng.uniform(.10,sx));angle=float(rng.uniform(0,math.pi));q=int(rng.choice([2,3,4]));n=2*math.ceil(3*sx*factor)+1;yy,xx=np.mgrid[:n,:n]-(n-1)/2;c,s=math.cos(angle),math.sin(angle);x=c*xx+s*yy;y=-s*xx+c*yy;k=np.exp(-.5*((x/(sx*factor))**2+(y/(sy*factor))**2));k=(k/k.sum()).astype(np.float32)
 blur=cv2.filter2D(hr.astype(np.float32)/255,-1,k,borderType=cv2.BORDER_REFLECT_101);first=cv2.resize(blur,(w*q,h*q),interpolation=cv2.INTER_AREA)
 photons=float(rng.uniform(1800,7000));first=rng.poisson(np.clip(first,0,1)*photons).astype(np.float32)/photons;read=float(rng.uniform(0,1.5));first+=rng.normal(0,read/255,first.shape).astype(np.float32)
 filt=Image.Resampling.BICUBIC if rng.random()<.7 else Image.Resampling.LANCZOS;lr=np.asarray(Image.fromarray(np.clip(first*255,0,255).round().astype('uint8')).resize((w,h),filt));quality=None
 if rng.random()<.2:
  quality=int(rng.integers(85,101));buf=BytesIO();Image.fromarray(lr).save(buf,format='JPEG',quality=quality);lr=np.asarray(Image.open(BytesIO(buf.getvalue())).convert('RGB')).copy()
 return lr,{'anisotropic_sigma_lr':[sx,sy],'angle_rad':angle,'intermediate_multiple':q,'photons':photons,'read_noise_255':read,'final_filter':'bicubic' if filt==Image.Resampling.BICUBIC else 'lanczos','jpeg_quality':quality,'note':'Plausible bounded sensor/resampling surrogate; not calibrated physical PlanetScopePSF'}
def main():
 cv2.setNumThreads(4);ROOT.mkdir(exist_ok=True);data=ROOT/'data';data.mkdir(exist_ok=True);assert not (data/'manifest.json').exists();records=[]
 m=json.loads((OLD/'matched_data/manifest.json').read_text(encoding='utf8'));sources=json.loads((OLD/'matched_sources.json').read_text(encoding='utf8'));sourcebyid={r['id']:r for r in sources if r['dataset']=='internal'}
 orig=json.loads(Path(r'D:\超分实验\多尺度样本_20260918\manifest.json').read_text(encoding='utf8'));origbyfile={r['source']:r for r in orig['records']};allmanual=json.loads((OLD/'manual_planes/annotations.json').read_text(encoding='utf8'));target=collections.Counter(cell(r['long_side'],r['bbox_area_fraction']) for r in allmanual if r.get('bbox'));assert sum(target.values())==57
 def store(uid,cohort,split,group,hr,clean,roi,geometry,source_sha):
  folder=data/'pairs'/uid;folder.mkdir(parents=True,exist_ok=True);seed=int(hashlib.sha256((uid+'/v2/928').encode()).hexdigest()[:8],16);lr,params=sensor(hr,clean.shape[1::-1],seed);valid=np.ones(hr.shape[:2],np.uint8)*255;files={}
  for key,arr in {'hr':hr,'clean_lr':clean,'sensor_lr':lr,'roi':roi,'valid':valid}.items():
   path=folder/(key+'.png');Image.fromarray(arr).save(path);files[key]={'path':path.relative_to(data).as_posix(),'sha256':sha(path)}
  l,t,r,b=geometry['bbox_hr_xyxy'];long=max(r-l,b-t)/20;area=(r-l)*(b-t)/(hr.shape[0]*hr.shape[1]);records.append({'id':uid,'dataset':cohort,'cohort':cohort,'split':split,'source_group':group,'source_sha256':source_sha,'files':files,'input_size':[clean.shape[1],clean.shape[0]],'reference_size':[hr.shape[1],hr.shape[0]],'plane_long_lr':long,'bbox_area_fraction':area,'cell':cell(long,area),'degradation':params,**geometry})
 # Original complete private fields: literally reduce the storedx20 LR another2/3/4.
 for i,s in enumerate(sourcebyid.values()):
  path=Path(s['file']);assert sha(path)==s['source_sha256'];o=origbyfile[path.relative_to(Path(orig['source_root'])).as_posix()];lowpath=Path(r'D:\超分实验\多尺度样本_20260918')/o['lr']['20']['path'];assert sha(lowpath)==o['lr']['20']['sha256'];im=Image.open(path).convert('RGB');low=Image.open(lowpath).convert('RGB');poly=np.array(s['polygon']).reshape(-1,2)
  for extra in (2,3,4):
   size=(low.width//extra,low.height//extra);ref=(size[0]*20,size[1]*20);assert ref[0]<=im.width and ref[1]<=im.height;hr=np.asarray(im.resize(ref,Image.Resampling.LANCZOS));clean=np.asarray(low.resize(size,Image.Resampling.BICUBIC));p=poly*np.array(ref)/np.array(im.size);roi=np.zeros((ref[1],ref[0]),np.uint8);cv2.fillPoly(roi,[np.round(p).astype('int32')],255)
   uid='whole_'+hashlib.sha256((s['id']+str(extra)).encode()).hexdigest()[:16];store(uid,'whole',s['split'],s['group'],hr,clean,roi,{'extra_reduction':extra,'original_size':list(im.size),'stored_x20_size':list(low.size),'bbox_hr_xyxy':[*p.min(0).tolist(),*p.max(0).tolist()],'preserves_whole_field':True,'reference_native_scale_xy':[ref[0]/im.width,ref[1]/im.height],'reference_note':'Original resized to exactly20*LR; no padding/crop. Per-axis rounding avoids nonintegerpairscale; small aspectratio rounding recorded.'},s['source_sha256'])
  if i%80==0:print('WHOLE_SOURCES',i+1,flush=True)
 # Existing public HR geometry and split stay fixed; reuse only DOTA(no replicatedbackground).
 for i,r in enumerate(x for x in m['records'] if x['dataset']=='dota'):
  src=OLD/'matched_data';hrpath=src/r['files']['hr']['path'];assert sha(hrpath)==r['files']['hr']['sha256'];hr=np.asarray(Image.open(hrpath));roi=np.asarray(Image.open(src/r['files']['roi']['path']));q=2+(int(r['id'][-4:],16)%3);clean=np.asarray(Image.fromarray(hr).resize((20*q,20*q),Image.Resampling.BICUBIC).resize((20,20),Image.Resampling.BICUBIC));store('target_'+r['id'],'target',r['split'],r['source_group'],hr,clean,roi,{'extra_reduction':q,'bbox_hr_xyxy':r['bbox_hr_xyxy'],'preserves_whole_field':False,'reference_native_scale_xy':[r['native_to_hr_scale']]*2,'reference_note':'Previouslyverified complete annotatedplane crop; nativeHR only minified.400square HR preserved.'},r['source_sha256'])
  if i%400==0:print('TARGET_PAIRS',i+1,flush=True)
 weights={k:v/57 for k,v in target.items()};groups=collections.defaultdict(set);hashes=collections.defaultdict(set)
 for r in records:groups[r['source_group']].add(r['split']);hashes[r['source_sha256']].add(r['split']);assert all(20*a==b for a,b in zip(r['input_size'],r['reference_size']))
 assert all(len(v)==1 for v in groups.values()) and all(len(v)==1 for v in hashes.values())
 cfg={'version':2,'records':records,'target_cell_weights':weights,'target_sample_count':57,'target_sample_unresolved':7,'target_sample_total':64,'target_warning':'Exploratory adaptation to previously inspected nativebenchmark geometry; NOT8000officialboxes or untouchedblindtest. Jointlongside/boxoccupancy estimated±2px.','split_counts':dict(collections.Counter(r['split'] for r in records)),'cohort_counts':dict(collections.Counter(r['cohort'] for r in records)),'scale':20,'generator_sha256':sha(Path(__file__)),'protocol':{'A_whole':'100%original wholefields, uniformsource and2/3/4 reduction, clean sequential bicubicinput','B_matched':'90%DOTA20square withmeasuredjointcellweights uniformsourcegroupswithincell;10%wholefieldvariablegrid supplement;cleaninput','C_sensor':'Same exact records/sampling asB;75%sensor surrogate and25%clean, sameHR andROI','model':'All start same prior2070385parameter mediumbest;2000additionalsteps effectivebatch4','selection':'Validation only;80%targetcohortmacroROI and20%wholecohortmacroROI, bothclean/sensor equal;step0eligible','test':'All frozen sourceheldoutpairs, bothregimes, plusall8000nativepositive;unchangedfive display. Reusedbenchmark is exploratory not a new blindtest.'}}
 dump(data/'manifest.json',cfg);audit={'counts':cfg['split_counts'],'cohorts':cfg['cohort_counts'],'input_size_counts':dict(collections.Counter(str(r['input_size']) for r in records if r['cohort']=='whole')),'joint_target_weights':weights,'whole_original_sources':len(sourcebyid),'no_cross_split_source_or_hash':True,'all_exact20':True,'whole_padding_or_cropping':False};dump(ROOT/'generation_audit.json',audit)
 selected=[]
 for cohort in ('whole','target'):
  subset=[r for r in records if r['cohort']==cohort];selected+=random.Random(928).sample(subset,4)
 canvas=Image.new('RGB',(900,len(selected)*240),'#eeeeee');draw=ImageDraw.Draw(canvas)
 for j,r in enumerate(selected):
  draw.text((3,j*240),f"{r['cohort']} {r['input_size']} q{r['extra_reduction']} {r['cell']}",fill='black')
  for k,key in enumerate(('clean_lr','sensor_lr','hr','roi')):
   pic=Image.open(data/r['files'][key]['path']).convert('RGB');pic.thumbnail((215,215),Image.Resampling.NEAREST if 'lr' in key else Image.Resampling.LANCZOS)
   # Tiny inputs shown as native pixels enlarged without inventing detail.
   if 'lr' in key:pic=Image.open(data/r['files'][key]['path']).convert('RGB');pic=pic.resize((round(pic.width*min(215/pic.width,215/pic.height)),round(pic.height*min(215/pic.width,215/pic.height))),Image.Resampling.NEAREST)
   canvas.paste(pic,(k*225,j*240+24));draw.text((k*225,j*240+10),key,fill='black')
 canvas.save(ROOT/'pair_review.jpg',quality=94);dump(ROOT/'review_selection.json',selected)
 with tarfile.open(ROOT/'data.tar','w') as tf:tf.add(data,arcname='data')
 print('V2_DATA_COMPLETE',audit,flush=True)
if __name__=='__main__':main()
