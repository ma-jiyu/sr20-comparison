"""Source-balanced real-aircraft x4 SwinIR adaptation with exact-state resume.

Only real scale4 train/val records are consumed; no test evaluation is present.
The first config freezes budget, data, weight bytes, loss and code before updates.
Required --protocol supplies an earlier freeze with the required keys
data_manifest_sha256, model, steps, reconstruction_steps, effective_batch.
"""
import argparse
import collections
import copy
from functools import lru_cache
import hashlib
import json
import math
import os
from pathlib import Path
import random
import time

import numpy as np
from PIL import Image
import torch
from torch.nn import functional as F

from .v5_baselines import SwinIRBaseline, SOURCES
from .prepare_reduction_v2 import sensor
from .train_matched import masked
from .train_reduction_v2 import scores
from .train_expansion_v3 import structural
from .train_research_v4 import perception
from .diagnose_v5_perceptual import pil_consistency


METRICS = ('full', 'roi', 'ssim_roi', 'edge_mae', 'lpips_roi', 'same_operator_lr_mae')
GUARD = {'roi_psnr_drop_db': .15, 'ssim_drop': .01, 'edge_ratio': 1.10}


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def dump(path, value):
    path = Path(path)
    tmp = path.with_name(path.name + '.tmp')
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf8')
    tmp.replace(path)


def export_model(model):
    return {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}


def capture_rng():
    return {'torch': torch.get_rng_state(), 'cuda': torch.cuda.get_rng_state_all() if torch.cuda.is_available() else [],
            'numpy': np.random.get_state(), 'python': random.getstate()}


def restore_rng(state):
    torch.set_rng_state(state['torch'])
    if state['cuda']:
        torch.cuda.set_rng_state_all(state['cuda'])
    np.random.set_state(state['numpy'])
    random.setstate(state['python'])


@lru_cache(maxsize=512)
def read_array(path, expected_hash, mode):
    assert sha(path) == expected_hash, f'Changed data file: {path}'
    with Image.open(path) as image:
        return np.asarray(image.convert(mode)).copy()


class RealAircraftData:
    def __init__(self, directory, seed):
        self.directory, self.seed = Path(directory), int(seed)
        self.manifest_path = self.directory / 'manifest.json'
        raw = json.loads(self.manifest_path.read_text(encoding='utf8'))
        self.manifest_sha256 = sha(self.manifest_path)
        # Never load test image files, sample test records, or evaluate test here.
        rows = [r for r in raw['records'] if r['split'] in ('train', 'val')
                and int(r['scale']) == 4 and r.get('synthetic') is False]
        assert rows and all(r['input_size'] == [20, 20] and r['reference_size'] == [80, 80] for r in rows)
        self.splits = {s: sorted((r for r in rows if r['split'] == s), key=lambda r: r['id']) for s in ('train', 'val')}
        assert all(self.splits.values())
        assert not ({r['source_group'] for r in self.splits['train']} & {r['source_group'] for r in self.splits['val']})
        self.groups = collections.defaultdict(list)
        for row in self.splits['train']:
            self.groups[row['source_group']].append(row)
        self.group_names = sorted(self.groups)

    def read(self, row, key, mode):
        entry = row['files'][key]
        path = (self.directory / entry['path']).resolve()
        path.relative_to(self.directory.resolve())
        return read_array(str(path), entry['sha256'], mode).copy()

    def choose(self, serial):
        gen = random.Random(self.seed * 100000000 + serial)
        return gen.choice(self.groups[gen.choice(self.group_names)])

    def batch(self, row, device, serial=None, regime='clean'):
        hr, roi, valid = self.read(row, 'hr', 'RGB'), self.read(row, 'roi', 'L'), self.read(row, 'valid', 'L')
        assert hr.shape == (80, 80, 3) and roi.shape == valid.shape == (80, 80)
        if serial is not None:
            assert row['split'] == 'train'
            rng = np.random.default_rng(self.seed * 100000000 + 50000000 + serial)
            turn, flip = int(rng.integers(4)), bool(rng.integers(2))
            hr, roi, valid = [np.rot90(a, turn).copy() for a in (hr, roi, valid)]
            if flip:
                hr, roi, valid = [a[:, ::-1].copy() for a in (hr, roi, valid)]
            if rng.random() < .65:
                gamma, gain = float(rng.uniform(.8, 1.2)), float(rng.uniform(.9, 1.1))
                hr = np.clip((hr.astype(np.float32)/255) ** gamma * gain, 0, 1)
                hr = (hr * 255).round().astype(np.uint8)
            clean = np.asarray(Image.fromarray(hr).resize((20, 20), Image.Resampling.BICUBIC)).copy()
            low = sensor(hr, (20, 20), int(rng.integers(2**31)))[0] if rng.random() < .5 else clean.copy()
        else:
            assert row['split'] == 'val' and regime in ('clean', 'sensor')
            clean, low = self.read(row, 'clean_lr', 'RGB'), self.read(row, regime+'_lr', 'RGB')
        def tensor(a):
            if a.ndim == 2:
                a = a[:, :, None]
            return torch.from_numpy(a.copy()).permute(2, 0, 1)[None].float().to(device) / 255
        return {k: tensor(v) for k, v in {'lr': low, 'hr': hr, 'roi': roi, 'valid': valid, 'clean_lr': clean}.items()}


def collate(items):
    return {key: torch.cat([item[key] for item in items], dim=0) for key in items[0]}


def losses(pred, batch, metric, perceptual_weight):
    mask = batch['valid'] * (1 + 2 * batch['roi'])
    reconstruction = masked((pred - batch['hr']).abs(), mask).mean()
    dx = (pred[..., 1:] - pred[..., :-1]) - (batch['hr'][..., 1:] - batch['hr'][..., :-1])
    dy = (pred[:, :, 1:] - pred[:, :, :-1]) - (batch['hr'][:, :, 1:] - batch['hr'][:, :, :-1])
    edge = .5 * (masked(dx.abs(), torch.minimum(mask[..., 1:], mask[..., :-1])).mean() +
                 masked(dy.abs(), torch.minimum(mask[:, :, 1:], mask[:, :, :-1])).mean())
    if perceptual_weight:
        perceptual = torch.stack([perception(metric, pred[i:i+1].clamp(0, 1),
                         {key: value[i:i+1] for key, value in batch.items()}) for i in range(len(pred))]).mean()
    else:
        perceptual = reconstruction.new_zeros(())
    total = reconstruction + .05 * edge + perceptual_weight * perceptual
    return total, {'l1': float(reconstruction.detach()), 'edge': float(edge.detach()), 'lpips': float(perceptual.detach())}


def schedule(step, steps):
    cosine = .1 + .9 * .5 * (1 + math.cos(math.pi * step / max(1, steps)))
    return 3e-5 * cosine * min(1, (step + 1) / 100)


def eligible(value, anchor):
    return (value['roi'] >= anchor['roi'] - GUARD['roi_psnr_drop_db'] and
            value['ssim_roi'] >= anchor['ssim_roi'] - GUARD['ssim_drop'] and
            value['edge_mae'] <= anchor['edge_mae'] * GUARD['edge_ratio'])


@torch.inference_mode()
def evaluate(model, data, metric, device, step, config_hash, work_path, deadline):
    model.eval()
    cases = [(r, regime) for r in data.splits['val'] for regime in ('clean', 'sensor')]
    rows = []
    if work_path.exists():
        partial = json.loads(work_path.read_text(encoding='utf8'))
        assert partial['step'] == step and partial['config_sha256'] == config_hash
        rows = partial['rows']
        assert [(r['id'], r['regime']) for r in rows] == [(r['id'], regime) for r, regime in cases[:len(rows)]]
    for row, regime in cases[len(rows):]:
        if deadline():
            dump(work_path, {'step': step, 'config_sha256': config_hash, 'rows': rows, 'partial': True})
            return None
        batch = data.batch(row, device, regime=regime)
        pred = model(batch['lr'])
        assert pred.shape == batch['hr'].shape and torch.isfinite(pred).all()
        roi = batch['roi'].clone() * batch['valid']
        roi[:, :, :4] = 0; roi[:, :, -4:] = 0; roi[:, :, :, :4] = 0; roi[:, :, :, -4:] = 0
        rows.append({'id': row['id'], 'source_group': row['source_group'], 'regime': regime,
            **scores(pred, batch['hr'], batch['valid'], batch['roi'], 4), **structural(pred, batch['hr'], roi),
            'lpips_roi': float(perception(metric, pred.clamp(0, 1), batch)),
            'same_operator_lr_mae': pil_consistency(pred, batch['clean_lr'])})
        if len(rows) % 16 == 0:
            dump(work_path, {'step': step, 'config_sha256': config_hash, 'rows': rows, 'partial': True})
    groups = collections.defaultdict(list)
    for row in rows:
        groups[row['source_group']].append(row)
    group_means = {g: {k: float(np.mean([r[k] for r in rs])) for k in METRICS} for g, rs in groups.items()}
    return {'step': step, 'config_sha256': config_hash, 'split': 'val', 'count': len(rows), 'groups': len(groups),
            'group_means': group_means, 'means': {k: float(np.mean([g[k] for g in group_means.values()])) for k in METRICS},
            'rows': rows, 'metric_scope': 'RGB x4 prediction against native/minified80px HR; shave4; equal source-group averages.'}


def smoke(model, optimizer, data, metric, args, config):
    assert not (args.run/'last.pt').exists() and not (args.run/'training_complete.json').exists()
    records = []
    for step in range(2):
        model.train(); optimizer.zero_grad(set_to_none=True)
        batch = data.batch(data.choose(step), args.device, serial=step)
        pred = model(batch['lr'])
        assert pred.shape == (1, 3, 80, 80) and torch.isfinite(pred).all()
        loss, components = losses(pred, batch, metric, .03)
        loss.backward()
        norm = torch.nn.utils.clip_grad_norm_(model.parameters(), 1, error_if_nonfinite=True)
        assert norm > 0 and torch.isfinite(loss)
        optimizer.step()
        records.append({'step': step+1, 'shape': list(pred.shape), 'loss': float(loss.detach()),
                        'gradient_norm': float(norm), 'components': components})
        if step == 0:
            checkpoint = {'model': export_model(model), 'optimizer': copy.deepcopy(optimizer.state_dict()), 'rng': capture_rng()}
            torch.save(checkpoint, args.run/'smoke_restore.pt')
    expected = export_model(model)
    restored = torch.load(args.run/'smoke_restore.pt', map_location='cpu', weights_only=False)
    model.load_state_dict(restored['model'], strict=True); optimizer.load_state_dict(restored['optimizer']); restore_rng(restored['rng'])
    model.train(); optimizer.zero_grad(set_to_none=True)
    batch = data.batch(data.choose(1), args.device, serial=1)
    replay, _ = losses(model(batch['lr']), batch, metric, .03)
    replay.backward(); torch.nn.utils.clip_grad_norm_(model.parameters(), 1, error_if_nonfinite=True); optimizer.step()
    error = max(float((value.detach().cpu()-expected[key]).abs().max()) for key, value in model.state_dict().items())
    assert error <= 1e-6, f'Optimizer/RNG resume parity failed: {error}'
    dump(args.run/'smoke_complete.json', {'complete': True, 'unique_updates': 2, 'resume_replay_updates': 1,
         'cases': records, 'resume_parameter_max_error': error, 'precision': 'float32',
         'gpu': torch.cuda.get_device_name() if args.device == 'cuda' else 'cpu', 'config': config})
    print('V5_SWINIR_SMOKE_COMPLETE', json.dumps(records), error, flush=True)


def main(args):
    import cv2
    import lpips
    begin = time.monotonic()
    cv2.setNumThreads(2); torch.set_num_threads(4)
    assert args.steps > args.reconstruction_steps > 0
    assert args.batch in (8, 16) and args.batch % args.microbatch == 0
    assert args.device != 'cuda' or torch.cuda.is_available()
    random.seed(args.seed); np.random.seed(args.seed); torch.manual_seed(args.seed)
    if torch.cuda.is_available():
        torch.backends.cudnn.benchmark = False
        torch.backends.cudnn.deterministic = True
        torch.backends.cuda.matmul.allow_tf32 = False
        torch.backends.cudnn.allow_tf32 = False
    args.run.mkdir(parents=True, exist_ok=True)
    data = RealAircraftData(args.data, args.seed)
    backbone = Path(torch.hub.get_dir())/'checkpoints/vgg16-397923af.pth'
    assert backbone.exists(), 'Pretrained VGG must be staged and verified; no automatic download'
    metric = lpips.LPIPS(net='vgg').to(args.device).eval().requires_grad_(False)
    model = SwinIRBaseline(args.model, args.assets, args.device)
    assert model.scale == 4
    optimizer = torch.optim.Adam(model.parameters(), lr=3e-5)
    code_names = ('train_v5_swinir.py', 'v5_baselines.py', 'prepare_reduction_v2.py', 'train_matched.py',
                  'train_reduction_v2.py', 'train_expansion_v3.py', 'train_research_v4.py', 'diagnose_v5_perceptual.py')
    config = {'version': 5, 'model': args.model, 'source_receipt': model.source_receipt, 'scale': 4,
        'steps': args.steps, 'reconstruction_steps': args.reconstruction_steps, 'effective_batch': args.batch,
        'microbatch': args.microbatch, 'seed': args.seed, 'precision': 'float32', 'smoke': args.smoke,
        'data_manifest_sha256': data.manifest_sha256, 'assets_manifest_sha256': sha(SOURCES),
        'vgg_sha256': sha(backbone), 'code_sha256': {name: sha(Path(__file__).parent/name) for name in code_names},
        'optimizer': 'Adam lr3e-5; cosine to0.1x,100stepwarmup;clipnorm1;no weightdecay',
        'loss': 'valid*(1+2*ROI) normalized L1 +.05 edge; after reconstruction_steps +.03 VGG ROI LPIPS',
        'data_sampling': 'real scale4 train only; uniform source/location then uniform instance; deterministic per serial',
        'augmentation': 'aligned D4 HR/ROI/valid;65% gamma[.8,1.2] gain[.9,1.1] onHR; then50%bicubic50%fresh bounded sensor',
        'validation': 'All real scale4 val clean+sensor; source-group macro;every500;no test consumption',
        'candidate_guard': GUARD, 'candidate_anchor': 'step0 on same new real validation',
        'selection': 'max ROI PSNR fidelity; lowest LPIPS among guard-eligible perceptual;step0 eligible',
        'train_pairs': len(data.splits['train']), 'train_groups': len(data.groups),
        'validation_pairs': len(data.splits['val']), 'validation_groups': len({r['source_group'] for r in data.splits['val']}),
        'protocol_sha256': sha(args.protocol) if args.protocol else None}
    if args.protocol:
        frozen = json.loads(args.protocol.read_text(encoding='utf8'))
        for key in ('data_manifest_sha256', 'model', 'steps', 'reconstruction_steps', 'effective_batch', 'microbatch', 'seed', 'scale'):
            assert frozen[key] == config[key], f'Frozen protocol mismatch: {key}'
        assert frozen['validation_interval'] == 500 and frozen['test_used_for_selection'] is False
        assert frozen['candidate_guard'] == {'roi_drop_db_max': GUARD['roi_psnr_drop_db'],
            'ssim_drop_max': GUARD['ssim_drop'], 'edge_ratio_max': GUARD['edge_ratio']}
    config_path = args.run/'config.json'
    if config_path.exists():
        assert json.loads(config_path.read_text(encoding='utf8')) == config, 'Frozen configuration changed; use a new run'
    else:
        dump(config_path, config)
    if args.smoke:
        smoke(model, optimizer, data, metric, args, config); return
    config_hash = sha(config_path)
    start, validated_step, best_f, best_p = 0, -1, -math.inf, math.inf
    selected = {'fidelity': None, 'perceptual': None}
    anchor = None

    def export(step, filename):
        tmp = args.run/(filename+'.tmp')
        torch.save({'model': export_model(model), 'step': step, 'config': config}, tmp)
        tmp.replace(args.run/filename)

    def save_last(step):
        tmp = args.run/'last.pt.tmp'
        torch.save({'model': export_model(model), 'optimizer': optimizer.state_dict(), 'step': step,
                    'validated_step': validated_step, 'best_f': best_f, 'best_p': best_p, 'selected': selected,
                    'anchor': anchor, 'rng': capture_rng(), 'config': config}, tmp)
        tmp.replace(args.run/'last.pt')
        dump(args.run/'state.json', {'step': step, 'steps': args.steps, 'validated_step': validated_step, 'selected': selected})

    if (args.run/'last.pt').exists():
        state = torch.load(args.run/'last.pt', map_location='cpu', weights_only=False)
        assert state['config'] == config
        model.load_state_dict(state['model'], strict=True); optimizer.load_state_dict(state['optimizer'])
        start, validated_step = state['step'], state['validated_step']
        best_f, best_p, selected, anchor = state['best_f'], state['best_p'], state['selected'], state['anchor']
        restore_rng(state['rng']); del state
    else:
        assert not (args.run/'training_complete.json').exists()
        save_last(0)
    if (args.run/'training_complete.json').exists():
        done = json.loads((args.run/'training_complete.json').read_text())
        assert start == args.steps == done['steps'] and validated_step == args.steps and done['complete']
        print('V5_SWINIR_ALREADY_COMPLETE', flush=True); return

    def near_deadline(buffer=120):
        return (time.monotonic()-begin >= args.max_seconds or
                time.time() >= float(os.environ.get('SLURM_JOB_END_TIME', 'inf'))-buffer)

    def validate(step):
        nonlocal validated_step, best_f, best_p, anchor
        path = args.run/f'validation_{step}.json'
        rng = capture_rng()
        if path.exists():
            value = json.loads(path.read_text(encoding='utf8'))
            assert value['config_sha256'] == config_hash and value['step'] == step
        else:
            value = evaluate(model, data, metric, args.device, step, config_hash,
                             args.run/f'validation_work_{step}.json', lambda: near_deadline(90))
        restore_rng(rng)
        if value is None:
            save_last(step); print('RESUMABLE_V5_VALIDATION_TIME_SLICE', step, flush=True); return False
        if step == 0:
            anchor = value['means']
        assert anchor is not None
        value['perceptual_eligible'] = eligible(value['means'], anchor)
        dump(path, value)
        if value['means']['roi'] > best_f:
            best_f = value['means']['roi']; selected['fidelity'] = step; export(step, 'best_fidelity.pt')
        if value['perceptual_eligible'] and value['means']['lpips_roi'] < best_p:
            best_p = value['means']['lpips_roi']; selected['perceptual'] = step; export(step, 'best_perceptual.pt')
        validated_step = step; save_last(step)
        print('V5_SWINIR_VALIDATION', step, json.dumps(value['means']), value['perceptual_eligible'], flush=True)
        return True

    if (start % 500 == 0 or start == args.steps) and validated_step < start:
        if not validate(start):
            return
    with (args.run/'progress.jsonl').open('a', encoding='utf8') as log:
        for step in range(start, args.steps):
            if near_deadline():
                save_last(step); print('RESUMABLE_V5_TRAIN_TIME_SLICE', step, flush=True); return
            model.train(); optimizer.zero_grad(set_to_none=True)
            lr, pw = schedule(step, args.steps), (.03 if step >= args.reconstruction_steps else 0.)
            for group in optimizer.param_groups:
                group['lr'] = lr
            total, details, tick = 0., collections.defaultdict(float), time.monotonic()
            for offset in range(0, args.batch, args.microbatch):
                serials = [step*args.batch+j for j in range(offset, offset+args.microbatch)]
                batch = collate([data.batch(data.choose(s), args.device, serial=s) for s in serials])
                pred = model(batch['lr'])
                assert pred.shape == batch['hr'].shape and torch.isfinite(pred).all()
                loss, components = losses(pred, batch, metric, pw)
                assert torch.isfinite(loss)
                fraction = args.microbatch/args.batch
                (loss*fraction).backward(); total += float(loss.detach())*fraction
                for key, value in components.items():
                    details[key] += value*fraction
            norm = torch.nn.utils.clip_grad_norm_(model.parameters(), 1, error_if_nonfinite=True)
            optimizer.step()
            row = {'step': step+1, 'loss': total, 'grad': float(norm), 'lr': lr, 'perceptual_weight': pw,
                   'seconds': time.monotonic()-tick, 'components': dict(details)}
            log.write(json.dumps(row)+'\n'); log.flush()
            if (step+1) % 25 == 0:
                print(json.dumps(row), flush=True)
            if (step+1) % 100 == 0:
                save_last(step+1)
            if (step+1) % 500 == 0 or step+1 == args.steps:
                save_last(step+1)
                if not validate(step+1):
                    return
    export(args.steps, 'final.pt'); save_last(args.steps)
    dump(args.run/'training_complete.json', {'complete': True, 'steps': args.steps, 'selected': selected,
        'config_sha256': config_hash, 'test_evaluated': False,
        'note': 'Pilot training and validation complete; no claimed native improvement without independent visual/test review.'})
    print('V5_SWINIR_TRAIN_COMPLETE', flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    for name in ('data', 'assets', 'run'):
        parser.add_argument('--'+name, required=True, type=Path)
    parser.add_argument('--protocol', type=Path, required=True)
    parser.add_argument('--model', default='swinir_classical_x4', choices=['swinir_classical_x4', 'swinir_real_psnr_x4'])
    parser.add_argument('--steps', default=6000, type=int)
    parser.add_argument('--reconstruction-steps', default=4000, type=int)
    parser.add_argument('--batch', default=8, type=int)
    parser.add_argument('--microbatch', default=4, type=int)
    parser.add_argument('--seed', default=1005, type=int)
    parser.add_argument('--device', default='cuda', choices=['cuda', 'cpu'])
    parser.add_argument('--max-seconds', default=100000, type=float)
    parser.add_argument('--smoke', action='store_true')
    main(parser.parse_args())
