"""Archive the V5 code and recorded provenance without changing experiment files.

This is a verified source/evidence archive, not a clean-environment reproduction.
Only the explicitly listed evidence and the static local Python dependency closure
are included. No images, checkpoints, site files, credentials or installed packages
are collected. Dynamic external CASR dependencies are documented, not vendored.
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import re
import zipfile


ENTRIES = (
    'prepare_v5_rareplanes', 'train_v5_swinir', 'train_v5_reconstruction',
    'v5_baselines', 'infer_v5_swinir', 'evaluate_v5_test_controls',
    'audit_v5_swinir', 'freeze_v5_reconstruction_candidates',
    'analyze_v5_results', 'compare_v5_loss_ablation',
)
ARMS = ('swinir_classical_x4', 'swinir_real_psnr_x4',
        'swinir_classical_reconstruction_x4')
SECRET_PATTERNS = (
    rb'-----BEGIN (?:RSA |EC |OPENSSH |DSA )?PRIVATE KEY-----',
    rb'\bgh[pousr]_[A-Za-z0-9]{30,}\b',
    rb'\bgithub_pat_[A-Za-z0-9_]{30,}\b',
    rb'\bsk-(?:proj-)?[A-Za-z0-9_-]{30,}\b',
    rb'\bAKIA[A-Z0-9]{16}\b',
    rb'(?i)(?:X-Amz-Signature|access_token|api_key|password)["\s]*[:=]["\s]*[A-Za-z0-9_+./=-]{16,}',
)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')


def read_json(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def local_closure(repo, entry_paths):
    """Resolve relative imports and existing absolute sr20 imports, without import."""
    package = (repo / 'sr20').resolve()
    queue, found, graph, external = list(entry_paths), set(), {}, set()
    while queue:
        path = queue.pop().resolve()
        if path in found:
            continue
        if not path.is_relative_to(package) or path.suffix != '.py':
            raise ValueError(f'Code dependency outside permitted package: {path}')
        found.add(path)
        deps = set()
        tree = ast.parse(path.read_text(encoding='utf-8-sig'), filename=str(path))
        for node in ast.walk(tree):
            module, base = None, None
            if isinstance(node, ast.ImportFrom):
                if node.level:
                    base = path.parent
                    for _ in range(node.level - 1):
                        base = base.parent
                    module = node.module or ''
                elif node.module and node.module.startswith('sr20'):
                    base, module = repo, node.module
                else:
                    external.add(node.module or '')
                if base is not None:
                    stem = base.joinpath(*module.split('.')) if module else base
                    candidates = [stem.with_suffix('.py'), stem / '__init__.py'] if module else [stem / '__init__.py']
                    if not module:
                        candidates += [stem / (alias.name + '.py') for alias in node.names]
                    resolved = [p.resolve() for p in candidates if p.is_file()]
                    if not resolved:
                        raise FileNotFoundError(f'Unresolved relative dependency in {path}: {ast.unparse(node)}')
                    deps.update(resolved)
            elif isinstance(node, ast.Import):
                for alias in node.names:
                    if alias.name.startswith('sr20.'):
                        stem = repo.joinpath(*alias.name.split('.'))
                        candidates = [stem.with_suffix('.py'), stem / '__init__.py']
                        resolved = [p.resolve() for p in candidates if p.is_file()]
                        if not resolved:
                            raise FileNotFoundError(f'Unresolved local import: {alias.name}')
                        deps.update(resolved)
                    else:
                        external.add(alias.name)
        graph[path.relative_to(repo).as_posix()] = sorted(p.relative_to(repo).as_posix() for p in deps)
        queue.extend(deps - found)
    return found, graph, sorted(external)


def main(args):
    repo, root = args.repo.resolve(), args.root.resolve()
    output = root / 'reproduction.zip'
    payload, records, source_snapshots = {}, {}, {}

    def add_bytes(name, body, category, source=None):
        posix = PurePosixPath(name)
        if posix.is_absolute() or '..' in posix.parts or '\\' in name:
            raise ValueError(f'Unsafe archive member: {name}')
        if name in payload:
            raise ValueError(f'Duplicate archive member: {name}')
        if posix.suffix.lower() not in ('.py', '.json', '.jsonl', '.txt'):
            raise ValueError(f'Forbidden member type: {name}')
        for pattern in SECRET_PATTERNS:
            if re.search(pattern, body):
                raise ValueError(f'Potential secret in {name}; archive not created')
        payload[name] = body
        records[name] = {'path': name, 'bytes': len(body), 'sha256': digest(body),
                         'category': category, 'source': str(source) if source else None}

    def add_file(path, name, category):
        path = path.resolve()
        body = path.read_bytes()
        add_bytes(name, body, category, path)
        source_snapshots[path] = digest(body)

    entries = [repo / 'sr20' / (name + '.py') for name in ENTRIES]
    closure, graph, external = local_closure(repo, entries)
    closure.add((repo / 'sr20/__init__.py').resolve())
    closure.add(Path(__file__).resolve())
    for path in sorted(closure):
        add_file(path, 'code/' + path.relative_to(repo).as_posix(), 'unchanged_local_python')

    # Non-Python data required by the official wrapper, explicitly allowlisted.
    source_manifest = repo / 'sr20/v5_baseline_sources.json'
    add_file(source_manifest, 'code/sr20/v5_baseline_sources.json', 'official_model_source_manifest')
    spec = read_json(source_manifest)
    arch = root / 'weights' / spec['architecture']['filename']
    assert digest(arch.read_bytes()) == spec['architecture']['sha256']
    add_file(arch, 'experiment/weights/' + arch.name, 'pinned_official_dynamic_architecture')
    evidence = [
        'rareplanes/data/manifest.json', 'rareplanes/source_plan_v2_frozen.json',
        'rareplanes/sources.json', 'rareplanes/data_audit.json',
        'rareplanes/overlap_deduplication.json', 'rareplanes/research_note.json',
        'rareplanes/metadata/LICENSE.txt', 'rareplanes/metadata/LICENSE.txt.source.json',
        'weights/asset_receipt.json', 'diagnostic_protocol.json',
    ] + [arm + '_training_protocol.json' for arm in ARMS]
    for rel in evidence:
        add_file(root / rel, 'experiment/' + rel, 'frozen_provenance')

    data_sha = digest(payload['experiment/rareplanes/data/manifest.json'])
    asset_sha = digest(payload['code/sr20/v5_baseline_sources.json'])
    environment, bindings, vgg = {}, [], set()
    for arm in ARMS:
        folder = root / 'training' / arm
        cfg = read_json(folder / 'config.json')
        progress_path = folder / 'progress.jsonl'
        progress = [json.loads(line) for line in progress_path.read_text(encoding='utf-8').splitlines() if line.strip()]
        assert cfg['data_manifest_sha256'] == data_sha
        assert cfg['assets_manifest_sha256'] == asset_sha
        assert [row['step'] for row in progress] == list(range(1, cfg['steps'] + 1))
        protocol_name = arm + '_training_protocol.json'
        assert cfg['protocol_sha256'] == digest(payload['experiment/' + protocol_name])
        for name, expected in cfg['code_sha256'].items():
            member = 'code/sr20/' + name
            if member not in payload or digest(payload[member]) != expected:
                raise ValueError(f'Trained code bytes differ from archived source: {arm}/{name}')
            bindings.append({'arm': arm, 'member': member, 'sha256': expected, 'matches_training_record': True})
        for path in sorted(folder.iterdir()):
            if path.name in ('config.json', 'progress.jsonl', 'training_complete.json', 'summary.json') or (path.name.startswith('validation') and path.suffix == '.json'):
                add_file(path, 'experiment/training/' + arm + '/' + path.name, 'recorded_training_evidence')
        vgg.add(cfg['vgg_sha256'])
        env_names = ('python_version', 'torch_version', 'pytorch_version', 'cuda_version', 'cudnn_version', 'gpu', 'gpu_name', 'environment', 'versions')
        version_evidence = {k: cfg[k] for k in env_names if k in cfg}
        progress_evidence = [{k: row[k] for k in env_names if k in row} for row in progress if any(k in row for k in env_names)]
        environment[arm] = {
            'sources': ['experiment/training/' + arm + '/config.json', 'experiment/training/' + arm + '/progress.jsonl'],
            'explicit_environment_fields_in_config': version_evidence,
            'explicit_environment_fields_in_progress': progress_evidence,
            'python_pytorch_cuda_versions_recorded': bool(version_evidence or progress_evidence),
            'not_recorded': ['Python runtime version', 'PyTorch package version', 'CUDA/cuDNN versions', 'GPU model', 'complete pip/conda lock'],
            'observed_configuration': {k: cfg[k] for k in ('precision', 'steps', 'reconstruction_steps', 'effective_batch', 'microbatch', 'seed', 'optimizer', 'scale')},
            'observed_progress': {'rows': len(progress), 'first_step': progress[0]['step'], 'last_step': progress[-1]['step'],
                                  'perceptual_weights': sorted({row['perceptual_weight'] for row in progress})},
            'warning': 'Local packaging runtime is not evidence of the historical GPU training runtime. No package versions inferred.',
        }
    assert len(vgg) == 1
    add_bytes('TRAINING_ENVIRONMENT_EVIDENCE.json', encoded(environment), 'derived_evidence')
    after_training = root / 'environment_after_training.json'
    if after_training.is_file():
        add_file(after_training, 'experiment/environment_after_training.json', 'post_training_environment_observation')
    add_bytes('TRAINED_CODE_BYTE_BINDINGS.json', encoded(bindings), 'derived_evidence')
    add_bytes('STATIC_DEPENDENCIES.json', encoded({
        'entrypoints': ['sr20/' + name + '.py' for name in ENTRIES], 'edges': graph,
        'external_imports_not_vendored': external,
        'dynamic_architecture_included': 'experiment/weights/' + arch.name,
        'casr_external_dependencies': 'src.* and _common occur inside optional historical CASR methods. They are not part of this SwinIR experiment and are not archived.',
        'third_party_installations_not_included': ['torch', 'torchvision', 'timm', 'numpy', 'Pillow', 'opencv-python', 'lpips', 'requests', 'matplotlib'],
        'static_scan_limit': 'Relative imports and local absolute sr20 imports only. This is not proof that every optional runtime branch is self-contained.',
    }), 'derived_evidence')
    add_bytes('REQUIRED_EXTERNAL_ASSETS.json', encoded({
        'official_swinir': {'source_manifest': 'code/sr20/v5_baseline_sources.json', 'download_receipt': 'experiment/weights/asset_receipt.json',
                            'weights_included': False, 'note': 'SHA256 values are local observations of official downloads; legacy publisher SHA256 was unavailable.'},
        'lpips_vgg16': {'required_sha256_recorded_by_all_training_configs': next(iter(vgg)), 'cache_relative_path': 'hub/checkpoints/vgg16-397923af.pth',
                       'source_url_recorded_in_training_config': None, 'weights_included': False, 'note': 'Obtain the official torchvision pretrained VGG16 asset and stage the exact recorded bytes. lpips package calibration assets/version must also be supplied; version was not recorded.'},
        'rareplanes': {'source_receipts': 'experiment/rareplanes/sources.json', 'license': 'experiment/rareplanes/metadata/LICENSE.txt', 'original_images_included': False,
                       'pair_images_included': False, 'frozen_manifest_sha256': data_sha},
        'legacy_controls': {'weights_included': False, 'required': 'old C20_sensor, B_real best_perceptual 20000/final30000 and RealESRNet initialization, at the paths expected by diagnose_v5_controls.py. Obtain original audited experiment artifacts; there is no claim these custom weights are official releases.'},
    }), 'derived_evidence')

    readme = f'''Aircraft SR V5 — source and evidence archive

STATUS
This ZIP preserves the exact local source bytes and experiment records listed in
ARCHIVE_MANIFEST.json. CRC and extracted-byte SHA256 are verified. It is NOT an
experiment already reproduced in a clean environment, a portable training image,
or proof of numerical reproducibility on another GPU/software stack.

CONTENTS
code/sr20/: ten requested entrypoints and recursive static relative Python
dependencies, package initializer and this packager. Training-referenced code
SHA256 values are checked against all three recorded config.json files.
experiment/: three prospective training protocols, native-pair manifest, data
source plan/URL/hash receipts, RarePlanes license, official SwinIR receipt and
pinned network_swinir.py, training config/progress/validation/completion records.
No credentials, raw images, generated pair images, model weights, installed
packages, other projects, websites or SSH configuration are included.

RECORDED TRAINING ENVIRONMENT
The three actual config/progress records specify float32, seed 1005, effective
batch 8, microbatch 4, 6000 updates and the recorded Adam/cosine schedule.
Original classical and real-PSNR use reconstruction_steps=4000; the reconstruction
control uses 6000 and progress confirms perceptual_weight=0 throughout.
Python, PyTorch, CUDA/cuDNN, GPU model and dependency versions were NOT recorded
in those files. They are intentionally not invented here. The computer running
this archive builder is not the historical training environment.
See TRAINING_ENVIRONMENT_EVIDENCE.json for exact source attribution.
experiment/environment_after_training.json, when present, records a later read
from the same server interpreter. It is useful setup evidence, not a training-time
lockfile or proof that dependencies never changed.
Required third-party packages include torch/torchvision/timm/numpy/Pillow/OpenCV,
lpips/requests/matplotlib. This is an unpinned dependency list, not an environment lock.

DATA AND LICENSING
RarePlanes real imagery: follow the official source URLs in sources.json and
LICENSE.txt (CC BY-SA 4.0) and preserve attribution: RarePlanes Dataset, Shermeyer
et al. (2020), In-Q-Tel CosmiQ Works and AI.Reverie; real imagery Maxar WorldView-3.
Our paired crops are minified from native HR, with computational LR degradation.
The frozen manifest contains x4: 385 train / 61 val / 78 test instances across
20 / 4 / 4 locations. x8 is a smaller ancillary set; do not pool resolutions.
Official test locations are excluded from source selection. This experiment's
held-out test must remain unavailable for training or candidate selection.
Geographic object IDs do not prove globally distinct physical airframes. Geographic
overlap with all older source datasets is not fully excluded.
Frozen manifest SHA256: {data_sha}
Neither source imagery nor pair PNG files are bundled. Acquire from official
URLs and verify all source/pair hashes. prepare_v5_rareplanes.py also requires the
prior matched_sources.json catalogue at its PRIOR path to reproduce exclusions;
that historical catalogue is not bundled. Its SHA/excluded locations are recorded
in source_plan_v2_frozen.json. A new data regeneration has not been tested here.

OFFICIAL MODELS AND OTHER ASSETS
Obtain official SwinIR assets from the pinned repository/release URLs in
code/sr20/v5_baseline_sources.json. Verify against experiment/weights/asset_receipt.json.
The release publisher did not supply SHA256; these are locally observed download
hashes, not signed publisher digests. Follow the upstream Apache-2.0 license.
The exact official architecture file is bundled because it is dynamically loaded.
Pretrained VGG16 required by the recorded LPIPS evaluator has SHA256:
{next(iter(vgg))}
Stage it in the torch hub checkpoint cache. LPIPS package/calibration/version also
needs to be provided. Existing old/B20/B30 controls and native8000 inputs require
the original audited artifacts; their model/image bytes are not bundled.
Optional historical CASR branches import an external CASR checkout, src.* and
_common dynamically; that separate project is not copied and is not required for
the V5 SwinIR training path. This ZIP does not independently reproduce old CASR work.

PATHS AND OPERATION (examples, not commands already rerun)
Extract, enter code/, then use python -m sr20.<entrypoint> --help.
Reconfigure --data, --assets, --run, --protocol, --root, --selection and --output
to your own absolute paths. Frozen records retain their original values; keep
an unchanged evidence copy. Any adapted source gets a new hash/experiment ID.
To retrieve official SwinIR assets explicitly:
  python -m sr20.v5_baselines prepare --assets YOUR_ASSET_DIRECTORY
Compare resulting hashes to the preserved official download receipt.
Training reconstruction example after acquiring/verifying data/assets/environment:
  python -m sr20.train_v5_reconstruction --data YOUR_RARE_DATA --assets YOUR_ASSETS --run NEW_RUN --protocol YOUR_RECONSTRUCTION_PROTOCOL --model swinir_classical_x4 --steps 6000 --reconstruction-steps 6000 --batch 8 --microbatch 4 --seed 1005 --device cuda
Original classical/real-PSNR use train_v5_swinir with reconstruction-steps 4000
and their own frozen protocol/model name. Never mix their run directories.
Candidate selection/visual review must precede freeze_v5_reconstruction_candidates;
only then use infer_v5_swinir and evaluate_v5_test_controls. Final test is not a
hyperparameter-selection loop. Native 20-to-80 learned output and 400-pixel
display interpolation must remain separately labeled.
analyze_v5_results / compare_v5_loss_ablation require saved run/evaluation records;
some commands additionally require the original native manifest/selection and
data bytes. The ZIP preserves code and bounded evidence, not every runtime input.

ARCHIVE INTEGRITY
ARCHIVE_MANIFEST.json lists SHA256/size for each member except itself (self-hashing
would be recursive). The external reproduction_verification.json gives the ZIP
and manifest SHA256 and the full CRC/extracted-byte verification result.
The builder rereads every source file after building and refuses publication if
its bytes changed during packaging. It never rewrites trained code/config/data.
'''
    add_bytes('README.txt', readme.encode('utf-8'), 'archive_documentation')
    manifest = {'schema_version': 'v5.source_archive.1', 'purpose': 'Local verified code/provenance archive; clean-environment reproduction not performed',
                'entrypoints': ['code/sr20/' + name + '.py' for name in ENTRIES],
                'files': [records[k] for k in sorted(records)],
                'exclusion_policy': 'Only static local Python closure and explicit JSON/JSONL/TXT evidence allowlist. No model/image/archive payloads, installed packages or unrelated projects.',
                'self_excluded': ['ARCHIVE_MANIFEST.json'], 'source_files_modified_by_packager': False,
                'clean_environment_reproduction_performed': False}
    manifest_bytes = encoded(manifest)
    payload['ARCHIVE_MANIFEST.json'] = manifest_bytes
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for name in sorted(payload):
            info = zipfile.ZipInfo(name, date_time=(2026, 10, 5, 0, 0, 0))
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            archive.writestr(info, payload[name])
    zip_bytes = buffer.getvalue()
    # Decode every member and test its CRC, then check exact extracted-byte SHA.
    with zipfile.ZipFile(io.BytesIO(zip_bytes)) as archive:
        assert archive.testzip() is None
        assert len(archive.namelist()) == len(set(archive.namelist())) == len(payload)
        assert set(archive.namelist()) == set(payload)
        for name, expected in payload.items():
            extracted = archive.read(name)
            assert len(extracted) == len(expected) and digest(extracted) == digest(expected)
    for path, expected in source_snapshots.items():
        if digest(path.read_bytes()) != expected:
            raise RuntimeError(f'Source changed while packaging; no archive written: {path}')

    verification = {'schema_version': 'v5.source_archive_verification.1', 'zip': str(output),
                    'zip_sha256': digest(zip_bytes), 'zip_bytes': len(zip_bytes),
                    'manifest_sha256': digest(manifest_bytes), 'member_count': len(payload),
                    'payload_member_count': len(records), 'zip_crc_all_passed': True,
                    'all_extracted_bytes_sha256_passed': True, 'source_files_unchanged': True,
                    'training_code_bindings_verified': len(bindings), 'credential_pattern_scan_passed': True,
                    'scan_limit': 'Bounded allowlist plus private-key/common-token-pattern checks; not a universal secret detector.',
                    'clean_environment_reproduction_performed': False, 'test_image_payloads_read': False}
    outputs = {output: zip_bytes, root / 'reproduction_manifest.json': manifest_bytes,
               root / 'reproduction_README.txt': readme.encode('utf-8'),
               root / 'reproduction_verification.json': encoded(verification)}
    for path, body in outputs.items():
        if path.exists() and path.read_bytes() != body:
            raise FileExistsError(f'Refusing to overwrite different existing archive artifact: {path}')
    for path, body in outputs.items():
        if not path.exists():
            with path.open('xb') as stream:
                stream.write(body)
    assert digest(output.read_bytes()) == verification['zip_sha256']
    print(json.dumps(verification, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--repo', type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument('--root', type=Path, default=Path('D:/超分实验/飞机超分突破诊断_20261005'))
    main(parser.parse_args())
