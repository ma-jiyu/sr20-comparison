"""Compare completed V5 classical loss schedules without consuming test images.

Uses saved validation rows and logs, not native-image pseudo ground truth.
Refuses partial runs. The only expected implementation changes are the budget
assertion and the reconstruction trainer's additional self fingerprint.
"""
import argparse
import ast
import collections
import difflib
import hashlib
import json
import math
from pathlib import Path
import statistics


METRICS = ('full', 'roi', 'ssim_roi', 'edge_mae', 'lpips_roi', 'same_operator_lr_mae')
ORIGINAL = 'swinir_classical_x4'
RECONSTRUCTION = 'swinir_classical_reconstruction_x4'
EXPECTED_REVIEW_SHA = 'baa709df710a934b33268abbd9723360ca0e0127b737bb09ef04290f85b8ac73'


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def differences(a, b, prefix=''):
    if isinstance(a, dict) and isinstance(b, dict):
        result = []
        for key in sorted(a.keys() | b.keys()):
            p = prefix + ('.' if prefix else '') + key
            if key not in a or key not in b:
                result.append({'field': p, 'original': a.get(key), 'reconstruction': b.get(key)})
            else:
                result.extend(differences(a[key], b[key], p))
        return result
    return [] if a == b else [{'field': prefix, 'original': a, 'reconstruction': b}]


def macro(rows):
    groups = collections.defaultdict(list)
    for row in rows:
        groups[row['source_group']].append(row)
    assert groups
    group_means = {g: {m: statistics.fmean(float(r[m]) for r in rs) for m in METRICS}
                   for g, rs in sorted(groups.items())}
    assert all(math.isfinite(v) for ms in group_means.values() for v in ms.values())
    return {m: statistics.fmean(g[m] for g in group_means.values()) for m in METRICS}, group_means


def delta(a, b):
    """Reconstruction minus original; positive is not uniformly better."""
    return {m: b[m] - a[m] for m in METRICS}


def load_run(root, name):
    run = root / 'training' / name
    cfg_path, done_path = run / 'config.json', run / 'training_complete.json'
    cfg, done = read(cfg_path), read(done_path)
    assert done['complete'] is True and done['steps'] == cfg['steps'] == 6000, 'Run is incomplete'
    assert done['test_evaluated'] is False and done['config_sha256'] == sha(cfg_path)
    protocol_path = root / (name + '_training_protocol.json')
    protocol = read(protocol_path)
    assert cfg['protocol_sha256'] == sha(protocol_path)
    assert protocol['test_used_for_selection'] is False
    sources = [cfg_path, done_path, protocol_path, run / 'progress.jsonl']
    vals, identities, recompute_max_error = {}, None, 0.
    for step in range(0, 6001, 500):
        p = run / f'validation_{step}.json'
        v = read(p)
        assert v['step'] == step and v['split'] == 'val' and v['config_sha256'] == sha(cfg_path)
        rows = v['rows']
        ids = [(r['id'], r['regime'], r['source_group']) for r in rows]
        assert len(ids) == len(set(ids)) == v['count'] == 122
        assert {r['regime'] for r in rows} == {'clean', 'sensor'}
        if identities is None:
            identities = ids
        assert ids == identities, 'Validation order or membership changed'
        means, group_means = macro(rows)
        assert len(group_means) == v['groups'] == 4
        errors = [abs(means[m] - v['means'][m]) for m in METRICS]
        errors += [abs(ms[m] - v['group_means'][g][m])
                   for g, ms in group_means.items() for m in METRICS]
        recompute_max_error = max(recompute_max_error, *errors)
        assert max(errors) < 1e-10, 'Saved macro averages do not match validation rows'
        vals[step] = {'means': means, 'groups': group_means, 'rows': rows,
                      'by_regime': {s: macro([r for r in rows if r['regime'] == s])[0]
                                    for s in ('clean', 'sensor')}}
        sources.append(p)
    progress = [json.loads(line) for line in (run / 'progress.jsonl').read_text().splitlines() if line.strip()]
    assert [r['step'] for r in progress] == list(range(1, 6001)), 'Missing/repeated training log updates'
    for r in progress:
        assert r['perceptual_weight'] == (.03 if r['step'] > cfg['reconstruction_steps'] else 0.)
        expected = r['components']['l1'] + .05*r['components']['edge'] + r['perceptual_weight']*r['components']['lpips']
        assert abs(expected - r['loss']) < 1e-6, 'Logged loss components do not compose to loss'
    return {'config': cfg, 'protocol': protocol, 'completion': done, 'vals': vals, 'progress': progress,
            'identities': identities, 'recompute_max_error': recompute_max_error,
            'sources': [{'path': str(p), 'sha256': sha(p)} for p in sources]}


def code_check(a, b, code_dir):
    old_path, new_path = code_dir/'train_v5_swinir.py', code_dir/'train_v5_reconstruction.py'
    old, new = old_path.read_text(encoding='utf-8-sig'), new_path.read_text(encoding='utf-8-sig')
    assert sha(old_path) == a['code_sha256']['train_v5_swinir.py']
    assert sha(new_path) == b['code_sha256']['train_v5_reconstruction.py']
    normalized = new.replace('assert args.steps >= args.reconstruction_steps > 0',
                             'assert args.steps > args.reconstruction_steps > 0')
    normalized = normalized.replace("code_names = ('train_v5_reconstruction.py', ", 'code_names = (')
    exact_ast_match = ast.dump(ast.parse(old), include_attributes=False) == ast.dump(ast.parse(normalized), include_attributes=False)
    dependency_checks = []
    for name, digest in a['code_sha256'].items():
        p = code_dir/name
        dependency_checks.append({'file': name, 'same_recorded_hash': b['code_sha256'].get(name) == digest,
                                  'local_file_matches_recorded': p.exists() and sha(p) == digest})
    return {'expected_source_changes_only': exact_ast_match,
            'allowed_changes': ['Allow reconstruction_steps == total_steps', 'Add train_v5_reconstruction.py self fingerprint'],
            'source_diff': list(difflib.unified_diff(old.splitlines(), new.splitlines(),
                                fromfile='train_v5_swinir.py', tofile='train_v5_reconstruction.py', lineterm='')),
            'shared_dependency_fingerprints': dependency_checks,
            'dependencies_all_identical': all(x['same_recorded_hash'] and x['local_file_matches_recorded'] for x in dependency_checks)}


def log_phase(rows, lo, hi):
    part = [r for r in rows if lo <= r['step'] <= hi]
    fields = ('loss', 'grad', 'lr', 'perceptual_weight')
    return {'first_update': lo, 'last_update': hi, 'count': len(part),
            'mean': {k: statistics.fmean(r[k] for r in part) for k in fields},
            'component_mean': {k: statistics.fmean(r['components'][k] for r in part)
                               for k in ('l1', 'edge', 'lpips')},
            'perceptual_weights_observed': sorted({r['perceptual_weight'] for r in part})}


def input_check(root, config, validation_ids):
    directory = root/'rareplanes/data'
    manifest_path = directory/'manifest.json'
    assert sha(manifest_path) == config['data_manifest_sha256']
    manifest = read(manifest_path)
    rows = [r for r in manifest['records'] if r['split'] in ('train','val')
            and r['scale'] == 4 and r.get('synthetic') is False]
    train, val = ([r for r in rows if r['split'] == split] for split in ('train','val'))
    assert len(train) == config['train_pairs'] == 385
    assert len(val) == config['validation_pairs'] == 61
    train_groups, val_groups = ({r['source_group'] for r in rs} for rs in (train,val))
    assert len(train_groups) == 20 and len(val_groups) == 4 and not train_groups & val_groups
    expected = [(r['id'],s,r['source_group']) for r in sorted(val,key=lambda r:r['id'])
                for s in ('clean','sensor')]
    assert validation_ids == expected
    count = 0
    for row in rows:
        for key in ('hr','roi','valid','clean_lr','sensor_lr'):
            entry = row['files'][key]
            p = (directory/entry['path']).resolve()
            p.relative_to(directory.resolve())
            assert sha(p) == entry['sha256'], f'Changed train/val input: {p}'
            count += 1
    return {'manifest_path':str(manifest_path),'manifest_sha256':sha(manifest_path),
            'train_pairs':len(train),'val_pairs':len(val),'train_groups':len(train_groups),
            'val_groups':len(val_groups),'train_val_file_hashes_verified':count,
            'validation_rows_exactly_match_frozen_val_split':True,
            'test_payload_read':False,'note':'Manifest metadata includes all split names; no test image payload opened.'}


def compare(root, output, code_dir, tolerance):
    a, b = load_run(root, ORIGINAL), load_run(root, RECONSTRUCTION)
    ac, bc = a['config'], b['config']
    assert ac['reconstruction_steps'] == 4000 and bc['reconstruction_steps'] == 6000
    assert a['identities'] == b['identities']
    inputs = input_check(root,ac,a['identities'])
    cfg_diffs = differences(ac, bc)
    allowed = {'reconstruction_steps', 'protocol_sha256', 'code_sha256.train_v5_reconstruction.py'}
    unexplained = [d for d in cfg_diffs if d['field'] not in allowed]
    protocol_invariants = ('data_manifest_sha256', 'model', 'steps', 'effective_batch', 'microbatch', 'seed',
                           'scale', 'validation_interval', 'test_used_for_selection', 'input_size',
                           'learned_output_size', 'display_only_size', 'candidate_guard')
    protocol_checks = {k: a['protocol'][k] == b['protocol'][k] for k in protocol_invariants}
    code = code_check(ac, bc, code_dir)
    assert b['protocol']['trainer_sha256'] == bc['code_sha256']['train_v5_reconstruction.py']
    review_path = root/'final_preview/independent_visual_review.json'
    assert sha(review_path) == EXPECTED_REVIEW_SHA, 'Original visual-review evidence changed'
    review = read(review_path)
    grid = review['candidate_gate_proposals']['classical']
    assert grid['pass_narrow_visual_gate'] is False
    assert grid['checkpoint_sha256'] == b['protocol']['rejected_parent_checkpoint_sha256']
    checkpoints, before, per_metric_max = [], [], {m: 0. for m in METRICS}
    row_metric_max = {m: 0. for m in METRICS}
    for step in a['vals']:
        av, bv = a['vals'][step], b['vals'][step]
        d = delta(av['means'], bv['means'])
        paired_max = {m: max(abs(y[m]-x[m]) for x,y in zip(av['rows'],bv['rows'])) for m in METRICS}
        checkpoints.append({'step': step, 'original': av['means'], 'reconstruction': bv['means'],
                            'delta_reconstruction_minus_original': d,
                            'by_regime': {s: {'original': av['by_regime'][s], 'reconstruction': bv['by_regime'][s],
                                              'delta': delta(av['by_regime'][s], bv['by_regime'][s])}
                                           for s in ('clean', 'sensor')},
                            'group_delta': {g: delta(av['groups'][g], bv['groups'][g]) for g in av['groups']},
                            'per_row_max_abs_metric_difference': paired_max})
        if step <= 4000:
            before.append({'step': step, 'mean_max_abs_difference': max(map(abs,d.values())),
                           'within_tolerance': all(abs(v) <= tolerance for v in d.values())})
            for m in METRICS:
                per_metric_max[m] = max(per_metric_max[m], abs(d[m]))
                row_metric_max[m] = max(row_metric_max[m], paired_max[m])
    phase_logs = {arm: [log_phase(run['progress'],1,4000),log_phase(run['progress'],4001,6000)]
                  for arm,run in (('original',a),('reconstruction',b))}
    log_parity = {k: max(abs(x[k]-y[k]) for x,y in zip(a['progress'][:4000],b['progress'][:4000]))
                  for k in ('loss','grad','lr')}
    lr_difference = max(abs(x['lr']-y['lr']) for x,y in zip(a['progress'],b['progress']))
    verified = not unexplained and all(protocol_checks.values()) and code['expected_source_changes_only'] and code['dependencies_all_identical'] and lr_difference == 0
    final_change = {arm: delta(run['vals'][4000]['means'],run['vals'][6000]['means'])
                    for arm,run in (('original',a),('reconstruction',b))}
    result = {'schema_version':'v5.loss_ablation.1', 'analysis_script':{'path':str(Path(__file__).resolve()),'sha256':sha(__file__)},
      'complete':True, 'test_images_read':False, 'test_metrics_used_for_selection':False,
      'scope':'Saved paired real-aircraft validation only. No native PSNR/SSIM or native ground-truth inference.',
      'design':{'original':'6000 updates; L1+.05 edge through4000, plus .03 ROI LPIPS on updates4001..6000',
                'reconstruction':'6000 updates; L1+.05 edge throughout; same LR schedule',
                'experimental_units':'61 validation objects in4 held-out locations, each clean/sensor;122 cases are not122 independent objects',
                'weighting':'Within-location case mean, then equal-location mean; regime summaries use the same4-location macro weighting',
                'native_display':'20px input ->80px learned output;400px interpolation display only'},
      'loss_change_isolation_verified':verified,
      'configuration_check':{'all_differences':cfg_diffs,'unexplained_differences':unexplained,
                             'protocol_invariant_matches':protocol_checks,'protocol_all_differences':differences(a['protocol'],b['protocol']),
                             'code':code,'inputs':inputs,'all_step_lr_max_abs_difference':lr_difference,
                             'batch_identity_limitation':'Same seed, serial-indexed sampler and augmentation code imply identical sampling; no per-update input-tensor hashes were logged.'},
      'pre_loss_change_parity':{'validation_steps':'0..4000 inclusive, every500', 'absolute_tolerance':tolerance,
          'mean_metrics_all_within_tolerance':all(x['within_tolerance'] for x in before),
          'per_metric_mean_max_abs_difference':per_metric_max,'per_row_metric_max_abs_difference':row_metric_max,
          'checkpoints':before,'first4000_training_log_max_abs_difference':log_parity,
          'prediction_pixel_identity_verified':False,
          'interpretation':'Compares saved validation metrics, not image tensors or parameter equality. Deviations are reported, not suppressed or automatically rejected; hardware/software numerics may differ, but this file does not attribute causality without environment evidence.'},
      'validation_checkpoints':checkpoints,'training_loss_phases':phase_logs,
      'change_4000_to_6000':final_change,
      'phase_difference_of_changes_reconstruction_minus_original':delta(final_change['original'],final_change['reconstruction']),
      'metric_directions':{'full':'higher','roi':'higher','ssim_roi':'higher','edge_mae':'lower','lpips_roi':'lower','same_operator_lr_mae':'lower'},
      'clean_lr_definition':'same_operator_lr_mae downsamples prediction with matching PIL bicubic and compares with clean LR, including sensor-input cases; it is not native truth.',
      'native_artifact_evidence':{'path':str(review_path),'sha256':sha(review_path),'checkpoint_sha256':grid['checkpoint_sha256'],
                                  'finding':grid['reason_zh'],'review':'Labeled nonblind model visual review; separate from paired validation metrics'},
      'limitations':['A single seed and four validation locations do not establish population-wide generalization or causal certainty.',
                     'Only the training loss schedule is intended to differ; final candidate selection policy also differs and is disclosed in protocol differences.',
                     'Equal-step 6000 comparisons are the loss ablation; best-checkpoint selection is not used to substitute unequal steps here.',
                     'Total training loss values are not directly comparable after4000 because one arm includes an LPIPS term.',
                     'No new-arm native artifact disappearance can be claimed from numeric metrics; requires separate actual image review.',
                     'Any parity failure must be reported and investigated rather than assuming identical trajectories.'],
      'sources':{'original':a['sources'],'reconstruction':b['sources']},
      'saved_macro_recompute_max_error':{'original':a['recompute_max_error'],'reconstruction':b['recompute_max_error']}}
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'output':str(output),'sha256':sha(output),'loss_change_isolation_verified':verified,
                      'pre4000_metric_parity':result['pre_loss_change_parity']['mean_metrics_all_within_tolerance'],
                      'step6000_delta':checkpoints[-1]['delta_reconstruction_minus_original']},ensure_ascii=False))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=Path('D:/超分实验/飞机超分突破诊断_20261005'))
    parser.add_argument('--output',type=Path)
    parser.add_argument('--code-dir',type=Path,default=Path(__file__).resolve().parent)
    parser.add_argument('--parity-tolerance',type=float,default=1e-6)
    args=parser.parse_args()
    assert args.parity_tolerance > 0
    compare(args.root,args.output or args.root/'analysis/loss_ablation_comparison.json',args.code_dir,args.parity_tolerance)
