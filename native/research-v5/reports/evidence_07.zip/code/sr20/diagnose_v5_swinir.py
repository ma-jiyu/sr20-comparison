"""Validation-only official x4/x8 SwinIR diagnosis; no test-based selection.

Legacy comparisons use exactly the legacy HR canvas. A new occupancy-matched
manifest can be supplied with --rare-data, and its effective grids are reported
separately. Learned resolution is recorded independently of display resolution.
The parent controller owns GPU job submission; this script never submits jobs.
"""
from __future__ import annotations

import argparse
import collections
import json
from pathlib import Path

import numpy as np
from PIL import Image
import torch
from torch.nn import functional as F

from .v5_baselines import SwinIRBaseline, display_resize, sha256, source_manifest
from .research_v4_data import PairedData
from .train_research_v4 import perception
from .train_reduction_v2 import scores
from .train_expansion_v3 import structural


METRICS = ("full", "roi", "ssim_roi", "edge_mae", "lpips_roi", "lowfreq_mae", "same_operator_lr_mae")


def dump(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    tmp.replace(path)


def save_image(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    array = value[0].clamp(0, 1).mul(255).round().byte().permute(1, 2, 0).cpu().numpy()
    Image.fromarray(array).save(path)
    return {"path": str(path), "sha256": sha256(path), "size_hw": list(value.shape[-2:])}


def tensor(path, device, mode="RGB"):
    value = np.asarray(Image.open(path).convert(mode)).copy()
    if value.ndim == 2:
        value = value[:, :, None]
    return torch.from_numpy(value).permute(2, 0, 1)[None].float().to(device) / 255


def same_operator_mae(pred, clean):
    array = pred[0].clamp(0, 1).mul(255).round().byte().permute(1, 2, 0).cpu().numpy()
    down = np.asarray(Image.fromarray(array).resize((clean.shape[-1], clean.shape[-2]), Image.Resampling.BICUBIC)).copy()
    down = torch.from_numpy(down).permute(2, 0, 1)[None].to(clean) / 255
    return float(F.l1_loss(down, clean))


def metrics(pred, batch, metric, shave):
    assert pred.shape == batch["hr"].shape and torch.isfinite(pred).all()
    roi = batch["roi"].clone()
    roi[:, :, :shave] = 0
    roi[:, :, -shave:] = 0
    roi[:, :, :, :shave] = 0
    roi[:, :, :, -shave:] = 0
    if not roi.sum().item():
        raise ValueError("ROI is empty after one-LR-pixel shave")
    valid = batch.get("valid", torch.ones_like(batch["roi"]))
    return {**scores(pred, batch["hr"], valid, batch["roi"], shave),
            **structural(pred, batch["hr"], roi * valid),
            "lpips_roi": float(perception(metric, pred.clamp(0, 1), batch)),
            "lowfreq_mae": float(F.l1_loss(F.interpolate(pred.clamp(0, 1), batch["lr"].shape[-2:], mode="area"), batch["clean_lr"])),
            "same_operator_lr_mae": same_operator_mae(pred, batch["clean_lr"])}


def aggregate(rows, note):
    if not rows:
        raise ValueError("No validation rows")
    groups = collections.defaultdict(list)
    for row in rows:
        groups[row["source_group"]].append(row)
    group_means = {group: {key: float(np.mean([row[key] for row in values])) for key in METRICS}
                   for group, values in groups.items()}
    by_regime = {}
    for regime in sorted({row["regime"] for row in rows}):
        subgroup_means = {group: {key: float(np.mean([row[key] for row in values if row["regime"] == regime]))
                                    for key in METRICS}
                          for group, values in groups.items() if any(row["regime"] == regime for row in values)}
        by_regime[regime] = {"count": sum(row["regime"] == regime for row in rows),
                            "group_means": subgroup_means,
                            "means": {key: float(np.mean([row[key] for row in subgroup_means.values()])) for key in METRICS}}
    return {"count": len(rows), "groups": len(groups), "split": "val", "test_used": False,
            "group_means": group_means, "by_regime": by_regime,
            "means": {key: float(np.mean([row[key] for row in group_means.values()])) for key in METRICS},
            "rows": rows, "note": note}


@torch.no_grad()
def evaluate_legacy(model, data, metric, out, panel_ids, self_ensemble=False):
    rows = []
    for row in data.splits["val"]:
        assert row["split"] == "val" and not row["synthetic"]
        for regime in ("clean", "sensor"):
            batch = data.batch(row, regime=regime, device=next(model.parameters()).device)
            native = model.predict(batch["lr"], self_ensemble=self_ensemble)
            pred = display_resize(native, batch["hr"].shape[-2:])
            record = {"id": row["id"], "source_group": row["source_group"], "regime": regime,
                      "input_size_hw": list(batch["lr"].shape[-2:]),
                      "learned_size_hw": list(native.shape[-2:]), "evaluation_size_hw": list(pred.shape[-2:]),
                      "shave": 20, **metrics(pred, batch, metric, 20)}
            rows.append(record)
            if row["id"] in panel_ids:
                folder = out / "paired_panel" / row["id"] / regime
                for name, image in (("input", batch["lr"]), ("reference", batch["hr"]),
                                    ("learned", native), ("display", pred)):
                    save_image(folder / (name + ".png"), image)
    return aggregate(rows, "Legacy HR grid and legacy metrics. Learned x4/x8 output is bicubic-resized to the same x20 HR canvas as the fixed old/B20 controls. This is not x20 learned detail recovery.")


def _file(data, row, key):
    entry = row["files"][key]
    name = entry["path"] if isinstance(entry, dict) else entry
    path = data / name
    if isinstance(entry, dict) and entry.get("sha256") and sha256(path) != entry["sha256"]:
        raise ValueError(f"Image hash mismatch: {path}")
    return path


@torch.no_grad()
def evaluate_rare(model, manifest_path, metric, out, self_ensemble=False):
    """Read paired files; never infer new LR inputs from held-out HR here.

    Expected rows: split, id, source_group, files{hr,roi,clean_lr,sensor_lr}.
    HR/input size ratio is checked from actual tensors, not trusted metadata.
    """
    manifest_path = Path(manifest_path)
    if manifest_path.is_dir():
        manifest_path = manifest_path / "manifest.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    data = manifest_path.parent
    by_grid = collections.defaultdict(list)
    for row in manifest["records"]:
        if row["split"] != "val":
            continue
        if row.get("synthetic", False):
            raise ValueError("Synthetic validation is not allowed")
        device = next(model.parameters()).device
        hr = tensor(_file(data, row, "hr"), device)
        roi = tensor(_file(data, row, "roi"), device, "L")
        clean = tensor(_file(data, row, "clean_lr"), device)
        valid = tensor(_file(data, row, "valid"), device, "L") if "valid" in row["files"] else torch.ones_like(roi)
        for regime in ("clean", "sensor"):
            key = regime + "_lr"
            if key not in row["files"]:
                continue
            lr = clean if regime == "clean" else tensor(_file(data, row, key), device)
            ratios = (hr.shape[-2] / lr.shape[-2], hr.shape[-1] / lr.shape[-1])
            if ratios[0] != ratios[1] or ratios[0] != int(ratios[0]) or ratios[0] <= 1:
                raise ValueError(f"Expected isotropic integer paired scale, got {ratios}")
            shave = int(ratios[0])
            if "scale" in row and row["scale"] != shave:
                raise ValueError("Manifest scale differs from actual file sizes")
            if clean.shape != lr.shape or roi.shape[-2:] != hr.shape[-2:] or valid.shape != roi.shape:
                raise ValueError("Paired LR/mask sizes are inconsistent")
            native = model.predict(lr, self_ensemble=self_ensemble)
            pred = display_resize(native, hr.shape[-2:])
            batch = {"lr": lr, "hr": hr, "roi": roi, "valid": valid, "clean_lr": clean}
            grid = f"x{shave}_gt{hr.shape[-2]}x{hr.shape[-1]}"
            record = {"id": row["id"], "source_group": row["source_group"], "regime": regime,
                      "input_size_hw": list(lr.shape[-2:]), "learned_size_hw": list(native.shape[-2:]),
                      "evaluation_size_hw": list(hr.shape[-2:]), "shave": shave,
                      **metrics(pred, batch, metric, shave)}
            by_grid[grid].append(record)
    if not by_grid:
        raise ValueError("New manifest has no real val pairs")
    return {"manifest_sha256": sha256(manifest_path), "split": "val", "test_used": False,
            "grids": {grid: aggregate(rows, "Effective GT grid; compare candidates only within this identical grid, never against legacy x20-canvas scores.")
                      for grid, rows in sorted(by_grid.items())}}


@torch.no_grad()
def native_panel(model, root, out, ids, self_ensemble=False):
    protocol_path = root / "geometry_20260928/test_protocol.json"
    protocol = json.loads(protocol_path.read_text(encoding="utf-8"))
    source = root / "planesnet_20260921/inputs.npy"
    if sha256(source) != protocol["planesnet_npy_sha256"]:
        raise ValueError("Native input array has changed")
    if not set(ids).issubset(set(protocol["test_indices"])):
        raise ValueError("Native panel contains an ID outside the frozen native pool")
    pixels = np.load(source, allow_pickle=False)
    rows = []
    for index in ids:
        lr = torch.from_numpy(pixels[index].copy()).permute(2, 0, 1)[None].float().to(next(model.parameters()).device) / 255
        native = model.predict(lr, self_ensemble=self_ensemble)
        display = display_resize(native, (400, 400))
        folder = out / "native_panel" / str(index)
        images = {name: save_image(folder / (name + ".png"), value)
                  for name, value in (("input", lr), ("learned", native), ("display", display))}
        rows.append({"index": index, "files": images})
    return {"count": len(rows), "rows": rows, "input_array_sha256": sha256(source),
            "note": "Full native field; no native HR ground truth. Display400 is a separately recorded bicubic view."}


def main(args):
    import lpips
    torch.set_num_threads(4)
    torch.manual_seed(1005)
    if args.device.startswith("cuda") and not torch.cuda.is_available():
        raise RuntimeError("Requested CUDA but none is available")
    vgg = Path(torch.hub.get_dir()) / "checkpoints/vgg16-397923af.pth"
    if not vgg.exists():
        raise FileNotFoundError(f"Expected cached pretrained VGG, refusing implicit download: {vgg}")
    metric = lpips.LPIPS(net="vgg").to(args.device).eval().requires_grad_(False)
    protocol = json.loads(args.protocol.read_text(encoding="utf-8"))
    if protocol["selection_split"] != "val" or protocol["test_used_for_selection"]:
        raise ValueError("Expected a frozen validation-only diagnostic protocol")
    legacy_path = args.legacy_data or args.root / "expansion_v3_20260928/data"
    frozen_path = args.v4_protocol or args.root / "research_v4_20260929/protocol_frozen.json"
    data = None if args.skip_legacy else PairedData(legacy_path, frozen_path)
    rare_path = args.rare_data / "manifest.json" if args.rare_data and args.rare_data.is_dir() else args.rare_data
    for name in args.models:
        model = SwinIRBaseline(name, args.assets, args.device)
        out = args.out / name
        config = {"model": model.source_receipt, "protocol_sha256": sha256(args.protocol),
                  "sources_sha256": sha256(Path(__file__).with_name("v5_baseline_sources.json")),
                  "code_sha256": {p: sha256(Path(__file__).with_name(p)) for p in ("diagnose_v5_swinir.py", "v5_baselines.py")},
                  "legacy_manifest_sha256": sha256(legacy_path / "manifest.json") if data is not None else None,
                  "legacy_frozen_protocol_sha256": sha256(frozen_path) if data is not None else None,
                  "rare_manifest_sha256": sha256(rare_path) if rare_path else None,
                  "self_ensemble": args.self_ensemble, "skip_legacy": args.skip_legacy,
                  "test_used_for_selection": False, "vgg_sha256": sha256(vgg)}
        config_path = out / "config.json"
        if config_path.exists() and json.loads(config_path.read_text(encoding="utf-8")) != config:
            raise ValueError(f"Existing output uses another run configuration: {out}")
        dump(config_path, config)
        if data is not None:
            result = evaluate_legacy(model, data, metric, out, set(protocol["paired_panel_ids"]), args.self_ensemble)
            dump(out / "legacy_validation.json", result)
            print("SWINIR_LEGACY_VAL", name, result["means"], flush=True)
        if rare_path:
            result = evaluate_rare(model, rare_path, metric, out, args.self_ensemble)
            dump(out / "effective_grid_validation.json", result)
            print("SWINIR_EFFECTIVE_VAL", name, {k: v["means"] for k, v in result["grids"].items()}, flush=True)
        panel = native_panel(model, args.root, out, protocol["native_panel_ids"], args.self_ensemble)
        dump(out / "native_panel_audit.json", panel)
        dump(out / "complete.json", {"complete": True, "name": name, "native_panel_count": len(panel["rows"]),
             "learned_scale": model.scale, "display_size": [400, 400], "new_training": False,
             "config_sha256": sha256(config_path)})
        print("SWINIR_DIAGNOSIS_COMPLETE", name, flush=True)
        del model
        if torch.cuda.is_available():
            torch.cuda.empty_cache()


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--assets", type=Path, required=True)
    parser.add_argument("--protocol", type=Path, required=True)
    parser.add_argument("--models", nargs="+", choices=list(source_manifest()["models"]), default=list(source_manifest()["models"]))
    parser.add_argument("--v4-protocol", type=Path)
    parser.add_argument("--legacy-data", type=Path)
    parser.add_argument("--rare-data", type=Path)
    parser.add_argument("--skip-legacy", action="store_true")
    parser.add_argument("--self-ensemble", action="store_true")
    parser.add_argument("--device", default="cuda")
    main(parser.parse_args())
