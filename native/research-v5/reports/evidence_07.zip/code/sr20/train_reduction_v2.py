"""Four frozen pilot arms: paired20/40 and geometry-clean/sensor20."""
import argparse, json, random, math, time, hashlib, collections, os
from pathlib import Path
import numpy as np
from PIL import Image
import torch
from torch.nn import functional as F
from torch.utils.checkpoint import checkpoint_sequential
from .model import CyclicSR,resize
from .train_matched import masked,dump,sha
class FlexibleSR(CyclicSR):
 schedules={**CyclicSR.schedules,40:(2,2,2.5,4)}
 # Activation recomputation is used identically by all arms; inference is unchanged.
 def step(self,x,size):
  aligned,smooth=self.alignment(x);features=self.head(aligned)+self.condition(torch.cat((smooth,x-smooth),1))
  features=checkpoint_sequential(self.body,3,features,use_reentrant=False) if self.training and torch.is_grad_enabled() else self.body(features)
  features=self.similarity(features,self.head(x));residual=self.tail(features)
  if residual.shape[-2:]!=tuple(size):residual=resize(residual,size)
  return resize(x,size)+residual
def read(data,r,key,device):
 a=np.asarray(Image.open(data/r['files'][key]['path'])).copy()
 if a.ndim==2:a=a[:,:,None]
 return torch.from_numpy(a).permute(2,0,1).float()[None].to(device)/255
def sample(data,r,scale,regime,device):
 suffix='40' if scale==40 else '';b={k:read(data,r,k+suffix,device) for k in ('hr','roi','valid')};b['clean_lr']=read(data,r,'clean_lr',device);b['lr']=b['clean_lr'] if regime=='clean' else read(data,r,'sensor_lr',device);return b
def loss_fn(p,st,b):
 mask=b['valid']*(1+2*b['roi'])
 def l1(x,y):return masked((x-y).abs(),F.interpolate(mask,size=x.shape[-2:],mode='area')).mean()
 rec=l1(p,b['hr']);inter=sum(l1(s,resize(b['hr'],s.shape[-2:]).clamp(0,1)) for s in st[:-1])/len(st[:-1]);con=l1(resize(p,b['clean_lr'].shape[-2:]),b['clean_lr']);dx=(p[:,:,:,1:]-p[:,:,:,:-1])-(b['hr'][:,:,:,1:]-b['hr'][:,:,:,:-1]);dy=(p[:,:,1:,:]-p[:,:,:-1,:])-(b['hr'][:,:,1:,:]-b['hr'][:,:,:-1,:]);edge=(masked(dx.abs(),torch.minimum(mask[:,:,:,1:],mask[:,:,:,:-1])).mean()+masked(dy.abs(),torch.minimum(mask[:,:,1:,:],mask[:,:,:-1,:])).mean())/2
 return rec+.1*inter+.05*con+.05*edge
def scores(p,gt,valid,roi,shave):
 mask=valid.clone();mask[:,:,:shave]=0;mask[:,:,-shave:]=0;mask[:,:,:,:shave]=0;mask[:,:,:,-shave:]=0
 return {k:-10*math.log10(max(masked((p.clamp(0,1)-gt).square(),m).item(),1e-12)) for k,m in [('full',mask),('roi',mask*roi)]}
@torch.inference_mode()
def evaluate(model,rows,data,scale,paired,save=None):
 model.eval();out=[]
 for r in rows:
  for regime in ('clean','sensor'):
   b=sample(data,r,scale,regime,'cuda');p=model(b['lr']);assert torch.isfinite(p).all();v={'id':r['id'],'source_group':r['source_group'],'cohort':r['cohort'],'regime':regime}
   if paired:
    for s in (20,40):
     suffix='40' if s==40 else '';gt=b['hr'] if s==scale else read(data,r,'hr'+suffix,'cuda');valid=read(data,r,'valid'+suffix,'cuda');roi=read(data,r,'roi'+suffix,'cuda');pred=p if p.shape[-2:]==gt.shape[-2:] else resize(p,gt.shape[-2:]);v.update({f'common{s}_{k}':x for k,x in scores(pred,gt,valid,roi,s).items()})
   else:
    v.update(scores(p,b['hr'],b['valid'],b['roi'],20));v.update({'bicubic_'+k:x for k,x in scores(resize(b['lr'],b['hr'].shape[-2:]),b['hr'],b['valid'],b['roi'],20).items()})
   out.append(v)
   if save:
    folder=save/r['id'];folder.mkdir(parents=True,exist_ok=True);Image.fromarray(p[0].clamp(0,1).mul(255).round().byte().permute(1,2,0).cpu().numpy()).save(folder/(regime+'.png'),compress_level=1)
 strata=collections.defaultdict(list)
 for r in out:strata[r['cohort']+'/'+r['regime']].append(r)
 keys=('common20_full','common20_roi','common40_full','common40_roi') if paired else ('full','roi','bicubic_full','bicubic_roi');means={k:{key:float(np.mean([r[key] for r in values])) for key in keys} for k,values in strata.items()}
 score=float(np.mean([v['common40_roi'] for v in means.values()])) if paired else .8*np.mean([means['target/'+reg]['roi'] for reg in ['clean','sensor']])+.2*np.mean([means['whole/'+reg]['roi'] for reg in ['clean','sensor']])
 return {'count':len(out),'score':float(score),'means':means,'rows':out,'note':'Same native source FOV. Pair common40 interpolates20output2x;common20 minifies40output2x. Nevercompare PSNRatdifferentreferencegrids. ROIcoarsebox;maskedpadding;shave1LRpixel equivalent.'}
def main(a):
 torch.set_num_threads(4);torch.manual_seed(929);device='cuda';assert torch.cuda.is_available();m=json.loads((a.data/'manifest.json').read_text());paired=a.arm in ('A20_pair','D40_pair');scale=40 if a.arm=='D40_pair' else 20;records=m['records'];rows={s:[r for r in records if r['split']==s and (r['cohort']=='pair' if paired else r['cohort'] in ('target','whole'))] for s in ('train','val','test')};selection=json.loads(a.sampling.read_text());assert selection['manifest_sha256']==sha(a.data/'manifest.json');ids=selection['indices'];assert len(ids)==a.steps*4
 init=torch.load(a.init,map_location='cpu',weights_only=True);config={**init['model_config'],'default_scale':scale};model=FlexibleSR(**config).cuda();model.load_state_dict(init['model']);opt=torch.optim.Adam(model.parameters(),lr=3e-5);a.run.mkdir(parents=True,exist_ok=True)
 cfg={'arm':a.arm,'scale':scale,'schedule':list(model.schedules[scale]),'model_config':config,'parameters':sum(p.numel() for p in model.parameters()),'steps':a.steps,'batch_effective':4,'lr':3e-5,'manifest_sha256':sha(a.data/'manifest.json'),'sampling_sha256':sha(a.sampling),'init_sha256':sha(a.init),'code_sha256':sha(Path(__file__)),'activation_checkpointing':True,'sensor_probability':0 if a.arm=='B20_matched' else .75,'selection':'common40 ROI' if paired else '.8targetROI+.2wholeROI;bothregimes','scope':'Exploratory1000additionalstep pilot, not convergenceproof. A20/D40 identicalLRandorder, differenttarget andschedule;B20/C20 identicalHRandorder, differentLRdegradation.'};start=0;best=-1e10
 if (a.run/'config.json').exists():
  assert json.loads((a.run/'config.json').read_text())==cfg;c=torch.load(a.run/'last.pt',map_location='cuda',weights_only=False);model.load_state_dict(c['model']);opt.load_state_dict(c['opt']);start=c['step'];best=c['best']
 else:dump(a.run/'config.json',cfg)
 def export(step,name):torch.save({'model':{k:v.cpu() for k,v in model.state_dict().items()},'model_config':config,'step':step,'arm':a.arm,'manifest_sha256':cfg['manifest_sha256'],'schedule':cfg['schedule']},a.run/name)
 def checkpoint(step):
  temp=a.run/'last.pt.tmp';torch.save({'model':model.state_dict(),'opt':opt.state_dict(),'step':step,'best':best},temp);temp.replace(a.run/'last.pt')
 begin=time.monotonic()
 if not (a.run/'validation_0.json').exists():
  initial={k:v.detach().clone() for k,v in model.state_dict().items()};smokeopt=torch.optim.Adam(model.parameters(),lr=1e-4);values=[]
  for step in range(16):
   model.train();smokeopt.zero_grad();r=records[ids[step%4]];b=sample(a.data,r,scale,'sensor','cuda');p,st=model(b['lr'],return_stages=True);loss=loss_fn(p,st,b);assert torch.isfinite(loss);loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),1,error_if_nonfinite=True);smokeopt.step();values.append(loss.item())
  smoke={'first4':float(np.mean(values[:4])),'last4':float(np.mean(values[-4:]))};dump(a.run/'smoke.json',smoke);assert smoke['last4']<smoke['first4'];model.load_state_dict(initial);del initial,smokeopt
  val=evaluate(model,rows['val'],a.data,scale,paired);dump(a.run/'validation_0.json',val);best=val['score'];export(0,'best_inference.pt');checkpoint(0);print('INITIAL',a.arm,best,flush=True)
 with (a.run/'progress.jsonl').open('a') as log:
  for step in range(start,a.steps):
   model.train();opt.zero_grad();total=0
   for pg in opt.param_groups:pg['lr']=3e-5*(.2+.8*.5*(1+math.cos(math.pi*step/a.steps)))
   for j in range(4):
    serial=step*4+j;r=records[ids[serial]];assert r['split']=='train';regime='sensor' if a.arm!='B20_matched' and random.Random(93000000+serial).random()<.75 else 'clean';b=sample(a.data,r,scale,regime,'cuda');p,st=model(b['lr'],return_stages=True);loss=loss_fn(p,st,b);assert torch.isfinite(loss);(loss/4).backward();total+=loss.item()/4
   grad=torch.nn.utils.clip_grad_norm_(model.parameters(),1,error_if_nonfinite=True);opt.step();row={'step':step+1,'loss':total,'grad':grad.item(),'elapsed':time.monotonic()-begin};log.write(json.dumps(row)+'\n');log.flush()
   if (step+1)%25==0:print(json.dumps(row),flush=True)
   if (step+1)%500==0 or step+1==a.steps:
    val=evaluate(model,rows['val'],a.data,scale,paired);dump(a.run/f'validation_{step+1}.json',val)
    if val['score']>best:best=val['score'];export(step+1,'best_inference.pt')
    print('VALIDATION',a.arm,step+1,val['score'],best,flush=True)
   if (step+1)%25==0:
    checkpoint(step+1)
    deadline=float(os.environ.get('SLURM_JOB_END_TIME','inf'))
    if (time.monotonic()-begin>a.max_seconds or time.time()>deadline-150) and step+1<a.steps:print('RESUMABLE_TIME_SLICE',step+1,flush=True);return
 checkpoint(a.steps);chosen=torch.load(a.run/'best_inference.pt',map_location='cuda',weights_only=True);model.load_state_dict(chosen['model']);dump(a.run/'test_selected.json',evaluate(model,rows['test'],a.data,scale,paired,a.run/'test_outputs'));model.load_state_dict(init['model']);dump(a.run/'test_initial.json',evaluate(model,rows['test'],a.data,scale,paired));dump(a.run/'completion.json',{'complete':True,'arm':a.arm,'steps':a.steps,'selected_step':chosen['step'],'test_sources':len(rows['test']),'test_predictions':len(rows['test'])*2,'best_validation':best});print('V2_TRAIN_COMPLETE',a.arm,flush=True)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--data',type=Path,required=True);p.add_argument('--init',type=Path,required=True);p.add_argument('--sampling',type=Path,required=True);p.add_argument('--run',type=Path,required=True);p.add_argument('--arm',required=True,choices=('A20_pair','B20_matched','C20_sensor','D40_pair'));p.add_argument('--steps',type=int,default=1000);p.add_argument('--max-seconds',type=int,default=1120);main(p.parse_args())
