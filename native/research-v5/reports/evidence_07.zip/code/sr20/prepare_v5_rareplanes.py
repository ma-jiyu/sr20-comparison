"""Freeze a location-held-out real RarePlanes SR pilot, with native HR targets.

Only official training imagery is eligible. Prior RarePlanes catalog locations
and every official test location are excluded. Geographic polygons deduplicate
overlapping tiles, and location isolation prevents scene leakage across splits.
This is new supervision for this experiment, not a claim that imagery was never
inspected in earlier public inference benchmarks.
"""
import argparse
import collections
import concurrent.futures
import hashlib
import json
import math
from pathlib import Path
import random
import time
import xml.etree.ElementTree as ET

import cv2
import numpy as np
from PIL import Image, ImageDraw
import requests

from .prepare_reduction_v2 import sensor


ROOT = Path('D:/超分实验/飞机超分突破诊断_20261005/rareplanes')
BASE = 'https://rareplanes-public.s3.us-west-2.amazonaws.com/'
PRIOR = Path('D:/超分实验/飞机尺度统计与匹配训练_20260928/matched_sources.json')
META_KEYS = [
    'LICENSE.txt',
    'real/metadata_annotations/RarePlanes_Public_Metadata.csv',
    'real/metadata_annotations/RarePlanes_Train_Coco_Annotations_tiled.json',
    'real/metadata_annotations/RarePlanes_Test_Coco_Annotations_tiled.json',
]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def dump(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2), encoding='utf-8')


def read(path):
    return json.loads(path.read_text(encoding='utf-8'))


def fetch(root, key, relative):
    path = root/relative
    receipt = path.with_name(path.name+'.source.json')
    if path.exists() and receipt.exists():
        info = read(receipt)
        assert info['url'] == BASE+key and info['sha256'] == sha(path)
        return path, info
    path.parent.mkdir(parents=True, exist_ok=True)
    last = None
    for attempt in range(4):
        try:
            response = requests.get(BASE+key, timeout=(15, 90))
            response.raise_for_status()
            payload = response.content
            assert len(payload) == int(response.headers.get('Content-Length', len(payload)))
            etag = response.headers.get('ETag', '').strip('"')
            if len(etag) == 32 and '-' not in etag:
                assert hashlib.md5(payload).hexdigest() == etag, 'S3 ETag mismatch'
            if path.exists():
                assert path.read_bytes() == payload, 'Existing input differs from publisher content'
            else:
                path.write_bytes(payload)
            info = {'url': BASE+key, 'sha256': sha(path), 'bytes': len(payload),
                    'etag': etag, 'last_modified': response.headers.get('Last-Modified'),
                    'license': 'CC BY-SA 4.0'}
            dump(receipt, info)
            return path, info
        except Exception as exc:
            last = exc
            if attempt < 3:
                time.sleep(1+attempt)
    raise RuntimeError(f'Download failed {key}: {last}')


def polygon(ann):
    assert len(ann['segmentation']) == 1
    poly = np.array(ann['segmentation'][0], dtype=np.float64).reshape(-1, 2)
    if np.allclose(poly[0], poly[-1]):
        poly = poly[:-1]
    return poly


def crop_plan(ann, scale, image_size=(512, 512)):
    if ann.get('truncated', 1) or ann.get('partialDec', 0) < .999999:
        return None
    poly = polygon(ann)
    lo, hi = poly.min(0), poly.max(0)
    long = float((hi-lo).max())
    output = 20*scale
    if long < output*.65:
        return None
    seed = int(hashlib.sha256(f"{ann['id']}/{scale}/20261005".encode()).hexdigest()[:8], 16)
    rng = random.Random(seed)
    wanted = rng.uniform(.72, .89)
    side = max(output, math.ceil(long/wanted))
    if side > min(image_size) or not .65 <= long/side <= .9:
        return None
    center = (lo+hi)/2
    left = min(max(round(center[0]-side/2+rng.uniform(-.025, .025)*side), 0), image_size[0]-side)
    top = min(max(round(center[1]-side/2+rng.uniform(-.025, .025)*side), 0), image_size[1]-side)
    if np.any(lo < np.array([left, top])+2) or np.any(hi > np.array([left+side, top+side])-2):
        return None
    return {'xywh': [left, top, side, side], 'target': output,
            'occupancy_long': long/side, 'native_to_hr_scale': output/side}


def intersection(a, b):
    x = max(0, min(a[2], b[2])-max(a[0], b[0]))
    y = max(0, min(a[3], b[3])-max(a[1], b[1]))
    return x*y


def neighbor_fraction(ann, plan, others):
    left, top, side, _ = plan['xywh']
    field = [left, top, left+side, top+side]
    total = 0.
    for other in others:
        if other['id'] == ann['id']:
            continue
        lo, hi = polygon(other).min(0), polygon(other).max(0)
        total += intersection(field, [*lo, *hi])
    return total/(side*side)


def native_geo_identity(ann, transform, features):
    poly = polygon(ann)
    a, b, c, d, e, f = transform
    geo = np.stack([a+b*poly[:, 0]+c*poly[:, 1], d+e*poly[:, 0]+f*poly[:, 1]], axis=1)
    matches = []
    for feature in features:
        prop = feature['properties']
        if str(prop['cat_id']) != ann['cat_id'] or int(prop['loc_id']) != int(ann['loc_id']):
            continue
        if prop.get('truncated', 1) or prop.get('partialDec', 0) < .999999:
            continue
        coords = np.array(feature['geometry']['coordinates'][0], dtype=float)
        if np.allclose(coords[0], coords[-1], rtol=0, atol=1e-12):
            coords = coords[:-1]
        if len(coords) != len(geo):
            continue
        error = max(np.linalg.norm(coords-point, axis=1).min() for point in geo)
        error /= min(abs(b), abs(f))
        if error < .1:
            matches.append((error, coords))
    assert len(matches) == 1, f"COCO/global polygon alignment ambiguous: {ann['id']} {len(matches)}"
    error, coords = matches[0]
    canon = sorted(tuple(float(round(v, 9)) for v in point) for point in coords)
    identity = hashlib.sha256(json.dumps([int(ann['loc_id']), ann['cat_id'], canon], separators=(',', ':')).encode()).hexdigest()
    return identity, error, coords.tolist()


def load_tile(root, image):
    name = image['file_name']
    stem = Path(name).stem
    png, png_receipt = fetch(root, 'real/train/PS-RGB_tiled/'+name, 'sources/'+name)
    aux, aux_receipt = fetch(root, 'real/train/PS-RGB_tiled/'+name+'.aux.xml', 'sources/'+name+'.aux.xml')
    geojson, geo_receipt = fetch(root, 'real/train/geojson_aircraft_tiled/'+stem+'.geojson', 'sources/'+stem+'.geojson')
    with Image.open(png) as source:
        source.load()
        assert source.size == (image['width'], image['height']) == (512, 512)
        pixels = np.array(source.convert('RGB'))
    xml = ET.fromstring(aux.read_bytes())
    assert 'WGS 84' in xml.findtext('SRS')
    transform = [float(s) for s in xml.findtext('GeoTransform').split(',')]
    assert abs(transform[2]) < 1e-15 and abs(transform[4]) < 1e-15
    return pixels, transform, read(geojson)['features'], [png_receipt, aux_receipt, geo_receipt]


def contact_sheet(root, records):
    chosen = []
    # Hold-out test pixels are deliberately not included in an inspected sheet.
    for split in ('train', 'val'):
        for row in sorted((r for r in records if r['split'] == split and r['scale'] == 4), key=lambda r: r['id']):
            if row['source_group'] not in {r['source_group'] for r in chosen}:
                chosen.append(row)
            if sum(r['split'] == split for r in chosen) >= 8:
                break
    out = Image.new('RGB', (1100, 254*len(chosen)), '#eeeeee')
    draw = ImageDraw.Draw(out)
    for i, row in enumerate(chosen):
        y = i*254
        draw.text((5, y), f"{row['split']} {row['source_group']} {row['source_id'][:12]} x4 {row['plane_long_lr']:.1f}px", fill='black')
        for j, key in enumerate(('clean_lr', 'sensor_lr', 'hr', 'roi')):
            pic = Image.open(root/'data'/row['files'][key]['path']).convert('RGB')
            pic = pic.resize((230, 230), Image.Resampling.NEAREST)
            out.paste(pic, (j*270, y+22))
            draw.text((j*270+4, y+10), key, fill='black')
    out.save(root/'pair_review.jpg', quality=94)
    dump(root/'pair_review_selection.json', chosen)


def main(args):
    root = args.root
    root.mkdir(parents=True, exist_ok=True)
    frozen = root/'data/manifest.json'
    if frozen.exists():
        manifest = read(frozen)
        for row in manifest['records']:
            for key, file in row['files'].items():
                assert sha(root/'data'/file['path']) == file['sha256']
        print('ALREADY_FROZEN_VERIFIED', sha(frozen), len(manifest['records']), flush=True)
        return
    cv2.setNumThreads(2)
    metadata = []
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
        for path, receipt in executor.map(lambda key: fetch(root, key, 'metadata/'+Path(key).name), META_KEYS):
            metadata.append(receipt)
    train = read(root/'metadata/RarePlanes_Train_Coco_Annotations_tiled.json')
    test = read(root/'metadata/RarePlanes_Test_Coco_Annotations_tiled.json')
    official_test_locations = {int(a['loc_id']) for a in test['annotations']}
    prior_rare = [r for r in read(PRIOR) if r['dataset'] == 'rareplanes-real']
    prior_locations = {int(float(r['group'].replace('rare_location_', ''))) for r in prior_rare}
    excluded = official_test_locations | prior_locations
    images = {r['id']: r for r in train['images']}
    annotations = collections.defaultdict(list)
    for ann in train['annotations']:
        annotations[ann['image_id']].append(ann)
    eligible = collections.defaultdict(list)
    for image_id, members in annotations.items():
        image = images[image_id]
        location = int(members[0]['loc_id'])
        assert all(int(a['loc_id']) == location for a in members)
        if location in excluded:
            continue
        valid = []
        for ann in members:
            assert ann['Public_Train'] == 1 and ann['Public_Test'] == 0
            plan = crop_plan(ann, 4)
            if plan and neighbor_fraction(ann, plan, members) <= .08:
                valid.append(ann)
        if valid:
            eligible[location].append((image, valid))
    # Require at least four usable tiles in a location for a reasonably sized held-out group.
    locations = sorted((loc for loc, tiles in eligible.items() if len(tiles) >= 4),
                       key=lambda loc: hashlib.sha256(f'rare-v5-loc/{loc}/20261005'.encode()).hexdigest())
    assert len(locations) >= 18, len(locations)
    val_locations = set(locations[:args.val_locations])
    test_locations = set(locations[args.val_locations:args.val_locations+args.test_locations])
    train_locations = set(locations[args.val_locations+args.test_locations:])
    assert len(train_locations) >= 10 and len(val_locations) >= 4 and len(test_locations) >= 4
    split = {loc: 'val' if loc in val_locations else 'test' if loc in test_locations else 'train' for loc in locations}
    # Balanced round-robin tile selection. Dense tiles first within a location.
    queues = {loc: sorted(eligible[loc], key=lambda pair: (-len(pair[1]), hashlib.sha256(pair[0]['file_name'].encode()).hexdigest())) for loc in locations}
    selection = []
    for index in range(max(map(len, queues.values()))):
        for location in locations:
            if index < len(queues[location]):
                image, members = queues[location][index]
                selection.append((location, image, members))
            if len(selection) >= args.max_tiles:
                break
        if len(selection) >= args.max_tiles:
            break
    plan = {
        'version': 2, 'seed': 20261005, 'official_partition': 'train_only',
        'official_test_locations_excluded': sorted(official_test_locations),
        'prior_catalog_locations_excluded': sorted(prior_locations),
        'prior_catalog_sha256': sha(PRIOR), 'train_locations': sorted(train_locations),
        'val_locations': sorted(val_locations), 'test_locations': sorted(test_locations),
        'data_policy': 'Location disjoint. Crop whole annotated aircraft with65-90% long-side occupancy. Native4x HR80 or8x HR160; never reference magnification. One geographic object identity per dataset, two scales at most.',
        'selection_policy': 'Only >=4 viable tiles per location; deterministic hash location order, first four validation, next four test, remaining train; round-robin tiles with most viable complete aircraft first. Split is selected before model results. Initial20tiles were processed before adding test split, but no contact sheet or model result had been inspected.',
        'max_tiles': args.max_tiles,
        'tile_keys': [image['file_name'] for _, image, _ in selection],
        'training_started': False,
        'geographic_overlap_with_old_dota_planesnet_excluded': False,
        'published_train_tiles_previously_used_in_public_inference': True,
        'supersedes_unfinished_source_plan_v1': 'User-directed three-way split change before any model use; original plan retained, cached files reused. No v1 dataset manifest was frozen.',
    }
    plan_path = root/'source_plan_v2_frozen.json'
    if plan_path.exists():
        assert read(plan_path) == plan, 'Source plan changed; use a new version'
    else:
        dump(plan_path, plan)
    print('SOURCE_PLAN', len(selection), 'tiles', len(train_locations), 'train locations', len(val_locations), 'val locations', len(test_locations), 'test locations', flush=True)
    records, receipts, seen, duplicates, failures = [], [], {}, [], []
    def download(item):
        location, image, members = item
        return item, load_tile(root, image)
    with concurrent.futures.ThreadPoolExecutor(max_workers=8) as executor:
        for number, (item, loaded) in enumerate(executor.map(download, selection), start=1):
            location, image, members = item
            pixels, transform, features, source_receipts = loaded
            receipts.extend(source_receipts)
            all_anns = annotations[image['id']]
            for ann in members:
                identity, coord_error, coords = native_geo_identity(ann, transform, features)
                if identity in seen:
                    duplicates.append({'source_id': identity, 'kept_tile': seen[identity], 'duplicate_tile': image['file_name']})
                    continue
                seen[identity] = image['file_name']
                for scale in (4, 8):
                    crop = crop_plan(ann, scale)
                    if crop is None or neighbor_fraction(ann, crop, all_anns) > .08:
                        continue
                    left, top, side, _ = crop['xywh']
                    target = crop['target']
                    hr = np.array(Image.fromarray(pixels[top:top+side, left:left+side]).resize((target, target), Image.Resampling.LANCZOS))
                    poly = (polygon(ann)-[left, top]) * target/side
                    roi = np.zeros((target, target), np.uint8)
                    cv2.fillPoly(roi, [poly.round().astype(np.int32)], 255)
                    assert crop['native_to_hr_scale'] <= 1 and .65 <= crop['occupancy_long'] <= .9
                    uid = f'rare_{identity[:24]}_x{scale}'
                    folder = root/'data/pairs'/uid
                    folder.mkdir(parents=True, exist_ok=True)
                    clean = np.array(Image.fromarray(hr).resize((20, 20), Image.Resampling.BICUBIC))
                    degraded, degrade_meta = sensor(hr, (20, 20), int(identity[:8], 16)+scale)
                    files = {}
                    for name, array in {'hr': hr, 'clean_lr': clean, 'sensor_lr': degraded, 'roi': roi, 'valid': np.full((target, target), 255, np.uint8)}.items():
                        path = folder/(name+'.png')
                        Image.fromarray(array).save(path, compress_level=3)
                        files[name] = {'path': path.relative_to(root/'data').as_posix(), 'sha256': sha(path)}
                    records.append({
                        'id': uid, 'dataset': 'rareplanes-real', 'synthetic': False,
                        'split': split[location], 'official_split': 'train',
                        'source_group': 'rare_location_'+str(location),
                        'source_id': identity, 'source_scene': ann['cat_id'],
                        'source_sha256': source_receipts[0]['sha256'],
                        'source_file': 'sources/'+image['file_name'],
                        'source_url': source_receipts[0]['url'],
                        'annotation_id': ann['id'], 'global_polygon': coords,
                        'pixel_polygon': polygon(ann).tolist(),
                        'annotation_geo_alignment_max_error_px': coord_error,
                        'scale': scale, 'input_size': [20, 20], 'reference_size': [target, target],
                        'native_crop_xywh': crop['xywh'], 'native_to_hr_scale': crop['native_to_hr_scale'],
                        'plane_long_lr': crop['occupancy_long']*20,
                        'bbox_area_fraction': float(np.prod(np.ptp(poly, axis=0))/(target*target)),
                        'neighbor_bbox_area_fraction': neighbor_fraction(ann, crop, all_anns),
                        'roi_note': 'Official diamond geometry, not exact aircraft silhouette.',
                        'files': files, 'degradation': degrade_meta,
                        'license': 'CC BY-SA 4.0', 'photographic_reference': True,
                    })
            if number % 10 == 0:
                print('PREPARED', number, '/', len(selection), 'tiles', len(seen), 'objects', len(records), 'pairs', flush=True)
    by_object, by_location, by_scene, by_source = (collections.defaultdict(set) for _ in range(4))
    for row in records:
        for index, key in ((by_object, 'source_id'), (by_location, 'source_group'), (by_scene, 'source_scene'), (by_source, 'source_sha256')):
            index[row[key]].add(row['split'])
    assert all(len(s) == 1 for table in (by_object, by_location, by_scene, by_source) for s in table.values())
    assert len(by_object) >= args.min_objects, (len(by_object), args.min_objects)
    actual_locations = {sp: sorted({r['source_group'] for r in records if r['split'] == sp}) for sp in ('train', 'val', 'test')}
    assert len(actual_locations['train']) >= 10 and len(actual_locations['val']) >= 4 and len(actual_locations['test']) >= 4
    # Independently decode/hash every generated file before freezing the manifest.
    checked = 0
    for row in records:
        for name, entry in row['files'].items():
            path = root/'data'/entry['path']
            assert sha(path) == entry['sha256']
            with Image.open(path) as im:
                im.load()
                assert list(im.size) == (row['input_size'] if name.endswith('_lr') else row['reference_size'])
            checked += 1
    manifest = {'version': 5, 'purpose': 'Matched native4x/8x real aircraft SR pilot',
                'source_plan_sha256': sha(plan_path), 'generator_sha256': sha(Path(__file__)),
                'records': records, 'counts': dict(collections.Counter(r['split']+'/x'+str(r['scale']) for r in records)),
                'no_reference_upsampling': True,
                'new_to_this_experiment_supervision': True,
                'never_previously_seen_claim': False,
                'old_dataset_geographic_overlap_not_yet_excluded': True,
                'license': 'CC BY-SA 4.0',
                'attribution': 'RarePlanes Dataset (Shermeyer et al., 2020), In-Q-Tel CosmiQ Works and AI.Reverie. Real imagery Maxar WorldView-3. Cropped/minified and computationally degraded for this experiment.',
                'official_user_guide': 'https://www.iqt.org/library/rareplanes-public-user-guide'}
    dump(frozen, manifest)
    dump(root/'sources.json', {'metadata': metadata, 'tile_sources': receipts})
    audit = {'complete': True, 'manifest_sha256': sha(frozen), 'verified_generated_files': checked,
             'unique_geographic_aircraft_instances': len(by_object), 'actual_locations': actual_locations,
             'counts': manifest['counts'], 'duplicates_removed': len(duplicates),
             'downloaded_tiles': len(selection), 'downloaded_payload_bytes': sum(r['bytes'] for r in metadata+receipts),
             'max_annotation_geo_alignment_error_px': max(r['annotation_geo_alignment_max_error_px'] for r in records),
             'no_cross_split_geographic_object_location_scene_source': True,
             'official_test_not_used': True, 'prior_catalog_locations_not_used': True,
             'no_reference_upsampling': True, 'training_started': False,
             'physical_airframe_identity_across_dates_proven': False,
             'note': 'Unique geographic annotations/scene, not aircraft registration identities. Entire location is kept in one split across dates.'}
    dump(root/'data_audit.json', audit)
    dump(root/'overlap_deduplication.json', {'duplicates': duplicates, 'failures': failures})
    contact_sheet(root, records)
    print('RAREPLANES_V5_READY', json.dumps(audit), flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, default=ROOT)
    parser.add_argument('--max-tiles', type=int, default=320)
    parser.add_argument('--min-objects', type=int, default=200)
    parser.add_argument('--val-locations', type=int, default=4)
    parser.add_argument('--test-locations', type=int, default=4)
    main(parser.parse_args())
