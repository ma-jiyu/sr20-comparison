"""Independent byte/PNG/exact-ID audit and source-bootstrap descriptive contrasts.

Does not load an SR model or compute VGG. Metric aggregation is independently
recomputed from recorded test rows; the audit verifies coverage and provenance,
not whether an image is visually better. --reference adds a same-grid recorded
control contrast after selection, and can never select/tune a model on test.
"""
import argparse
import collections
import hashlib
from io import BytesIO
import json
import math
from pathlib import Path
import tarfile

import numpy as np
from PIL import Image


METRICS = ('full', 'roi', 'ssim_roi', 'edge_mae', 'lpips_roi', 'same_operator_lr_mae')
LOWER_BETTER = {'edge_mae', 'lpips_roi', 'same_operator_lr_mae'}


def sha(path):
    result = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            result.update(chunk)
    return result.hexdigest()


def read(path):
    return json.loads(Path(path).read_text(encoding='utf8'))


def below(root, relative):
    assert not Path(relative).is_absolute()
    path = (root / relative).resolve(); path.relative_to(root.resolve())
    return path


def decoded(payload, entry, side):
    assert hashlib.sha256(payload).hexdigest() == entry['sha256'] and len(payload) == entry['bytes']
    assert entry['size'] == [side, side] and entry['mode'] == 'RGB'
    with Image.open(BytesIO(payload)) as image:
        assert image.format == 'PNG'; image.verify()
    with Image.open(BytesIO(payload)) as image:
        image.load(); assert image.size == (side, side) and image.mode == 'RGB'
        return image.copy()


def display_matches(raw, display):
    expected = np.asarray(raw.resize((400, 400), Image.Resampling.BICUBIC))
    assert np.array_equal(expected, np.asarray(display)), 'Display differs from declared learned80 bicubic interpolation'


def recompute(report):
    groups, identities = collections.defaultdict(list), []
    for row in report['rows']:
        assert row['regime'] in ('clean', 'sensor') and all(math.isfinite(row[k]) for k in METRICS)
        identities.append((row['id'], row['source_group'], row['regime']))
        groups[row['source_group']].append(row)
    assert len(identities) == len(set(identities)) == report['count']
    gm = {g: {k: float(np.mean([r[k] for r in rows])) for k in METRICS} for g, rows in groups.items()}
    macro = {k: float(np.mean([values[k] for values in gm.values()])) for k in METRICS}
    assert len(gm) == report['groups'] and set(gm) == set(report['group_means'])
    for g in gm:
        for key in METRICS:
            assert abs(gm[g][key] - report['group_means'][g][key]) < 1e-10
    assert all(abs(macro[k] - report['means'][k]) < 1e-10 for k in METRICS)
    by_id = collections.defaultdict(set)
    for identifier, group, regime in identities:
        by_id[(identifier, group)].add(regime)
    assert all(value == {'clean', 'sensor'} for value in by_id.values())
    return {'identities': sorted(identities), 'group_means': gm, 'means': macro}


def bootstrap(reference, candidate, draws=10000, seed=10052026):
    assert reference['identities'] == candidate['identities'], 'Different paired cases'
    groups = sorted(candidate['group_means']); assert groups == sorted(reference['group_means'])
    sample = np.random.default_rng(seed).integers(0, len(groups), (draws, len(groups)))
    metrics = {}
    for key in METRICS:
        a = np.array([reference['group_means'][g][key] for g in groups])
        b = np.array([candidate['group_means'][g][key] for g in groups]); delta = b - a
        metrics[key] = {'candidate_minus_control': float(delta.mean()),
            'ci95': [float(x) for x in np.percentile(delta[sample].mean(axis=1), [2.5, 97.5])],
            'better_group_fraction': float(np.mean(delta < 0 if key in LOWER_BETTER else delta > 0)),
            'direction': 'lower is better' if key in LOWER_BETTER else 'higher is better',
            'group_differences': {g: float(x) for g, x in zip(groups, delta)}}
    return {'groups': groups, 'draws': draws, 'seed': seed, 'metrics': metrics,
            'scope': 'Descriptive frozen-candidate test contrast, not test-based model selection; only4heldout locations.'}


def verify_reference(path, candidate_config, root, assets):
    """Bind a named control report to its full completed control run and weight."""
    path = Path(path); report = read(path); config_path = path.parent / 'config.json'
    config = read(config_path); common_path = path.parent.parent / 'config.json'
    common = read(common_path); complete = read(path.parent.parent / 'complete.json')
    methods = ['bicubic', 'old', 'B20', 'B30', 'swinir_classical_x4_init', 'swinir_real_psnr_x4_init']
    assert config['fixed_methods'] == common['fixed_methods'] == methods
    assert config['method'] == path.parent.name and config['method'] in methods
    assert complete['complete'] is True and complete['selection_changed'] is False
    assert complete['test_ranking_performed'] is False and complete['config_sha256'] == sha(common_path)
    assert report['config_sha256'] == sha(config_path)
    assert report['selection_sha256'] == config['selection_sha256'] == complete['selection_sha256'] == candidate_config['selection_sha256']
    assert all(config[k] == value for k, value in common.items())
    assert len(complete['reports']) == len(methods) and {r['method'] for r in complete['reports']} == set(methods)
    entries = [r for r in complete['reports'] if r['method'] == config['method']]
    assert len(entries) == 1 and entries[0]['sha256'] == sha(path) and entries[0]['config_sha256'] == sha(config_path)
    assert entries[0]['verified_output_files'] == 312
    receipt, method = config['model'], config['method']
    if method.endswith('_init'):
        name = method.removesuffix('_init'); asset = read(assets / 'asset_receipt.json')['assets'][name]
        assert receipt['name'] == name and receipt['adapted'] is False and receipt['strict_load'] is True
        assert receipt['checkpoint_sha256'] == asset['sha256'] == sha(assets / asset['filename'])
    elif method == 'bicubic':
        assert receipt['name'] == method and receipt['weight_sha256'] is None and receipt['new_training'] is False
    else:
        checkpoint = (root / 'reduction_v2_20260928/training/C20_sensor/best_inference.pt' if method == 'old' else
                      root / 'research_v4_20260929/train/B_real' / ('best_perceptual.pt' if method == 'B20' else 'final.pt'))
        assert receipt['name'] == method and receipt['strict_load'] is True and receipt['new_training'] is False
        assert receipt['weight_sha256'] == sha(checkpoint)
        if method in ('B20', 'B30'):
            assert receipt['checkpoint_step'] == (20000 if method == 'B20' else 30000)
    for row in report['rows']:
        images = {}
        for key, side in (('learned80', 80), ('display400', 400)):
            entry = row['outputs'][key]
            assert entry['path'] == f"paired/{row['id']}/{row['regime']}/{key}.png"
            images[key] = decoded(below(path.parent, entry['path']).read_bytes(), entry, side)
        display_matches(images['learned80'], images['display400'])
    return report, {'method': method, 'model_receipt': receipt, 'config_sha256': sha(config_path),
                    'complete_sha256': sha(path.parent.parent / 'complete.json')}


def audit_native_shard(archive, meta, expected, pixels):
    assert sha(archive) == meta['tar_sha256'] and meta['indices'] == expected
    assert [row['index'] for row in meta['rows']] == expected
    wanted = [f'{i}/{key}.png' for i in expected for key in ('learned80', 'display400')]
    panel_bytes = {}
    with tarfile.open(archive, 'r:') as tar:
        members = tar.getmembers()
        assert len(members) == len(wanted) and [m.name for m in members] == wanted
        assert all(m.isfile() for m in members)
        for row in meta['rows']:
            index = row['index']
            assert row['input_pixels_sha256'] == hashlib.sha256(pixels[index].tobytes()).hexdigest()
            assert set(row['files']) == {'learned80', 'display400'}
            images, bodies = {}, {}
            for key, side in (('learned80', 80), ('display400', 400)):
                entry = row['files'][key]; assert entry['path'] == f'{index}/{key}.png'
                member = tar.getmember(entry['path']); body = tar.extractfile(member).read()
                assert member.size == entry['bytes']; images[key] = decoded(body, entry, side); bodies[key] = body
            display_matches(images['learned80'], images['display400'])
            if 'panel' in row:
                panel_bytes[index] = bodies
    return panel_bytes


def run_audit(args):
    output, root = args.output, args.root
    assert sha(args.selection) == args.selection_sha256, 'Unexpected frozen selection bytes'
    cfg_path = output / 'config.json'; cfg = read(cfg_path); done = read(output / 'completion.json')
    selected = read(args.selection)
    assert sha(args.selection) == cfg['selection_sha256'] == done['selection_sha256']
    assert selected == cfg['selection'] == read(output / 'selection.json')
    assert selected['frozen'] is True and selected['test_used_for_selection'] is False
    assert selected['version'] == cfg['version'] == 5
    assert done['complete'] is True and done['config_sha256'] == sha(cfg_path)
    checkpoint = below(args.run, selected['checkpoint']['file'])
    assert sha(checkpoint) == selected['checkpoint']['sha256']
    assert cfg['checkpoint'] == selected['checkpoint']
    assert sha(args.run / 'config.json') == selected['training_config_sha256']
    assert sha(args.run / 'training_complete.json') == selected['training_complete_sha256']
    training, train_done = read(args.run / 'config.json'), read(args.run / 'training_complete.json')
    assert train_done['complete'] and train_done['steps'] == training['steps'] and not training['smoke']
    assert train_done['config_sha256'] == selected['training_config_sha256'] and train_done['test_evaluated'] is False
    assert training['model'] == cfg['checkpoint']['model'] and cfg['checkpoint']['step'] <= training['steps']
    assert cfg['input_size'] == [20, 20] and cfg['learned_size'] == [80, 80] and cfg['display_size'] == [400, 400]
    manifest_path = args.data / 'manifest.json'; assert sha(manifest_path) == selected['data_manifest_sha256'] == cfg['data_manifest_sha256']
    native_path = root / 'geometry_20260928/test_protocol.json'
    panel_path = root / 'research_v4_20260929/visual_panel_frozen.json'
    assert sha(native_path) == selected['native_protocol_sha256'] and sha(panel_path) == selected['visual_panel_sha256']
    native, panel = read(native_path), read(panel_path)
    expected = native['test_indices']; assert len(expected) == len(set(expected)) == 8000
    panel_ids = sorted(set(native['display_indices']) | set(panel['native_ids']))
    assert len(panel_ids) == 29 and cfg['native_panel_ids'] == selected['native_panel_ids'] == panel_ids
    source = root / 'planesnet_20260921/inputs.npy'
    assert sha(source) == cfg['input_array_sha256'] == native['planesnet_npy_sha256']
    pixels = np.load(source, mmap_mode='r', allow_pickle=False)
    assert pixels.dtype == np.uint8 and pixels.shape[1:] == (20, 20, 3)
    seen, archives, panel_bodies = [], [], {}
    assert len(done['shard_manifests']) == 40
    for number in range(40):
        path = output / f'shard_{number:03d}.json'; meta = read(path)
        assert done['shard_manifests'][number] == {'number': number, 'sha256': sha(path)}
        assert meta['number'] == number and meta['config_sha256'] == sha(cfg_path)
        ids = expected[number * 200:(number + 1) * 200]
        panel_bodies.update(audit_native_shard(path.with_suffix('.tar'), meta, ids, pixels))
        seen.extend(ids); archives.append({'file': path.with_suffix('.tar').name, 'sha256': meta['tar_sha256'], 'verified_pngs': 400})
    assert seen == expected and set(panel_bodies) == set(panel_ids)
    assert sha(output / 'panel.json') == done['panel_sha256']
    actual_panel = read(output / 'panel.json')
    assert actual_panel['config_sha256'] == sha(cfg_path) and actual_panel['native_no_hr'] is True
    assert [r['index'] for r in actual_panel['rows']] == panel_ids
    for row in actual_panel['rows']:
        i = row['index']; entries = row['files']
        assert set(entries) == {'input20', 'input_nearest400', 'input_bicubic400', 'learned80', 'display400'}
        for key, entry in entries.items():
            assert entry['path'] == f'panel/{i}/{key}.png'
            body = below(output, entry['path']).read_bytes()
            image = decoded(body, entry, 20 if key == 'input20' else (80 if key == 'learned80' else 400))
            if key in ('learned80', 'display400'):
                assert body == panel_bodies[i][key]
            else:
                expected_image = Image.fromarray(pixels[i])
                if key != 'input20':
                    expected_image = expected_image.resize((400, 400), Image.Resampling.NEAREST if key == 'input_nearest400' else Image.Resampling.BICUBIC)
                assert np.array_equal(np.asarray(image), np.asarray(expected_image))
    paired_path = output / 'paired_test.json'; assert sha(paired_path) == done['paired_test_sha256']
    paired = read(paired_path)
    assert paired['complete'] is True and paired['split'] == 'test' and paired['test_used_for_selection'] is False
    assert paired['config_sha256'] == sha(cfg_path) and paired['selection_sha256'] == cfg['selection_sha256']
    assert paired['data_manifest_sha256'] == cfg['data_manifest_sha256']
    assert paired['metric_spec'] == cfg['metric_spec'] and paired['vgg_sha256'] == cfg['vgg_sha256'] == training['vgg_sha256']
    manifest = read(manifest_path)
    tests = sorted((r for r in manifest['records'] if r['split'] == 'test' and r['scale'] == 4 and r.get('synthetic') is False), key=lambda r: r['id'])
    assert len(tests) == 78 and len({r['source_group'] for r in tests}) == 4
    identities = [(r['id'], r['source_group'], reg) for r in tests for reg in ('clean', 'sensor')]
    assert [(r['id'], r['source_group'], r['regime']) for r in paired['rows']] == identities
    by_id = {r['id']: r for r in tests}; verified_source = set()
    for row in paired['rows']:
        assert row['source_files'] == by_id[row['id']]['files']
        for key, entry in row['source_files'].items():
            path = below(args.data, entry['path'])
            if str(path) not in verified_source:
                assert sha(path) == entry['sha256']
                with Image.open(path) as image:
                    image.load(); assert image.mode == ('L' if key in ('roi', 'valid') else 'RGB')
                    assert image.size == ((20, 20) if key.endswith('_lr') else (80, 80))
                verified_source.add(str(path))
        images = {}
        assert set(row['outputs']) == {'learned80', 'display400'}
        for key, side in (('learned80', 80), ('display400', 400)):
            entry = row['outputs'][key]; assert entry['path'] == f"paired/{row['id']}/{row['regime']}/{key}.png"
            images[key] = decoded(below(output, entry['path']).read_bytes(), entry, side)
        display_matches(images['learned80'], images['display400'])
    grouped = recompute(paired); assert paired['count'] == 156 and paired['groups'] == 4
    contrasts = []
    for path in args.reference:
        control, identity = verify_reference(path, cfg, root, args.assets)
        assert control['complete'] is True and control['split'] == 'test' and control['test_used_for_selection'] is False
        for key in ('data_manifest_sha256', 'vgg_sha256', 'metric_spec'):
            assert control[key] == paired[key], f'Control differs in {key}'
        assert [(r['id'], r['regime'], r['source_files']) for r in control['rows']] == [(r['id'], r['regime'], r['source_files']) for r in paired['rows']]
        contrasts.append({'reference_file': str(path), 'reference_sha256': sha(path), 'identity': identity,
                          **bootstrap(recompute(control), grouped)})
    assert done['native_images'] == 8000 and done['native_pngs'] == 16000
    return {'complete': True, 'selection_sha256': sha(args.selection), 'config_sha256': sha(cfg_path),
        'checkpoint': cfg['checkpoint'], 'native_exact_ids': True, 'verified_native_pngs': 16000,
        'verified_paired_output_pngs': 312, 'verified_paired_source_files': len(verified_source),
        'verified_panel_pngs': 145, 'native_learned_size': [80, 80], 'native_display_size': [400, 400],
        'all_displays_verified_as_interpolation': True, 'paired_group_macro': grouped['means'], 'contrasts': contrasts,
        'archives': archives, 'audit_code_sha256': sha(Path(__file__)),
        'scope': 'Every payload SHA, PNG decode, dimensions, exact identity and grouped arithmetic checked. No visual-quality claim; LPIPS forward not rerun by this CPU auditor.'}


def main(args):
    report = args.report or args.output / 'integrity_audit.json'
    # A failed re-audit cannot leave an earlier success marker looking current.
    status = report.with_name(report.stem + '_status.json')
    def write(path, value):
        path.parent.mkdir(parents=True, exist_ok=True); tmp = path.with_name(path.name + '.tmp')
        tmp.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False), encoding='utf8'); tmp.replace(path)
    write(status, {'state': 'running', 'audit_code_sha256': sha(Path(__file__))})
    if report.exists():
        report.replace(report.with_name(report.name + '.previous'))
    try:
        result = run_audit(args)
    except Exception as error:
        write(status, {'state': 'failed', 'error': str(error), 'audit_code_sha256': sha(Path(__file__))})
        raise
    write(report, result); write(status, {'state': 'complete', 'report_sha256': sha(report)})
    print('V5_AUDIT_COMPLETE', str(report), 16000, flush=True)


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    for key in ('selection', 'run', 'data', 'root', 'assets', 'output'):
        parser.add_argument('--' + key, required=True, type=Path)
    parser.add_argument('--selection-sha256', required=True)
    parser.add_argument('--reference', type=Path, action='append', default=[], help='Same-grid paired control JSON, descriptive bootstrap only')
    parser.add_argument('--report', type=Path)
    main(parser.parse_args())
