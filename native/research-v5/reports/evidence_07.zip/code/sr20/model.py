"""Reuse a 4x residual CNN in bounded-scale cycles, with lightweight alignment.

Inspired by Guo et al., CASR, arXiv:2602.22159, sections 3.1-3.3.
This is a CNN adaptation, not a diffusion/SAM/DepthAnything reproduction.
"""
import math
import torch
from torch import nn
from torch.nn import functional as F


def resize(x, size):
    return F.interpolate(x, size=size, mode='bicubic', align_corners=False,
                         antialias=True)


class ResidualBlock(nn.Module):
    def __init__(self, width):
        super().__init__()
        self.conv1 = nn.Conv2d(width, width, 3, padding=1)
        self.conv2 = nn.Conv2d(width, width, 3, padding=1)

    def forward(self, x):
        return x + self.conv2(F.relu(self.conv1(x))) * 0.1


class SoftSuperpixelAlignment(nn.Module):
    """Local 9-region soft color/spatial assignment and regional RGB aggregation.

    Regular-grid seeds, differentiable color-based assignments; no pretrained
    SpixelNet or depth model. A learned blend preserves fine input information.
    """
    def __init__(self, cell=4):
        super().__init__()
        self.cell = cell
        self.blend_logit = nn.Parameter(torch.tensor(-3.0))

    def forward(self, x):
        b, c, h, w = x.shape
        gh, gw = max(1, math.ceil(h / self.cell)), max(1, math.ceil(w / self.cell))
        centers = F.adaptive_avg_pool2d(x, (gh, gw)).flatten(2)
        yy, xx = torch.meshgrid(torch.arange(h, device=x.device),
                                torch.arange(w, device=x.device), indexing='ij')
        cy, cx = (yy + .5) * gh / h - .5, (xx + .5) * gw / w - .5
        iy, ix = cy.round().long(), cx.round().long()
        ids, spatial, valid = [], [], []
        for dy in (-1, 0, 1):
            for dx in (-1, 0, 1):
                sy, sx = iy + dy, ix + dx
                ids.append((sy.clamp(0, gh - 1) * gw + sx.clamp(0, gw - 1)).flatten())
                spatial.append(((cy - sy).square() + (cx - sx).square()).flatten())
                valid.append(((sy >= 0) & (sy < gh) & (sx >= 0) & (sx < gw)).flatten())
        ids, spatial, valid = torch.stack(ids), torch.stack(spatial), torch.stack(valid)
        index = ids.reshape(1, 1, -1).expand(b, c, -1)
        seeds = centers.gather(2, index).reshape(b, c, 9, h * w)
        pixels = x.flatten(2)
        distance = (pixels[:, :, None] - seeds).square().mean(1) / .02 + spatial[None] * .5
        weights = (-distance).masked_fill(~valid[None], -1e4).softmax(1)
        sums = x.new_zeros(b, c, gh * gw)
        sums.scatter_add_(2, index, (pixels[:, :, None] * weights[:, None]).reshape(b, c, -1))
        norm = x.new_zeros(b, 1, gh * gw)
        norm.scatter_add_(2, ids.reshape(1, 1, -1).expand(b, 1, -1), weights.reshape(b, 1, -1))
        regions = sums / norm.clamp_min(1e-6)
        smooth = (regions.gather(2, index).reshape(b, c, 9, h * w) * weights[:, None]).sum(2).reshape_as(x)
        aligned = x + self.blend_logit.sigmoid() * (smooth - x)
        return aligned, smooth


class SelfSimilarityRefinement(nn.Module):
    """All query positions can attend to a bounded global LR feature grid."""
    def __init__(self, width, grid=8):
        super().__init__()
        self.grid = grid
        self.q = nn.Conv2d(width, width // 2, 1)
        self.k = nn.Conv2d(width, width // 2, 1)
        self.v = nn.Conv2d(width, width, 1)
        self.out = nn.Conv2d(width, width, 1)
        nn.init.zeros_(self.out.weight)
        nn.init.zeros_(self.out.bias)

    def forward(self, features, reference):
        h, w = reference.shape[-2:]
        tokens = F.adaptive_avg_pool2d(reference, (min(h, self.grid), min(w, self.grid)))
        q = F.normalize(self.q(features).flatten(2).transpose(1, 2), dim=-1, eps=1e-6)
        k = F.normalize(self.k(tokens).flatten(2), dim=1, eps=1e-6)
        attention = torch.bmm(q, k).mul(4).softmax(-1)
        context = torch.bmm(self.v(tokens).flatten(2), attention.transpose(1, 2)).reshape_as(features)
        return features + self.out(context)


class CyclicSR(nn.Module):
    schedules = {2: (2,), 4: (4,), 10: (2.5, 4), 20: (2, 2.5, 4)}

    def __init__(self, width=48, blocks=6, default_scale=20):
        super().__init__()
        self.default_scale = default_scale
        self.head = nn.Conv2d(3, width, 3, padding=1)
        self.body = nn.Sequential(*[ResidualBlock(width) for _ in range(blocks)])
        # Retain pretrained x4 pixel-shuffle reconstruction weights.
        self.tail = nn.Sequential(nn.Conv2d(width, 48, 3, padding=1), nn.PixelShuffle(4))
        self.alignment = SoftSuperpixelAlignment()
        self.condition = nn.Conv2d(6, width, 3, padding=1)
        self.similarity = SelfSimilarityRefinement(width)
        nn.init.zeros_(self.condition.weight)
        nn.init.zeros_(self.condition.bias)
        nn.init.normal_(self.tail[0].weight, std=1e-3)
        nn.init.zeros_(self.tail[0].bias)

    def initialize_baseline(self, checkpoint):
        config = checkpoint['model_config']
        if config['scale'] != 4 or config.get('lora_rank', 0):
            raise ValueError('Requires a full x4 baseline checkpoint')
        expected = {k for k in self.state_dict() if k.startswith(('head.', 'body.', 'tail.'))}
        if set(checkpoint['model']) != expected:
            raise ValueError('Baseline architecture differs')
        result = self.load_state_dict(checkpoint['model'], strict=False)
        if result.unexpected_keys or set(result.missing_keys) & expected:
            raise ValueError(result)
        return sorted(expected)

    def step(self, x, size):
        aligned, smooth = self.alignment(x)
        features = self.head(aligned)
        condition = self.condition(torch.cat((smooth, x - smooth), 1))
        features = self.body(features + condition)
        features = self.similarity(features, self.head(x))
        residual = self.tail(features)
        if residual.shape[-2:] != tuple(size):
            residual = resize(residual, size)
        return resize(x, size) + residual

    def forward(self, x, scale=None, return_stages=False):
        scale = self.default_scale if scale is None else scale
        if scale not in self.schedules:
            raise ValueError('Supported scales: 2, 4, 10, 20')
        h, w = x.shape[-2:]
        stages, cumulative = [], 1
        for factor in self.schedules[scale]:
            cumulative *= factor
            # Round intermediate grids upwards so even tiny/odd inputs never
            # require a subsequent transition larger than the trained max 4x.
            size = (math.ceil(h * cumulative), math.ceil(w * cumulative))
            x = self.step(x, size)
            stages.append(x)
        assert x.shape[-2:] == (h * scale, w * scale)
        return (x, stages) if return_stages else x


def correlation_matrix(x, grid=8):
    # Fixed RGB + first-derivative descriptors prevent a trainable feature
    # extractor from collapsing the correlation objective to a constant.
    dx = F.pad(x[..., 1:] - x[..., :-1], (0, 1, 0, 0))
    dy = F.pad(x[..., 1:, :] - x[..., :-1, :], (0, 0, 0, 1))
    z = F.adaptive_avg_pool2d(torch.cat((x, dx, dy), 1), (grid, grid))
    z = z.flatten(2)
    z = F.normalize(z - z.mean(-1, keepdim=True), dim=1, eps=1e-5)
    return torch.bmm(z.transpose(1, 2), z)


def reconstruction_loss(pred, stages, hr, lr):
    reconstruction = F.l1_loss(pred, hr)
    intermediate = sum(F.l1_loss(s, resize(hr, s.shape[-2:]).clamp(0, 1)) for s in stages[:-1])
    if stages[:-1]:
        intermediate = intermediate / len(stages[:-1])
    correlation = F.mse_loss(correlation_matrix(pred), correlation_matrix(hr))
    consistency = F.l1_loss(resize(pred, lr.shape[-2:]), lr)
    loss = reconstruction + .1 * intermediate + .01 * correlation + .05 * consistency
    return loss, {'l1': float(reconstruction.detach()), 'intermediate': float(intermediate.detach()) if torch.is_tensor(intermediate) else intermediate,
                  'correlation': float(correlation.detach()), 'lr_consistency': float(consistency.detach())}
