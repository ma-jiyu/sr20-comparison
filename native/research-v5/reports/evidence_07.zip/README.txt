Aircraft SR V5 — source and evidence archive

STATUS
This ZIP preserves the exact local source bytes and experiment records listed in
ARCHIVE_MANIFEST.json. CRC and extracted-byte SHA256 are verified. It is NOT an
experiment already reproduced in a clean environment, a portable training image,
or proof of numerical reproducibility on another GPU/software stack.

CONTENTS
code/sr20/: ten requested entrypoints and recursive static relative Python
dependencies, package initializer and this packager. Training-referenced code
SHA256 values are checked against all three recorded config.json files.
experiment/: three prospective training protocols, native-pair manifest, data
source plan/URL/hash receipts, RarePlanes license, official SwinIR receipt and
pinned network_swinir.py, training config/progress/validation/completion records.
No credentials, raw images, generated pair images, model weights, installed
packages, other projects, websites or SSH configuration are included.

RECORDED TRAINING ENVIRONMENT
The three actual config/progress records specify float32, seed 1005, effective
batch 8, microbatch 4, 6000 updates and the recorded Adam/cosine schedule.
Original classical and real-PSNR use reconstruction_steps=4000; the reconstruction
control uses 6000 and progress confirms perceptual_weight=0 throughout.
Python, PyTorch, CUDA/cuDNN, GPU model and dependency versions were NOT recorded
in those files. They are intentionally not invented here. The computer running
this archive builder is not the historical training environment.
See TRAINING_ENVIRONMENT_EVIDENCE.json for exact source attribution.
experiment/environment_after_training.json, when present, records a later read
from the same server interpreter. It is useful setup evidence, not a training-time
lockfile or proof that dependencies never changed.
Required third-party packages include torch/torchvision/timm/numpy/Pillow/OpenCV,
lpips/requests/matplotlib. This is an unpinned dependency list, not an environment lock.

DATA AND LICENSING
RarePlanes real imagery: follow the official source URLs in sources.json and
LICENSE.txt (CC BY-SA 4.0) and preserve attribution: RarePlanes Dataset, Shermeyer
et al. (2020), In-Q-Tel CosmiQ Works and AI.Reverie; real imagery Maxar WorldView-3.
Our paired crops are minified from native HR, with computational LR degradation.
The frozen manifest contains x4: 385 train / 61 val / 78 test instances across
20 / 4 / 4 locations. x8 is a smaller ancillary set; do not pool resolutions.
Official test locations are excluded from source selection. This experiment's
held-out test must remain unavailable for training or candidate selection.
Geographic object IDs do not prove globally distinct physical airframes. Geographic
overlap with all older source datasets is not fully excluded.
Frozen manifest SHA256: 344914c935fc08b757ccb23adb176d3f0bf00a5500aa21565f97697c8d4c2d86
Neither source imagery nor pair PNG files are bundled. Acquire from official
URLs and verify all source/pair hashes. prepare_v5_rareplanes.py also requires the
prior matched_sources.json catalogue at its PRIOR path to reproduce exclusions;
that historical catalogue is not bundled. Its SHA/excluded locations are recorded
in source_plan_v2_frozen.json. A new data regeneration has not been tested here.

OFFICIAL MODELS AND OTHER ASSETS
Obtain official SwinIR assets from the pinned repository/release URLs in
code/sr20/v5_baseline_sources.json. Verify against experiment/weights/asset_receipt.json.
The release publisher did not supply SHA256; these are locally observed download
hashes, not signed publisher digests. Follow the upstream Apache-2.0 license.
The exact official architecture file is bundled because it is dynamically loaded.
Pretrained VGG16 required by the recorded LPIPS evaluator has SHA256:
397923af8e79cdbb6a7127f12361acd7a2f83e06b05044ddf496e83de57a5bf0
Stage it in the torch hub checkpoint cache. LPIPS package/calibration/version also
needs to be provided. Existing old/B20/B30 controls and native8000 inputs require
the original audited artifacts; their model/image bytes are not bundled.
Optional historical CASR branches import an external CASR checkout, src.* and
_common dynamically; that separate project is not copied and is not required for
the V5 SwinIR training path. This ZIP does not independently reproduce old CASR work.

PATHS AND OPERATION (examples, not commands already rerun)
Extract, enter code/, then use python -m sr20.<entrypoint> --help.
Reconfigure --data, --assets, --run, --protocol, --root, --selection and --output
to your own absolute paths. Frozen records retain their original values; keep
an unchanged evidence copy. Any adapted source gets a new hash/experiment ID.
To retrieve official SwinIR assets explicitly:
  python -m sr20.v5_baselines prepare --assets YOUR_ASSET_DIRECTORY
Compare resulting hashes to the preserved official download receipt.
Training reconstruction example after acquiring/verifying data/assets/environment:
  python -m sr20.train_v5_reconstruction --data YOUR_RARE_DATA --assets YOUR_ASSETS --run NEW_RUN --protocol YOUR_RECONSTRUCTION_PROTOCOL --model swinir_classical_x4 --steps 6000 --reconstruction-steps 6000 --batch 8 --microbatch 4 --seed 1005 --device cuda
Original classical/real-PSNR use train_v5_swinir with reconstruction-steps 4000
and their own frozen protocol/model name. Never mix their run directories.
Candidate selection/visual review must precede freeze_v5_reconstruction_candidates;
only then use infer_v5_swinir and evaluate_v5_test_controls. Final test is not a
hyperparameter-selection loop. Native 20-to-80 learned output and 400-pixel
display interpolation must remain separately labeled.
analyze_v5_results / compare_v5_loss_ablation require saved run/evaluation records;
some commands additionally require the original native manifest/selection and
data bytes. The ZIP preserves code and bounded evidence, not every runtime input.

ARCHIVE INTEGRITY
ARCHIVE_MANIFEST.json lists SHA256/size for each member except itself (self-hashing
would be recursive). The external reproduction_verification.json gives the ZIP
and manifest SHA256 and the full CRC/extracted-byte verification result.
The builder rereads every source file after building and refuses publication if
its bytes changed during packaging. It never rewrites trained code/config/data.
